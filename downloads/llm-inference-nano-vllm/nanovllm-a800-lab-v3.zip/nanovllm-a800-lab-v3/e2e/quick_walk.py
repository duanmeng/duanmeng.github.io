"""A/B/C/D source walkthrough. Tracing is diagnostic, never a benchmark."""
import argparse
import json
import os
from pathlib import Path


def cases(name):
    if name == "A":
        return [[100, 200, 300]], [3]
    if name == "B":
        return [[100, 200, 300], [400, 500, 600, 700]], [2, 5]
    if name == "C":
        return [list(range(100, 356))], [3]
    return [[100] * 700, [101] * 32], [3, 3]


def state(seq):
    return dict(id=seq.seq_id, total=seq.num_tokens, cached=seq.num_cached_tokens,
                scheduled=seq.num_scheduled_tokens, output=seq.num_completion_tokens,
                status=seq.status.name, blocks=list(seq.block_table))


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--model", default=os.environ.get("MODEL_DIR"))
    p.add_argument("--case", choices=list("ABCD"), required=True)
    p.add_argument("--budget", type=int, choices=[256, 512, 1024], default=512)
    p.add_argument("--max-num-seqs", type=int, choices=[1, 2], default=2)
    p.add_argument("--debug", action="store_true")
    p.add_argument("--trace", action="store_true")
    p.add_argument("--out")
    args = p.parse_args()
    if not args.model:
        p.error("Use --model or source env.sh")
    import torch
    from nanovllm import LLM, SamplingParams
    import nanovllm.engine.llm_engine as engine_module
    from nanovllm.utils.context import get_context

    torch.manual_seed(0)
    llm = LLM(args.model, enforce_eager=True, tensor_parallel_size=1,
              max_model_len=1024, max_num_seqs=args.max_num_seqs,
              max_num_batched_tokens=args.budget, kvcache_block_size=256,
              gpu_memory_utilization=0.5)
    rows = []
    scheduler = llm.scheduler
    runner = llm.model_runner
    schedule, postprocess = scheduler.schedule, scheduler.postprocess

    def traced_schedule():
        seqs, prefill = schedule()
        rows.append(dict(phase="prefill" if prefill else "decode",
                         before=[state(s) for s in seqs]))
        return seqs, prefill

    def traced_postprocess(seqs, token_ids, prefill):
        postprocess(seqs, token_ids, prefill)
        rows[-1].update(after=[state(s) for s in seqs],
                        running=[s.seq_id for s in scheduler.running],
                        waiting=[s.seq_id for s in scheduler.waiting],
                        free_blocks=len(scheduler.block_manager.free_block_ids))
        if args.trace:
            print(json.dumps(dict(event="walk_step", step=len(rows), **rows[-1])))

    def traced_prepare(original):
        def prepare(seqs):
            ids, positions = original(seqs)
            ctx = get_context()
            rows[-1]["inputs"] = dict(shape=list(ids.shape),
                positions_first8=positions[:8].tolist(), positions_last8=positions[-8:].tolist(),
                slots_last8=ctx.slot_mapping[-8:].tolist(),
                context_lens=None if ctx.context_lens is None else ctx.context_lens.tolist())
            return ids, positions
        return prepare

    scheduler.schedule = traced_schedule
    scheduler.postprocess = traced_postprocess
    runner.prepare_prefill = traced_prepare(runner.prepare_prefill)
    runner.prepare_decode = traced_prepare(runner.prepare_decode)
    prompts, limits = cases(args.case)
    print("Loaded source:", engine_module.__file__)
    print("Prompt lengths:", [len(x) for x in prompts], "Output limits:", limits)
    if args.debug:
        breakpoint()  # Initialization/warmup are deliberately already finished.
    outputs = llm.generate(prompts, [SamplingParams(temperature=0.6, max_tokens=n,
                          ignore_eos=True) for n in limits], use_tqdm=False)
    assert [len(x["token_ids"]) for x in outputs] == limits
    assert scheduler.is_finished()
    if args.max_num_seqs == 2:
        expected = {"A": [3, 1, 1], "B": [7, 2, 1, 1, 1], "C": [256, 1, 1]}
        if args.case in expected:
            assert [r["inputs"]["shape"][0] for r in rows] == expected[args.case]
        else:
            expected_prefill = {256: [[256], [256], [188, 32]],
                                512: [[512], [188, 32]], 1024: [[700, 32]]}
            actual = [[s["scheduled"] for s in r["before"]]
                      for r in rows if r["phase"] == "prefill"]
            assert actual == expected_prefill[args.budget], actual
    result = dict(check="PASS", scope="actual GPU walkthrough; structural assertions only",
                  case=args.case, budget=args.budget, max_num_seqs=args.max_num_seqs,
                  source=engine_module.__file__, rounds=rows, outputs=outputs)
    if args.out:
        dest = Path(args.out)
        dest.parent.mkdir(parents=True, exist_ok=True)
        dest.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n")
    print(json.dumps(dict(check="PASS", case=args.case, steps=len(rows),
                          output_counts=[len(x["token_ids"]) for x in outputs])))


if __name__ == "__main__":
    main()
