"""Verify the walkthrough's budget predictions using the actual Scheduler, no GPU."""
import argparse
import json
import types
from pathlib import Path
from cpu_scheduler import load_source


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--repo", required=True)
    p.add_argument("--out", required=True)
    a = p.parse_args()
    Seq, SP, Scheduler, _ = load_source(a.repo)
    results = {}
    expected = {256: [[256], [256], [188, 32]],
                512: [[512], [188, 32]], 1024: [[700, 32]]}
    for budget in expected:
        Seq.block_size = 256
        sched = Scheduler(types.SimpleNamespace(max_num_seqs=2, max_num_batched_tokens=budget,
                          eos=-1, kvcache_block_size=256, num_kvcache_blocks=16))
        for ids in [[100] * 700, [101] * 32]:
            sched.add(Seq(ids, SP(max_tokens=3, ignore_eos=True)))
        prefills = []
        rounds = 0
        while not sched.is_finished():
            selected, prefill = sched.schedule()
            if prefill:
                prefills.append([s.num_scheduled_tokens for s in selected])
            sched.postprocess(selected, [1000] * len(selected), prefill)
            rounds += 1
            assert rounds < 12
        assert prefills == expected[budget], prefills
        results[str(budget)] = dict(prefills=prefills, total_rounds=rounds)
    result = dict(check="PASS", scope="CPU Scheduler with synthetic sampled IDs, not GPU inference",
                  results=results)
    out = Path(a.out)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
