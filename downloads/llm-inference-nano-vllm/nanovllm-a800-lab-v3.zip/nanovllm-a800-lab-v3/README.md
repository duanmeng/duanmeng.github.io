# nano-vLLM A800 实验包 v3

配套文档：https://bytedance.larkoffice.com/docx/KoiNd9URGohmWGxB2WlcOUA4ndh

## 先打开什么

用浏览器打开同目录的“第18章-操作手册.html”。它包含本次重构的完整步骤、全部命令与验收说明；不是启动实验的网页按钮。代码要在 GPU 实验机的终端执行。

本包针对现成的 Linux x86_64 / Python 3.11.2 / CUDA 12.9.86 / 多张 A800-SXM4-80GB 环境设计，按用户说明将现有环境视为可用。不安装驱动、不更换系统 Python、不安装 Docker。

## 唯一目录与版本

- ZIP 含 nanovllm-a800-lab-v3 顶层目录，解压到用户目录后得到 $HOME/nanovllm-a800-lab-v3。
- 上游仓库：GeeeekExplorer/nano-vllm。
- 固定提交：bb823b3e06983d71485a8e1f23715ebd87d98ef8（0.2.0）。
- 模型：Qwen/Qwen3-0.6B。
- 模型 revision：c1899de289a04d12100db370d81485cdf75e47ca。
- 参考新装依赖：Torch 2.8.0+cu129、Triton 3.4.0、FlashAttention 2.8.3、Transformers 4.57.1。
- 本包不含引擎源码、模型权重、虚拟环境或已编译 GPU 扩展。必须完成操作手册的 clone、安装和模型下载步骤。
- 若复用已有可工作 GPU 软件栈，按操作手册的继承环境分支执行，记录实际版本，不能声称它与参考新装组合相同。

## 第一次按这个顺序做

1. 18.0.1–18.0.2：核对环境和附件，解压后运行 sha256sum -c SHA256SUMS。
2. 18.0.3：git clone，上述固定提交，创建自己的学习分支。
3. 18.0.4：使用现有 Python 3.11.2 创建 .venv-nano，editable 安装 nano-vLLM。
4. 18.0.5：一次性下载完整模型（包括 Tokenizer、配置、权重）。
5. 18.0.6：单卡 doctor、smoke、quick A 都完成后才算 setup 结束。
6. 18.0.7–18.0.10：打开编辑器/断点，按 A 单请求、B 多请求、C 跨页观察。
7. 18.0.11：阅读并应用源码日志补丁，比较 512/256 调度预算，然后撤销补丁或自行保留。
8. 18.7–18.14：深入生命周期、调度、KV 管理、模型形状、Graph、双卡 TP。
9. 18.1–18.6：需要时补做原理与真实模型缓存数值对照，不必按日期顺序学习。

## 安装完成后，每次重新登录

在 GPU 实验机的 Bash 中执行：

    source "$HOME/nanovllm-a800-lab-v3/env.sh"
    source "$LAB_ROOT/.venv-nano/bin/activate"
    cd "$LAB_ROOT"

运行一个例子：

    CUDA_VISIBLE_DEVICES=0 python e2e/quick_walk.py --case A --trace --out runs/quick-A.json

把物理卡编号换成你被分配的卡。交互断点示例：

    cd "$NANO_DIR"
    CUDA_VISIBLE_DEVICES=0 python "$LAB_ROOT/e2e/quick_walk.py" --case A --debug

进入 pdb 后可输入 b engine_module.LLMEngine.step，然后 c 继续。未修改固定源码时还可用手册里的行号断点。CPU/GPU 脚本共用 .venv-nano，不需要 .venv-cpu。

## 哪些文件负责什么

| 文件 | 用途 |
|---|---|
| env.sh | 定位实验根目录、源码目录、模型目录；启用 pipefail |
| e2e/quick_walk.py | A/B/C/D 真实 GPU 入口；诊断日志不是性能测试 |
| patches/01-step-trace.patch | 改 LLMEngine.step，增加 NANO_LAB_TRACE=1 控制的日志 |
| e2e/check_budget_cpu.py | 用真实 Scheduler、合成采样 ID 验证预算预测，不执行模型 |
| labs/01_attention_numpy.py | 最小因果 Attention |
| labs/02_cached_forward.py | Transformers 真实模型缓存/无缓存 logits 对照 |
| labs/03_trace_nanovllm.py | lifecycle/chunk/prefix 真实引擎日志及可选形状 hook |
| labs/04_benchmark_nanovllm.py | 不带 trace 的 eager/Graph/TP 对照 |
| e2e/analyze.py | 读取实际日志，断言固定实验条件 |
| e2e/source_walk.py | 核对原始源码 hash；浏览已修改源码可加 --allow-modified |
| pedagogy/00_uncached_walkthrough.py | 未训练的小模型，无 GPU 依赖 |
| verified_20260922/ | 本次实际执行的本地 CPU 验证，不是 A800 实测 |
| verified_cpu/ | v2 历史 CPU 记录，不是本次 GPU 环境验收 |
| VALIDATION.md | 明确列出已运行和未运行范围 |

## 修改与运行约定

引擎在 nano-vllm/nanovllm/ 下；实验入口在 e2e/ 和 labs/ 下。editable 安装后改 Python 源码不必重新安装，但必须重新启动旧进程。源码补丁的应用、查看 diff 和反向撤销命令见 18.0.11；不要使用 reset --hard 清理学习修改。

nano 使用固定端口 localhost:2333 和共享内存名 nanovllm，同一主机上的实验顺序运行，不并发启动多份。TP=2 只执行一次普通 python 命令，引擎自行 spawn 其他 rank，不用 torchrun/mpirun。

runs/dayNN-* 与 notes/dayNN.md 是保留的实验编号，不代表强制两周课程。只完成 18.0 时 final_report 出现深入实验 MISSING 是正常现象。不要把预期输出粘贴成实测，不要用 trace 日志评估性能。

旧版 ZIP 不要再解压覆盖本目录。SHA256SUMS 是本包的文件完整性校验；手动改过文件后不匹配是预期行为。
