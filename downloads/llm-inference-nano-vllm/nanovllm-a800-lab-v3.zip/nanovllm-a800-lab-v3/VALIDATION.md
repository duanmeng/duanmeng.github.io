# v3 验证边界（2026-09-22）

## 已实际完成

- 下载并核对 nano-vLLM bb823b3e06983d71485a8e1f23715ebd87d98ef8 的 20 个固定源码文件，SOURCE PASS。
- 全部包内 Python 文件通过 Python 3.11 语法解析。
- 正文 33 个 Bash 代码块通过 bash -n；这只是语法检查，不是 GPU 命令实测。
- 日志补丁在固定源码副本上实际应用、解析、反向应用；恢复结果逐字节一致。
- 本地 macOS / Python 3.12.14 / NumPy 2.3.5 / xxhash 3.5.0 执行：Attention、timeline、cache、memory、slots、TP 形状推导、无缓存小模型。
- 直接执行固定提交真实 Scheduler/BlockManager：抢占、引用计数、A/B/C 位置计数、256/512/1024 三种预算；采样 token 使用合成 ID，不运行模型。
- 具体 JSON 在 verified_20260922/；旧 verified_cpu/ 是 v2 历史记录。

## 未实际运行，不能宣称已验证

- Linux Python 3.11.2 / CUDA 12.9 / A800 上的依赖安装。
- Torch/FlashAttention/Triton 的真实 GPU forward。
- quick_walk.py 的 A/B/C/D 完整 GPU 路径。
- CUDA Graph 的捕获、回放和性能对照。
- NCCL TP=2 真实双卡执行。

用户提供的现成机器按可工作环境设计；本文没有远程连接该机器，也没有升级其驱动。参考 Python 依赖组合已经明确列出，不是作者在 A800 上实测通过的镜像。

## PASS 的含义

doctor：依赖导入和一个小 CUDA 运算；不是完整 Attention kernel 验证。
smoke：完整引擎生成指定数量 token；不是质量或性能保证。
quick_walk：对应案例的形状/轮数/输出长度等结构断言；不是逐 token 数值等价证明。
analyze cache：位置计数与误差值有限；BF16 数值是否可接受仍需阅读原始结果。
benchmark：固定工作量、初始化分离和离线吞吐；不能把它当在线 TTFT/ITL。
TP 静态形状：数学推导；不代表通信实际执行。
