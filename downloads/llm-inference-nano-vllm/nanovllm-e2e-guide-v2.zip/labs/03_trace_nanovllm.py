"""固定 nano-vLLM bb823b3，单卡 eager 跟踪；日志会影响速度，不作 benchmark。"""
import argparse
import json
import torch
from nanovllm import LLM, SamplingParams
from nanovllm.utils.context import get_context


def emit(event, **values):
    print(json.dumps({'event': event, **values}, ensure_ascii=False))


def state(seq):
    return dict(id=seq.seq_id, status=seq.status.name, total=len(seq),
                prompt=seq.num_prompt_tokens, cached=seq.num_cached_tokens,
                scheduled=seq.num_scheduled_tokens, blocks=list(seq.block_table))


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--model', required=True)
    p.add_argument('--case', choices=['lifecycle', 'chunk', 'prefix'], default='lifecycle')
    p.add_argument('--shapes', action='store_true', help='Log first prefill/decode shapes in layer 0')
    a = p.parse_args()
    torch.manual_seed(0)
    llm = LLM(a.model, enforce_eager=True, tensor_parallel_size=1,
              max_model_len=1024, max_num_seqs=8,
              max_num_batched_tokens=512, gpu_memory_utilization=0.5)
    scheduler = llm.scheduler
    original_schedule, original_post = scheduler.schedule, scheduler.postprocess

    def schedule():
        emit('before_schedule', waiting=[state(s) for s in scheduler.waiting],
             running=[state(s) for s in scheduler.running])
        seqs, prefill = original_schedule()
        emit('scheduled', prefill=prefill, seqs=[state(s) for s in seqs],
             refs={str(b): scheduler.block_manager.blocks[b].ref_count
                   for s in seqs for b in s.block_table})
        return seqs, prefill

    def post(seqs, token_ids, prefill):
        original_post(seqs, token_ids, prefill)
        emit('after_postprocess', prefill=prefill,
             sampled=token_ids, seqs=[state(s) for s in seqs])

    scheduler.schedule, scheduler.postprocess = schedule, post
    runner = llm.model_runner
    if a.shapes:
        seen = set()

        def shape_hook(name):
            def hook(module, inputs, output):
                phase = 'prefill' if get_context().is_prefill else 'decode'
                key = (phase, name)
                if key not in seen:
                    seen.add(key)
                    emit('model_shape', phase=phase, name=name,
                         input=[list(x.shape) for x in inputs if isinstance(x, torch.Tensor)],
                         output=list(output.shape))
            return hook

        layer = runner.model.model.layers[0]
        for name, module in [('qkv_proj', layer.self_attn.qkv_proj),
                             ('attention_inputs', layer.self_attn.attn),
                             ('o_proj', layer.self_attn.o_proj),
                             ('gate_up_proj', layer.mlp.gate_up_proj),
                             ('down_proj', layer.mlp.down_proj),
                             ('lm_head', runner.model.lm_head)]:
            module.register_forward_hook(shape_hook(name))

    def wrap_prepare(original, phase):
        def prepare(seqs):
            ids, positions = original(seqs)
            ctx = get_context()
            metadata = {}
            for name in ['cu_seqlens_q', 'cu_seqlens_k', 'context_lens', 'block_tables']:
                value = getattr(ctx, name)
                metadata[name] = None if value is None else value.tolist()
            emit('gpu_inputs', phase=phase, input_shape=list(ids.shape),
                 positions_first8=positions[:8].tolist(),
                 slots_first8=ctx.slot_mapping[:8].tolist(), **metadata)
            return ids, positions
        return prepare

    runner.prepare_prefill = wrap_prepare(runner.prepare_prefill, 'prefill')
    runner.prepare_decode = wrap_prepare(runner.prepare_decode, 'decode')
    sp = SamplingParams(temperature=0.6, max_tokens=3, ignore_eos=True)
    if a.case == 'lifecycle':
        llm.generate([[100] * 64, [101] * 96],
                     [SamplingParams(temperature=0.6, max_tokens=2, ignore_eos=True), sp], use_tqdm=False)
    elif a.case == 'chunk':
        llm.generate([[100] * 700, [101] * 32], sp, use_tqdm=False)
    else:
        # 先完成 A，使完整 block 的 hash 登记完成；再提交 B。
        # 相同前 512 tokens，最后 108 tokens 不同。
        prefix = [100] * 512
        llm.generate([prefix + [101] * 108], sp, use_tqdm=False)
        emit('prefix_second_request')
        llm.generate([prefix + [102] * 108], sp, use_tqdm=False)
    # 原仓库已注册 atexit；这里不重复调用非幂等 exit()。


if __name__ == '__main__':
    main()
