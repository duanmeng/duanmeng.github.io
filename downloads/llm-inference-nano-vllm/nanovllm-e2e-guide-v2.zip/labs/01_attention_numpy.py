"""教学用单头 causal attention；无训练权重，不用于生成自然语言。"""
import numpy as np

np.set_printoptions(precision=4, suppress=True)


def softmax(x):
    e = np.exp(x - x.max(axis=-1, keepdims=True))
    return e / e.sum(axis=-1, keepdims=True)


def full_attention(x):
    # 教学简化：Wq = Wk = Wv = 单位矩阵。
    q, k, v = x, x, x
    scores = q @ k.T / np.sqrt(x.shape[-1])
    future = np.triu(np.ones(scores.shape, dtype=bool), k=1)
    weights = softmax(np.where(future, -np.inf, scores))
    return weights @ v, weights


def main():
    x = np.array([[1., 0.], [0., 1.], [1., 1.]])
    output, weights = full_attention(x)
    print('attention weights:\n', weights)
    print('last output:', output[-1])
    changed = x.copy()
    changed[-1] = [10., -7.]
    np.testing.assert_allclose(full_attention(changed)[0][:2], output[:2])
    print('future change leaves earlier positions unchanged: True')

    new_x = np.array([[0.5, 1.]])
    all_x = np.concatenate([x, new_x])
    reference = full_attention(all_x)[0][-1:]
    k_cache = np.concatenate([x.copy(), new_x])
    v_cache = np.concatenate([x.copy(), new_x])
    new_weights = softmax(new_x @ k_cache.T / np.sqrt(2.))
    cached_output = new_weights @ v_cache
    np.testing.assert_allclose(cached_output, reference, atol=1e-12)
    print('cached last output:', cached_output[0])
    print('max error:', float(np.max(np.abs(cached_output - reference))))
    print('query positions: full=4, cached=1; KV positions=4')


if __name__ == '__main__':
    main()
