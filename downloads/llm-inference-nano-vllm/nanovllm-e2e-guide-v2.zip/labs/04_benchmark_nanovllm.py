"""离线吞吐对照；每个配置独立进程运行，初始化与正式生成分开计时。"""
import argparse
import json
import random
import statistics
import time
import torch
from nanovllm import LLM, SamplingParams


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--model', required=True)
    p.add_argument('--eager', action='store_true')
    p.add_argument('--tp', type=int, default=1)
    p.add_argument('--seqs', type=int, default=16)
    p.add_argument('--max-num-seqs', type=int, default=32)
    p.add_argument('--input-len', type=int, default=128)
    p.add_argument('--output-len', type=int, default=32)
    p.add_argument('--repeats', type=int, default=3)
    a = p.parse_args()
    assert a.seqs > 0 and a.input_len > 0 and a.output_len > 0 and a.repeats > 0
    assert a.input_len + a.output_len <= 2048
    assert a.max_num_seqs >= 16 and a.max_num_seqs % 16 == 0
    torch.manual_seed(0)
    start = time.perf_counter()
    llm = LLM(a.model, enforce_eager=a.eager, tensor_parallel_size=a.tp,
              max_num_seqs=a.max_num_seqs, max_model_len=2048,
              max_num_batched_tokens=2048, gpu_memory_utilization=0.5)
    torch.cuda.synchronize()
    init_seconds = time.perf_counter() - start
    for _ in range(2):
        llm.generate([[42] * 64], SamplingParams(temperature=0.6, max_tokens=8, ignore_eos=True), use_tqdm=False)
    runs = []
    for repeat in range(a.repeats):
        # 各配置使用相同 seeds。各轮使用不同前缀，避免重复运行变成 prefix-hit 测试。
        rng = random.Random(20260906 + repeat)
        prompts = [[rng.randint(100, 10000) for _ in range(a.input_len)] for _ in range(a.seqs)]
        params = SamplingParams(temperature=0.6, max_tokens=a.output_len, ignore_eos=True)
        torch.cuda.synchronize()
        torch.cuda.reset_peak_memory_stats()
        start = time.perf_counter()
        out = llm.generate(prompts, params, use_tqdm=False)
        torch.cuda.synchronize()
        elapsed = time.perf_counter() - start
        tokens = sum(len(row['token_ids']) for row in out)
        assert tokens == a.seqs * a.output_len
        runs.append(dict(seconds=elapsed, output_tokens=tokens, tokens_per_second=tokens / elapsed,
                         peak_allocated_rank0=torch.cuda.max_memory_allocated(),
                         peak_reserved_rank0=torch.cuda.max_memory_reserved()))
    print(json.dumps(dict(config=vars(a), gpu_rank0=torch.cuda.get_device_name(0),
                          torch_version=torch.__version__, cuda=torch.version.cuda,
                          init_seconds=init_seconds,
                          kv_blocks_rank0=llm.model_runner.config.num_kvcache_blocks,
                          median_tokens_per_second=statistics.median(r['tokens_per_second'] for r in runs),
                          runs=runs), indent=2))


if __name__ == '__main__':
    main()
