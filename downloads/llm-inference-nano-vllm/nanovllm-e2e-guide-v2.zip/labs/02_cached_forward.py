"""固定 token 路径，对比 Transformers 全上下文与 KV cache 前向；需模型权重。"""
import argparse
import json
import statistics
import time
import torch
from transformers import AutoModelForCausalLM, AutoTokenizer


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--model', required=True)
    p.add_argument('--prompt-len', type=int, default=64)
    p.add_argument('--steps', type=int, default=8)
    p.add_argument('--repeats', type=int, default=3)
    p.add_argument('--device', choices=['cpu', 'cuda'], default='cuda')
    a = p.parse_args()
    assert a.prompt_len > 0 and a.steps >= 2 and a.repeats > 0
    device = torch.device(a.device)
    dtype = torch.bfloat16 if a.device == 'cuda' else torch.float32
    tokenizer = AutoTokenizer.from_pretrained(a.model)
    model = AutoModelForCausalLM.from_pretrained(a.model, torch_dtype=dtype).to(device).eval()
    seed_ids = tokenizer.encode('The sky is blue and the river is calm. ', add_special_tokens=False)
    assert seed_ids
    n = a.prompt_len + a.steps - 1
    ids = torch.tensor((seed_ids * (n // len(seed_ids) + 1))[:n], device=device)[None, :]
    assert n <= model.config.max_position_embeddings

    def sync():
        if a.device == 'cuda':
            torch.cuda.synchronize()

    @torch.inference_mode()
    def run(use_cache):
        past = None
        logits, times, widths = [], [], []
        for i in range(a.steps):
            end = a.prompt_len + i
            inp = ids[:, :end] if i == 0 or not use_cache else ids[:, end - 1:end]
            sync()
            start = time.perf_counter()
            out = model(input_ids=inp, past_key_values=past, use_cache=use_cache)
            sync()
            times.append(time.perf_counter() - start)
            past = out.past_key_values if use_cache else None
            widths.append(inp.shape[1])
            # 拷回 CPU 用于正确性比较；拷贝时间不计入 forward 时间。
            logits.append(out.logits[:, -1, :].detach().float().cpu())
        return torch.cat(logits), times, widths

    for _ in range(2):
        run(False)
        run(True)
    samples = {False: [], True: []}
    last = {}
    for repeat in range(a.repeats):
        for cached in ([False, True] if repeat % 2 == 0 else [True, False]):
            last[cached] = run(cached)
            samples[cached].append(sum(last[cached][1][1:]))
    base, cache = last[False][0], last[True][0]
    delta = cache - base
    result = {
        'device': str(device), 'dtype': str(dtype),
        'input_widths_no_cache': last[False][2],
        'input_widths_cache': last[True][2],
        'forward_input_tokens_no_cache': sum(last[False][2]),
        'forward_input_tokens_cache': sum(last[True][2]),
        'decode_forward_seconds_median_no_cache': statistics.median(samples[False]),
        'decode_forward_seconds_median_cache': statistics.median(samples[True]),
        'max_abs_logit_error': delta.abs().max().item(),
        'relative_l2_logit_error': (delta.norm() / base.norm().clamp_min(1e-12)).item(),
        'same_top1_steps': int((base.argmax(-1) == cache.argmax(-1)).sum()),
        'steps': a.steps,
    }
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
