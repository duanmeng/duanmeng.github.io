# Run: source "$HOME/llm-inference-lab/env.sh". This file does not activate a venv.
export LAB_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
export NANO_COMMIT=bb823b3e06983d71485a8e1f23715ebd87d98ef8
export MODEL_REV=c1899de289a04d12100db370d81485cdf75e47ca
export NANO_DIR="$LAB_ROOT/nano-vllm"
export MODEL_DIR="$LAB_ROOT/models/Qwen3-0.6B"
export PYTHONUNBUFFERED=1
mkdir -p "$LAB_ROOT/runs" "$LAB_ROOT/notes" "$LAB_ROOT/models"
set -o pipefail
