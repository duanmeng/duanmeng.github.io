# 18. 两周学习计划：从环境准备到实验验收（E2E 操作手册）

本章是一份可以从零跟做的实验手册。主线为：准备目录与环境 → 前 5 天建立推理原理 → 第 6 天跑通模型 → 第 7–11 天用日志解读 nano-vLLM → 第 12–13 天做性能与多卡对照 → 第 14 天提交证据报告。每天约 60–90 分钟；首次下载、编译和 GPU 排队另计。

**配套附件：nanovllm-e2e-guide-v2.zip。**请下载下面的附件；包含本章完整离线版 README.md、原有 4 个实验脚本、分词/原理练习、源码导航、日志验收器、环境检查与报告生成工具。Day 7 的 trace 脚本增加了可选形状 hook。无需再下载第 15 章的旧实验包。

**验证边界：**文中的“预期值”是验收目标。CPU 原理练习和真实 Scheduler/BlockManager 的 CPU 测试已在写作机器验证；GPU 安装、模型 forward、CUDA Graph 与 TP 命令已对照固定源码检查，但写作机器没有 NVIDIA GPU，未把这些结果标成实测。附件 VALIDATION.md 记录具体覆盖范围。

## 18.0 开始前：目录、设备、版本与执行约定

**步骤 1｜准备机器并下载附件。**完整路线使用 Linux x86_64、Ampere/Ada/Hopper NVIDIA GPU；推荐独占 A100/A800/H100/H800，显存至少 24 GB、主机内存至少 32 GB、磁盘至少 30 GB。驱动建议 550.54.15 或更新。Day 1–5 及标明“CPU”的推演可在普通 Linux/macOS 完成；没有 GPU 时，GPU 验收保持“未运行”。本指南不包含 GPU 资源申请、驱动或 Docker 的管理员安装。

在飞书点击附件下载。若浏览器在本机、实验在远端，先把文件传过去；下面的 user@gpu-host 要换成自己的登录地址。后续主线路径统一为执行环境中的 $HOME/llm-inference-lab。

```bash
# 仅远端实验需要：在下载附件的电脑运行
scp "$HOME/Downloads/nanovllm-e2e-guide-v2.zip" user@gpu-host:~/
ssh user@gpu-host

# 在实验机运行；本机实验时将 ZIP 改为实际下载路径
mkdir -p "$HOME/llm-inference-lab"
unzip "$HOME/nanovllm-e2e-guide-v2.zip" -d "$HOME/llm-inference-lab"
cd "$HOME/llm-inference-lab"
ls README.md env.sh e2e labs
```

**步骤 2｜确定 GPU 工具链。**主线使用 CUDA 12.4.1 devel 环境。已具备 Linux + CUDA 12.4 nvcc + C++ 编译器时直接跳到步骤 3；否则，在已有 Docker 和 NVIDIA Container Toolkit 的 GPU 宿主机执行下面命令。后续步骤都在这个容器中运行。容器不随退出删除，宿主机的附件目录会保存所有输出。

```bash
# 在 GPU 宿主机，先确认驱动和 GPU 可见
nvidia-smi
docker run --gpus all --ipc=host --name nanovllm-e2e   -it -v "$HOME/llm-inference-lab:/root/llm-inference-lab"   nvidia/cuda:12.4.1-devel-ubuntu22.04 bash

# 以下在容器内执行（容器默认 root）
apt-get update
apt-get install -y ca-certificates curl git unzip build-essential
nvidia-smi
nvcc --version

# 以后退出后重进：在宿主机执行 docker start -ai nanovllm-e2e
# 容器仍在运行时另开终端：docker exec -it nanovllm-e2e bash
```

**步骤 3｜安装独立 Python 3.11.11 与 CPU 环境。**下面固定 uv 版本，仅安装到实验目录并创建虚拟环境，不替换系统 Python。使用容器时在容器内执行；纯 CPU 路线在自己的 Linux/macOS 终端执行。不要把在 macOS 创建的虚拟环境直接搬进 Linux。

```bash
source "$HOME/llm-inference-lab/env.sh"
cd "$LAB_ROOT"
mkdir -p tools
case "$(uname -s)-$(uname -m)" in
  Linux-x86_64) UV_BUILD=uv-x86_64-unknown-linux-gnu ;;
  Darwin-arm64) UV_BUILD=uv-aarch64-apple-darwin ;;
  Darwin-x86_64) UV_BUILD=uv-x86_64-apple-darwin ;;
  *) echo "本指南未覆盖此平台"; return 1 2>/dev/null || exit 1 ;;
esac
curl -fL --retry 3   "https://github.com/astral-sh/uv/releases/download/0.6.9/$UV_BUILD.tar.gz"   -o tools/uv.tar.gz
tar -xzf tools/uv.tar.gz -C tools
"tools/$UV_BUILD/uv" python install 3.11.11
"tools/$UV_BUILD/uv" venv --seed --python 3.11.11 .venv-cpu
source .venv-cpu/bin/activate
python -m pip install -r requirements-cpu.txt
python --version
python -m pip check
python e2e/final_report.py --root "$LAB_ROOT" --init-notes
```

看到 Python 3.11.11、pip check 没有依赖冲突，并生成 notes/day01.md–day14.md 后再继续。requirements-cpu.txt 固定 NumPy 1.26.4、Transformers 4.57.1、tokenizers 0.22.1、huggingface-hub 0.36.0、safetensors 0.6.2、xxhash 3.5.0 与 Jinja2 3.1.6。后续 GPU 环境另建，避免和 vLLM 的依赖互相覆盖。

**步骤 4｜下载固定源码和分词配置。**本章始终使用 nano-vLLM 提交 bb823b3e06983d71485a8e1f23715ebd87d98ef8（0.2.0）与 Qwen/Qwen3-0.6B revision c1899de289a04d12100db370d81485cdf75e47ca。先只下载分词/模型配置；第 6 天再下载权重。下载失败重跑同一命令，不要换到未固定的 main 分支。

```bash
source "$HOME/llm-inference-lab/env.sh"
cd "$LAB_ROOT"
source ".venv-cpu/bin/activate"
mkdir -p "$NANO_DIR"
curl -fL --retry 3   "https://codeload.github.com/GeeeekExplorer/nano-vllm/tar.gz/$NANO_COMMIT"   -o nano-vllm-source.tar.gz
tar -xzf nano-vllm-source.tar.gz -C "$NANO_DIR" --strip-components=1
python e2e/source_walk.py verify --repo "$NANO_DIR" | tee runs/source-version.txt
python e2e/download_model.py --model "$MODEL_DIR" | tee runs/tokenizer-download.log
python -m pip freeze > runs/cpu-environment.txt
```

**执行与记录约定：**每个日任务都从 source env.sh、进入目录、激活环境开始，可以关闭终端后重新接上。env.sh 启用 pipefail；带 tee 的命令要正常结束且没有 Traceback 才算成功。runs/ 保存实际输出，notes/dayNN.md 保存你的预测和解释；原样保留“未运行”项目。不要用带 trace 的程序测性能。nano 固定使用 localhost:2333 和共享内存名 nanovllm，同一主机不要并发启动多个 nano 实验；TP=2 本身属于一个实验。

附件脚本有 --help。principles.py 是小型原理演示；cpu_scheduler.py 直接加载固定源码里的 Sequence/Scheduler/BlockManager，并提供合成的采样 token，不运行模型或 GPU；analyze.py 读取真正的运行日志，输出 JSON 验收与 TSV 状态表。PASS 仅覆盖脚本声明的断言，不能代替对性能和数值误差的解释。

## 18.1 Day 1：从文本、token 到采样概率

**今天的问题与阅读：**读第 1 章：token id、logits、softmax、生成循环。先回答“一个 token 一定是一个汉字吗”。

**步骤 1｜运行真实分词与教学采样。**脚本对一段固定中英文文本做 encode/decode，对人为给定的 [2,1,0] 做 softmax，并打印关闭 thinking 的 Qwen3 chat template。此处尚未加载模型权重，三个分数不是 Qwen3 的预测。

```bash
source "$HOME/llm-inference-lab/env.sh"
cd "$LAB_ROOT"
source ".venv-cpu/bin/activate"
python e2e/principles.py tokenizer --model "$MODEL_DIR" --out runs/day01-tokenizer.json
cat runs/day01-tokenizer.json
```

**步骤 2｜对照输出写记录。**打开 notes/day01.md，抄下真实 ids、token_pieces 和 decoded；看到单个中文 token piece 像乱码时，对照完整 decode，token 的内部字节表示不一定是独立可读字符。记录 chat_template_text 如何包含角色边界与生成提示。

**预期与验收：**decoded 与原文逐字相同；probabilities 约为 [0.66524,0.24473,0.09003]，greedy_index=0；随机采样频率接近概率但不要求完全相等。输出 check=PASS。补写两句：权重推理时通常固定，上下文/缓存随生成增长；greedy 每次取最大值，采样按分布抽取。**卡住时：**缺 tokenizer.json 就重跑 18.0 的分词下载；不要用不存在的模型路径继续。

## 18.2 Day 2：手算并验证一次因果 Attention

**今天的问题与阅读：**读第 2 章；今天用 Q=K=V=X 的单头教学矩阵，先预测修改未来位置会不会改变过去位置。

```bash
source "$HOME/llm-inference-lab/env.sh"
cd "$LAB_ROOT"
source ".venv-cpu/bin/activate"
python labs/01_attention_numpy.py | tee runs/day02-original.log
python e2e/principles.py attention --out runs/day02-attention.json
sed -n '1,150p' e2e/principles.py
```

**步骤 2｜手算最后一行。**X=[[1,0],[0,1],[1,1]]。写出 Q/K/V=[3,2]、score=[3,3]、output=[3,2]；最后一行 score=[1/√2,1/√2,2/√2]，softmax 后权重约 [0.2483,0.2483,0.5035]，加权输出约 [0.7517,0.7517]。把过程写入 notes/day02.md。

**步骤 3｜验证 mask 的作用。**同一脚本将最后一个位置改为 [9,-5]，分别保留和去掉 causal mask，自动对比前两个位置。**验收：**masked_earlier_delta=0，unmasked_earlier_delta>0（本输入约 8.15455），各行权重和为 1，check=PASS。能解释为什么不允许较早位置读取未来信息。**卡住时：**ModuleNotFoundError: numpy 说明没有激活 .venv-cpu 或安装未完成。

## 18.3 Day 3：逐轮分清“已知 token”和“已计算 KV”

**今天的问题与阅读：**读第 3 章前半部分及 Prefill/Decode 时序图。先在纸上预测 t1–t3 输入、t4–t6 输出需要几轮 forward。

```bash
source "$HOME/llm-inference-lab/env.sh"
cd "$LAB_ROOT"
source ".venv-cpu/bin/activate"
python e2e/principles.py timeline --out runs/day03-timeline.json
cat runs/day03-timeline.json
```

**步骤 2｜逐项核对三轮。**第 1 轮 Prefill 输入 t1,t2,t3，KV 覆盖 t1–t3，预测 t4；第 2 轮 Decode 输入 t4，KV 到 t4，预测 t5；第 3 轮输入 t5，KV 到 t5，预测 t6。把 rounds 整理成“forward 输入 / KV 覆盖范围 / 刚输出 token”三列表。

**验收：**每轮 known_token_count=kv_count+1；第一轮输入宽度 3，后两轮各 1；check=PASS。能回答“输出 t4 时为什么还没有 t4 的 KV”。这是符号推演，不是模型实测。**卡住时：**若把新输出 token 立刻算进 KV，回到生成循环，区分 forward 与采样这两个动作。

## 18.4 Day 4：用两个路径验证 KV cache 省了哪些计算

**今天的问题与阅读：**读第 3 章后半部分；今天先验证数学等价，第 6 天再用真实模型对比。

```bash
source "$HOME/llm-inference-lab/env.sh"
cd "$LAB_ROOT"
source ".venv-cpu/bin/activate"
python e2e/principles.py cache --out runs/day04-cache.json
python labs/01_attention_numpy.py | tee runs/day04-numpy.log
```

**步骤 2｜核对输入位置数。**S=64、生成 G=8 时，不缓存路径的每轮输入是 64–71，求和 540；缓存路径是 [64,1,1,1,1,1,1,1]，求和 71。脚本用同一固定输入比较“完整重算最后位置”与“只算新 query 并读取历史 K/V”。

**验收：**max_error=0 或浮点舍入量级，full_last 与 cached_last 一致，位置总数为 540/71，check=PASS。在 notes/day04.md 写清：历史 K/V 仍被读取；历史 Q 通常不需缓存；540÷71 不是 GPU 提速倍数。**卡住时：**不要比较两次独立随机生成的文本来判断缓存正确性，必须固定输入 token 路径。

## 18.5 Day 5：算显存并区分 TTFT、TPOT 与吞吐

**今天的问题与阅读：**读第 4 章。今天所有数字都是估算或教学时间戳，尚无 GPU 性能结论。

```bash
source "$HOME/llm-inference-lab/env.sh"
cd "$LAB_ROOT"
source ".venv-cpu/bin/activate"
python e2e/principles.py memory --out runs/day05-memory.json
cat "$MODEL_DIR/config.json"
```

**步骤 2｜从配置代入公式。**KV bytes/token=2(K/V)×28 层×8 KV heads×128 head_dim×2 bytes(BF16)=114688 bytes=112 KiB。单请求 4096 个已缓存位置=448 MiB，8 请求为 3.5 GiB；一个 256-token block 跨全层的 KV 为 28 MiB。权重、激活、工作区、Graph、块尾浪费需另计。

**步骤 3｜算一条教学时间线。**请求发出为 0 秒，收到四个 token 的时间是 [0.12,0.16,0.21,0.25] 秒：TTFT=120ms，ITL=[40,50,40]ms，TPOT=(250−120)/(4−1)≈43.33ms。写出“离线输出 token 总数 / generate 总耗时”的吞吐口径为何不同。

**验收：**day05-memory.json 中 112、448、28、3.5 均吻合，check=PASS；notes/day05.md 同时写出显存估算的假设和指标起止点。**卡住时：**先检查是否误用了 16 个 Q heads；KV 容量要用 8 个 KV heads，KiB/MiB 按 1024 换算。

## 18.6 Day 6：配置 GPU，完成第一次真实生成

**今天的问题与阅读：**读第 5–6 章：先区分 vLLM 的服务能力与 nano 的教学引擎；本章必做主线使用 nano。第 5 章的 vLLM 在线体验留作完成主线后的扩展。

**步骤 1｜检查工具链并新建 GPU 环境。**以下是明确指定的参考软件组合，不是已在写作机器通过的 GPU 镜像：Python 3.11.11、PyTorch 2.6.0+cu124、Triton 3.2.0、FlashAttention 2.7.4.post1、Transformers 4.57.1。FlashAttention 可能需要编译，耗时显著长于普通 pip 包。先看到 GPU 和 nvcc 12.4 再安装。

```bash
source "$HOME/llm-inference-lab/env.sh"
cd "$LAB_ROOT"
source ".venv-cpu/bin/activate"
nvidia-smi
nvcc --version
g++ --version
python -m venv .venv-nano
source .venv-nano/bin/activate
python -m pip install --upgrade pip
python -m pip install setuptools==80.9.0 wheel==0.45.1 packaging==24.2 ninja==1.11.1.3
python -m pip install torch==2.6.0 --index-url https://download.pytorch.org/whl/cu124
python -m pip install -r requirements-cpu.txt einops==0.8.1 psutil==7.0.0
MAX_JOBS=4 python -m pip install flash-attn==2.7.4.post1 --no-build-isolation
python -m pip install --no-deps --no-build-isolation -e "$NANO_DIR"
python -m pip check
python -m pip freeze > runs/gpu-environment.txt
CUDA_VISIBLE_DEVICES=0 python e2e/doctor.py | tee runs/day06-doctor.json
python e2e/download_model.py --model "$MODEL_DIR" --weights | tee runs/weights-download.log
```

**步骤 2｜先验证短生成。**smoke.py 使用 chat template、单卡 eager、max_model_len=1024、token budget=512、gpu_memory_utilization=0.5，并设置 ignore_eos=True 强制生成 2 token。不要以这 2 token 是否组成完整回答作为验收。

```bash
source "$HOME/llm-inference-lab/env.sh"
cd "$LAB_ROOT"
source ".venv-nano/bin/activate"
CUDA_VISIBLE_DEVICES=0 python e2e/smoke.py --model "$MODEL_DIR" 2>&1 | tee runs/day06-smoke.log
CUDA_VISIBLE_DEVICES=0 python labs/02_cached_forward.py   --model "$MODEL_DIR" --device cuda --prompt-len 64 --steps 8 --repeats 3   2>&1 | tee runs/day06-cached-forward.log
python e2e/analyze.py cache --log runs/day06-cached-forward.log --out runs/day06-cache-check.json
```

**预期与验收：**doctor 输出 check=PASS；smoke 返回 1 个结果、2 个 token id、正数 kv_blocks；真实模型 cache 对照仍为 540/71，数值误差为有限值。记录 max_abs_logit_error、relative_l2_logit_error、same_top1_steps 及两条 decode 时间；BF16 不强求逐位相等，分析器的 PASS 不等于已证明所有误差都可接受。若 top-1 不一致或误差异常，先保留原始结果，单独排查，不写“等价已通过”。

**卡住时按顺序处理：**CUDA 不可用先检查容器 GPU 挂载和驱动；没有 nvcc 时回到 18.0 的 devel 环境；flash-attn 出现 undefined symbol 时确认 torch=2.6.0+cu124 后，用 MAX_JOBS=2 python -m pip install --force-reinstall --no-deps --no-cache-dir --no-build-isolation flash-attn==2.7.4.post1 重装；编译被 Killed 时先降低 MAX_JOBS 并检查主机内存。KV blocks 断言或 OOM 时先看 nvidia-smi，停止自己占用的其他实验，再在独占设备重跑；不要直接杀别人的进程。

## 18.7 Day 7：从日志还原两条请求的一生

**今天的问题与阅读：**读第 7 章，重点 add_request、step、generate、Sequence.append_token。今天启用形状 hook，日志同时留给第 11 天使用。

**步骤 1｜预测后运行。**两条请求输入长 64/96，输出限制为 2/3，ignore_eos=True。先在 notes/day07.md 写下每轮哪些请求还活跃，再运行：

```bash
source "$HOME/llm-inference-lab/env.sh"
cd "$LAB_ROOT"
source ".venv-nano/bin/activate"
python e2e/source_walk.py engine --repo "$NANO_DIR" > runs/day07-source.txt
CUDA_VISIBLE_DEVICES=0 python labs/03_trace_nanovllm.py   --model "$MODEL_DIR" --case lifecycle --shapes 2>&1 | tee runs/day07-lifecycle.log
python e2e/analyze.py lifecycle --log runs/day07-lifecycle.log --out runs/day07-check.json
cat runs/day07-check.tsv
```

**步骤 2｜按同一个 id 读四种事件。**before_schedule 看队列；scheduled 看本轮 cached/scheduled/blocks；gpu_inputs 看送进 GPU 的输入；after_postprocess 看 token 接受、状态变化和资源回收。seq_id 因 warmup 而变化，不要假定从 0 起；物理块 id 也不固定。

**预期与验收：**三轮依次 Prefill、Decode、Decode；首次 postprocess 后 total=65/97，cached=64/96；短请求先完成，最终输出长 2/3。结束时 cached=0、blocks=[] 是 deallocate 的结果；未完成请求通常 total=cached+1。day07-check.json 为 PASS，TSV 能逐行解释。**卡住时：**分析器报告缺事件先检查原始 log 的 Traceback，不要手工补 JSON。

## 18.8 Day 8：验证分块 Prefill 与抢占顺序

**今天的问题与阅读：**读第 8 章 schedule、preempt、postprocess。先手写 700/32 token 输入在 budget=512 下的前三轮选择。

```bash
source "$HOME/llm-inference-lab/env.sh"
cd "$LAB_ROOT"
source ".venv-nano/bin/activate"
python e2e/source_walk.py scheduler --repo "$NANO_DIR" > runs/day08-source.txt
CUDA_VISIBLE_DEVICES=0 python labs/03_trace_nanovllm.py   --model "$MODEL_DIR" --case chunk 2>&1 | tee runs/day08-chunk.log
python e2e/analyze.py chunk --log runs/day08-chunk.log --out runs/day08-check.json
cat runs/day08-check.tsv
```

**预期观察：**第 1 轮只处理 A 的 512 个位置，total 仍为 700、cached 变为 512；中间 chunk 虽有采样结果，postprocess 不接受为输出。第 2 轮处理 A 的 188+B 的 32=220，cu_q=[0,188,220]、cu_k=[0,700,732]；第 3 轮进入 Decode。分析器输出 PASS。

**步骤 2｜用 CPU 精确触发抢占。**教学 block size=4、共 4 块，A/B/C 各 4 token；首轮占 3 块并各采样 1 token。Decode 时 A 获得最后一块，B 需要扩块，于是从 running 尾部抢占 C。这个受控例子直接执行真实 Scheduler，不依赖把 GPU 显存耗尽。

```bash
source "$HOME/llm-inference-lab/env.sh"
cd "$LAB_ROOT"
source ".venv-cpu/bin/activate"
python e2e/cpu_scheduler.py preempt --repo "$NANO_DIR" --out runs/day08-preempt.json
```

**验收：**selected 是 A/B，waiting 是 C，C.cached=0、blocks=[]，check=PASS。notes/day08.md 解释 C 保留了 token 序列，重新入场要用 Prefill 重建已被释放的 KV。CPU 教学块大小 4 不能直接传给真实 nano Config，真实路径要求 256 的倍数。

## 18.9 Day 9：从逻辑位置算到真实 cache slot

**今天的问题与阅读：**读第 9 章与 prepare_prefill/prepare_decode 的 slot 公式。

```bash
source "$HOME/llm-inference-lab/env.sh"
cd "$LAB_ROOT"
source ".venv-cpu/bin/activate"
python e2e/source_walk.py blocks --repo "$NANO_DIR" > runs/day09-source.txt
python e2e/principles.py slots --out runs/day09-slots.json
python e2e/analyze.py slots --log runs/day07-lifecycle.log --out runs/day09-real-slots.json
```

**步骤 2｜先算教学例，再对照真实日志。**B=4、block_table=[17,5,23]，位置 0/6/8 对应 slot 68/22/92。统一公式为 block_table[position//B]×B+position%B。真实实验 B=256，分析器使用每个 scheduled 事件的 block_table 重算各轮前 8 个 slot，与 gpu_inputs 逐个相等才 PASS。

**步骤 3｜解释边界。**长度 255/256/257 对应 1/1/2 个逻辑块；采样出第 257 个 token 时该 token 的 KV 尚未计算，下一轮 forward 前才需 may_append 分配新块。**验收：**两个 JSON 均 PASS，并在 notes/day09.md 写出逻辑块、物理块、块内偏移的区别。无 GPU 日志时只完成教学计算，真实 slot 项保持未运行。

## 18.10 Day 10：验证 512-token 前缀命中与引用计数

**今天的问题与阅读：**读第 10 章，重点 can_allocate、hash_blocks、allocate/deallocate。

**步骤 1｜执行先 A 后 B 的受控前缀实验。**A/B 长度都为 620，前 512 token 相同、后 108 不同。A 完全生成结束后再提交 B；这与两个请求同时首次入队不同。

```bash
source "$HOME/llm-inference-lab/env.sh"
cd "$LAB_ROOT"
source ".venv-nano/bin/activate"
CUDA_VISIBLE_DEVICES=0 python labs/03_trace_nanovllm.py   --model "$MODEL_DIR" --case prefix 2>&1 | tee runs/day10-prefix.log
python e2e/analyze.py prefix --log runs/day10-prefix.log --out runs/day10-check.json
cat runs/day10-check.tsv
```

**预期观察：**prefix_second_request 后 B 首次 scheduled 为 cached=512、scheduled=108；GPU 的 cu_q=[0,108]、cu_k=[0,620]，positions 从 512 开始，block_tables 非空。由此解释“本轮只算 108 个 query，却读到 620 个位置的 K/V”。

**步骤 2｜执行 CPU 引用计数实验。**同样调用固定源码 BlockManager，受控登记完整块的 hash，再执行释放、重新激活、并发共享、逐个释放；这里没有计算真正 KV 张量。

```bash
source "$HOME/llm-inference-lab/env.sh"
cd "$LAB_ROOT"
source ".venv-cpu/bin/activate"
python e2e/cpu_scheduler.py refs --repo "$NANO_DIR" --out runs/day10-refs.json
```

**验收：**两个共享块的 ref_count 依次 [0,0]→[1,1]→[2,2]→[1,1]→[0,0]；620 长度命中 2 块，恰好 512 长度最多检查并命中 1 块（can_allocate 使用 range(num_blocks−1)）。两项均 PASS。notes/day10.md 解释 ref_count=0 不代表 GPU 显存池已归还，也不代表 hash 立即失效；旧块被重新分配覆盖时会清理旧映射。

## 18.11 Day 11：把 Runner 元数据接到真实模型形状

**今天的问题与阅读：**读第 11–12 章。今天复用第 7/10 天的 GPU 日志，不必重复初始化模型。

```bash
source "$HOME/llm-inference-lab/env.sh"
cd "$LAB_ROOT"
source ".venv-cpu/bin/activate"
python e2e/source_walk.py runner --repo "$NANO_DIR" > runs/day11-runner-source.txt
python e2e/source_walk.py model --repo "$NANO_DIR" > runs/day11-model-source.txt
python e2e/principles.py shapes --tp 1 --out runs/day11-static.json
python e2e/analyze.py runner --log runs/day07-lifecycle.log --out runs/day11-runner.json
python e2e/analyze.py shapes --log runs/day07-lifecycle.log --out runs/day11-shapes.json
cat runs/day10-check.json
```

**步骤 2｜对照三组元数据。**lifecycle Prefill 的 input_shape=[160]，cu_q/cu_k 都是 [0,64,160]，没有历史 block_tables；首次 Decode 输入 [2]，positions=[64,96]、context_lens=[65,97]；prefix 的 query=108、key=620，需从页表读取历史缓存。

**步骤 3｜核对 layer 0 的 hook。**首次 Prefill：qkv_proj 输出 [160,4096]；Q=[160,16,128]，K/V=[160,8,128]；o_proj 回到 [160,1024]；gate_up=[160,6144]；down_proj=[160,1024]；LM Head 的 logits=[2,151936]。T=160 是输入位置数，N=2 是本轮序列数；Prefill 在 LM Head 中挑每条序列的最后位置。首次 Decode 的 qkv 输出 [2,4096]。

**步骤 4｜定位权重如何装进去。**在 day11-model-source.txt 搜 packed_modules_mapping、load_model，再读 layers/linear.py 的 QKVParallelLinear.weight_loader。TP=1 时 Q/K/V 分别写入 qkv 权重的行区间 [0,2048)、[2048,3072)、[3072,4096)。不是把 hidden_size=1024 简单乘三得到 3072。**验收：**三个 JSON 均 PASS，在 notes/day11.md 记录一条真实形状与对应源码函数。如果提示缺 model_shape，用第 7 天的 --shapes 命令重跑日志。

## 18.12 Day 12：完成 eager 与 CUDA Graph 的可比较实验

**今天的问题与阅读：**读第 13 章 Attention.forward、store_kvcache_kernel、run_model、capture_cudagraph。今天启用不带 trace/hook 的 benchmark。

**步骤 1｜两个独立进程顺序运行。**固定 16 请求、输入 128 token、输出 32 token，ignore_eos=True，每轮应有 512 输出 token。正式测量前预热 2 次，测量 3 次；两组只改 enforce_eager。运行期间保持同一 GPU、没有其他负载。

```bash
source "$HOME/llm-inference-lab/env.sh"
cd "$LAB_ROOT"
source ".venv-nano/bin/activate"
python e2e/source_walk.py kernels --repo "$NANO_DIR" > runs/day12-source.txt
CUDA_VISIBLE_DEVICES=0 python labs/04_benchmark_nanovllm.py   --model "$MODEL_DIR" --eager --seqs 16 --max-num-seqs 32   --input-len 128 --output-len 32 --repeats 3 2>&1 | tee runs/day12-eager.log
CUDA_VISIBLE_DEVICES=0 python labs/04_benchmark_nanovllm.py   --model "$MODEL_DIR" --seqs 16 --max-num-seqs 32   --input-len 128 --output-len 32 --repeats 3 2>&1 | tee runs/day12-graph.log
python e2e/analyze.py compare --variable eager   --log runs/day12-eager.log --other runs/day12-graph.log --out runs/day12-comparison.json
```

**步骤 2｜读结果与源代码。**分别记 init_seconds、三轮吞吐、median_tokens_per_second 和 KV block 数；比较文件给出 Graph/eager 的吞吐比。定位 graph_bs=[1,2,4,8,16,32]：batch=9 选择 16 桶，填充的 slot_mapping=-1 使 KV 写入 kernel 跳过；Graph 捕获主要是 Decode 的 model forward，LM Head 与采样在捕获外。

**验收：**每轮 output_tokens=512、配置仅 eager 不同、分析器 PASS。写一条带设备、软件、负载、重复次数和实际数字的结论；Graph 没变快也可以完成验收，不能删掉不符合预期的轮次。该指标是包含 Prefill/Decode 的离线输出吞吐，不是 TTFT 或 TPOT。**卡住时：**先确认第 6 天 eager smoke 成功；Graph 初始化失败保留日志，本日标未完成；小于 16 的 max_num_seqs 不属于本实验覆盖范围，不随意改桶参数。

## 18.13 Day 13：先推导 Tensor Parallel，再按设备选做多卡

**今天的问题与阅读：**读第 14 章；TP 形状推导为必做，实际 TP=2 需要同机两张兼容 GPU。

```bash
source "$HOME/llm-inference-lab/env.sh"
cd "$LAB_ROOT"
source ".venv-cpu/bin/activate"
python e2e/source_walk.py tp --repo "$NANO_DIR" > runs/day13-source.txt
python e2e/principles.py shapes --tp 2 --out runs/day13-static.json
```

**步骤 2｜核对每张卡的形状。**TP=2 时每 rank 有 8 个 Q heads、4 个 KV heads；qkv 输出宽度 2048；o_proj 输入宽度 1024，其输出虽为 [T,1024]，仍只是部分和，需要 all-reduce；gate_up 宽度 3072，down_proj 输入宽度 1536；词表切为每卡 75968，logits gather 到 rank 0。KV 每 token 每 rank 56 KiB；两卡总和仍为 112 KiB。

**步骤 3｜有两卡再做性能对照。**以下两条命令也必须顺序运行，参数保持一致；两组仅改变 TP。终端 B 可用 nvidia-smi -l 1 观察每卡占用，用 Ctrl+C 结束观察。benchmark 的 peak 字段仅来自 rank 0，不能据此声称多卡总显存。

```bash
source "$HOME/llm-inference-lab/env.sh"
cd "$LAB_ROOT"
source ".venv-nano/bin/activate"
CUDA_VISIBLE_DEVICES=0 python labs/04_benchmark_nanovllm.py   --model "$MODEL_DIR" --eager --tp 1 2>&1 | tee runs/day13-tp1.log
CUDA_VISIBLE_DEVICES=0,1 python labs/04_benchmark_nanovllm.py   --model "$MODEL_DIR" --eager --tp 2 2>&1 | tee runs/day13-tp2.log
python e2e/analyze.py compare --variable tp   --log runs/day13-tp1.log --other runs/day13-tp2.log --out runs/day13-comparison.json
```

**验收：**day13-static.json 为 PASS；在 notes/day13.md 标“静态推演”或“含双卡实测”。若实测，比较文件应 PASS，并解释小模型 TP=2 可能受通信开销影响而变慢。SharedMemory 传递方法名和序列控制元数据，模型张量通信走 NCCL。**卡住时：**NCCL 等待时先检查可见 GPU 数、两卡是否可用和前一实验是否退出，不要并发重试制造更多进程。没有双卡则跳过步骤 3，无需伪造多卡结果。

## 18.14 Day 14：交付一份别人能复查的推理实验报告

**今天的问题与阅读：**回看第 7 章总链路与第 15–17 章实验/排障索引。今天验收的是解释与证据是否接得起来。

**步骤 1｜完成学习记录。**用任意文本编辑器打开 notes/day01.md–day14.md，将 TODO 换成自己的内容；未运行项目明确写“未运行及原因”，不要填预期数值代替观察。Day 14 写完整调用链 prompt → Sequence → Scheduler → BlockManager → Runner → Qwen3 → Sampler → postprocess，并给每一步标出一个源码函数或实际日志字段。

**步骤 2｜写三条有证据的结论。**至少覆盖缓存位置数、调度/前缀缓存、性能对照；每条注明实测/CPU 源码执行/静态估算、文件路径、具体数值与适用条件。另写一个只改变单一变量的后续实验设计，例如在线 TTFT；本章的离线 benchmark 不能直接给出在线 TTFT。

```bash
source "$HOME/llm-inference-lab/env.sh"
cd "$LAB_ROOT"
source ".venv-cpu/bin/activate"
python e2e/final_report.py --root "$LAB_ROOT"
cat runs/final-report.md
tar -czf learning-evidence.tar.gz   README.md VALIDATION.md env.sh requirements-cpu.txt e2e labs runs notes
```

**最终验收：**runs/final-report.md 列出 Day 1–13 必要输出是否存在、JSON 检查状态和文件摘要，Day 1–14 笔记是否仍有 TODO。完整单卡路线应无 MISSING/INVALID JSON，笔记无 TODO，evidence_and_notes_ready_for_review=true；此值只表示证据和笔记已就绪，仍需人工审核内容。无 GPU 路线允许报告保留 MISSING，结论明确停留在 CPU/静态范围。双卡实测为选学，不影响单卡路线完成。

把 learning-evidence.tar.gz 留存或交给同伴复查。随机抽一行调度 TSV，应能解释为什么选择这些序列、写到哪些 slot、模型输入形状是什么、为什么接收或忽略本轮 sampled token；再抽一条性能结论，应能找到原始日志、环境版本与测量口径。能做到这两点，才算把原理、源码和运行结果连起来。
