# 本实验包的验证范围

核对日期：2026-09-06。正文主线：Linux x86_64、Python 3.11.11、CUDA 12.4.1、PyTorch 2.6.0+cu124、FlashAttention 2.7.4.post1、Transformers 4.57.1。

## 实际执行过的部分

写作机器为 macOS ARM64，无 NVIDIA GPU。本地验证环境是 Python 3.14.5、NumPy 2.4.6；Transformers 4.57.1、tokenizers 0.22.1、huggingface-hub 0.36.0、safetensors 0.6.2、xxhash 3.5.0、Jinja2 3.1.6。这不是对上述 Linux GPU 软件组合的实跑认证。

- 固定模型 revision 的真实 tokenizer：encode/decode 一致；教学文本的 token IDs 为 [108386, 3837, 113272, 6313, 21927, 44378, 13]。
- NumPy 因果 Attention：masked_earlier_delta=0，unmasked_earlier_delta≈8.15455，最后位置输出≈[0.751745,0.751745]。
- 教学 KV cache 的最后位置等价；输入位置总数为 540/71。
- 符号 Prefill/Decode 时序、显存估算、slot 算术、TP=1/2 静态形状推导。
- 固定 nano 源码 Sequence/Scheduler/BlockManager 的 CPU 执行：抢占 running 尾部请求、清空其缓存状态；两个共享块引用计数 0→1→2→1→0；620/512 token 请求分别命中 2/1 块。
- 源码指纹覆盖 20 个 Python/项目配置文件。原实验 01 也实际执行通过。
- 全部 Python 文件语法检查，README 的 22 个 Bash 命令块语法检查，12 个被引用脚本存在性检查。
- 日志分析器用“真实 CPU 调度 + 人工构造 Runner 元数据”的明确标注测试数据验证；错误调度计数、截断日志与不可比较的 benchmark 配置均被拒绝。形状、cache 与 benchmark 解析器还使用了明确标注的合成数据。
- 报告生成器对缺失证据保持 MISSING；不会自动把空项目判成完成。

`verified_cpu/` 内只包含实际执行的 CPU 输出和验证摘要。合成 GPU/benchmark 解析测试数据不随包分发，不能作为任何 GPU 正确性或性能证据。

## 尚未实际执行的部分

- GPU 环境完整安装与 FlashAttention 编译。
- `doctor.py` 的 CUDA 检查，`smoke.py` 的真实模型生成。
- 实验 02 的真实权重 forward；实验 03 的 GPU trace/形状 hook；实验 04 的 eager/Graph/TP benchmark。
- 双卡 NCCL、显存测量，以及 vLLM 在线服务。
- uv 安装 Python 与 Hugging Face snapshot 下载助手的完整跨平台链路未在本地重走；已核对固定下载地址，分词配置通过固定 revision 单独下载并实测。

请运行正文命令保存自己的原始日志和 `pip freeze`。PASS 只表示对应脚本声明的结构检查通过；BF16 数值误差、速度结论和学习理解仍需按正文方法复核。不要以“合成输入的脚本自测通过”替代“真实 GPU 已运行”。
