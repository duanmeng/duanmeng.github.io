"""Print source with line numbers; no import of CUDA modules. Verify pinned files."""
import argparse
import hashlib
import json
from pathlib import Path

GROUPS = {
    "engine": ["engine/llm_engine.py", "engine/sequence.py"],
    "scheduler": ["engine/scheduler.py"],
    "blocks": ["engine/block_manager.py"],
    "runner": ["engine/model_runner.py", "utils/context.py"],
    "model": ["models/qwen3.py", "utils/loader.py"],
    "kernels": ["layers/attention.py", "engine/model_runner.py"],
    "tp": ["layers/linear.py", "layers/embed_head.py", "engine/model_runner.py"],
}


def main():
    p = argparse.ArgumentParser()
    p.add_argument("group", choices=["verify", *GROUPS])
    p.add_argument("--repo", required=True)
    a = p.parse_args()
    base = Path(a.repo)
    manifest = json.loads((Path(__file__).parent / "source-manifest.json").read_text())
    for rel, expected in manifest["sha256"].items():
        actual = hashlib.sha256((base / rel).read_bytes()).hexdigest()
        assert actual == expected, f"Source differs from pinned commit: {rel}"
    print("SOURCE PASS", manifest["commit"])
    if a.group != "verify":
        for rel in GROUPS[a.group]:
            file = base / "nanovllm" / rel
            print(f"\n{file}\n")
            for i, line in enumerate(file.read_text().splitlines(), 1):
                print(f"{i:4}: {line}")


if __name__ == "__main__":
    main()
