"""Inventory evidence and human conclusions without auto-filling unrun experiments."""
import argparse
import hashlib
import json
from pathlib import Path

REQUIRED={
    1:["day01-tokenizer.json"],2:["day02-attention.json"],3:["day03-timeline.json"],
    4:["day04-cache.json"],5:["day05-memory.json"],
    6:["day06-doctor.json","day06-smoke.log","day06-cache-check.json"],
    7:["day07-check.json"],8:["day08-check.json","day08-preempt.json"],
    9:["day09-slots.json","day09-real-slots.json"],
    10:["day10-check.json","day10-refs.json"],
    11:["day11-static.json","day11-runner.json","day11-shapes.json"],
    12:["day12-comparison.json"],13:["day13-static.json"],
}


def main():
    p=argparse.ArgumentParser()
    p.add_argument("--root",required=True)
    p.add_argument("--init-notes",action="store_true")
    a=p.parse_args()
    root=Path(a.root)
    notes=root/"notes"
    notes.mkdir(parents=True,exist_ok=True)
    if a.init_notes:
        for day in range(1,15):
            file=notes/f"day{day:02}.md"
            if not file.exists():
                file.write_text(f"# Day {day}\n\n状态：TODO（实测 / 静态推演 / 未运行）\n\n"
                                "预测：TODO\n\n命令与配置：TODO\n\n实际观察与日志路径：TODO\n\n"
                                "对应源码或公式：TODO\n\n结论及适用条件：TODO\n\n未解释的问题：TODO\n")
        print("Created missing notes only; existing notes preserved.")
        return
    rows=[]
    for day,files in REQUIRED.items():
        for name in files:
            f=root/"runs"/name
            state="MISSING"
            if f.exists() and f.stat().st_size:
                state="PRESENT"
                if f.suffix==".json":
                    try:
                        state="PASS" if json.loads(f.read_text()).get("check")=="PASS" else "REVIEW"
                    except json.JSONDecodeError:
                        state="INVALID JSON"
                elif name.endswith("smoke.log"):
                    from analyze import objects
                    state="PASS" if any(x.get("check")=="PASS" and x.get("scope")=="nano eager actual generation" for x in objects(f)) else "REVIEW"
            sha=hashlib.sha256(f.read_bytes()).hexdigest()[:12] if f.exists() else "-"
            rows.append((day,name,state,sha))
    lines=["# 两周学习证据报告","", "由实际文件生成；PASS 仅表示对应脚本的检查通过。数值等价、性能解释和学习理解仍需人工复盘。", "",
           "| Day | 文件 | 状态 | SHA256 前12位 |","|---|---|---|---|"]
    lines += [f"| {d} | runs/{n} | {s} | {h} |" for d,n,s,h in rows]
    lines += ["","## 学习记录检查",""]
    complete=True
    for day in range(1,15):
        f=notes/f"day{day:02}.md"
        status="需补充" if not f.exists() or "TODO" in f.read_text() else "已填写，待人工复核"
        if status=="需补充": complete=False
        lines.append(f"- Day {day}: {status}（notes/day{day:02}.md）")
    lines += ["","## 可选项与限制","", "- Day 13 的多卡实测为选学；静态形状结果不能证明 TP 性能。",
              "- 未运行的 GPU 项必须保持 MISSING，并在学习记录写明原因。",
              "- Day 6 cache-check 的 PASS 检查输入宽度和有限误差值，不自动判定 BF16 数值完全等价。",
              "- 所有 GPU 原始日志应与本报告一同保存。"]
    dest=root/"runs"/"final-report.md"
    dest.parent.mkdir(parents=True,exist_ok=True)
    dest.write_text("\n".join(lines)+"\n")
    ready=all(r[2]=="PASS" for r in rows) and complete
    print(json.dumps(dict(report=str(dest),evidence_and_notes_ready_for_review=ready,
                          missing_or_review=[n for _,n,s,_ in rows if s!="PASS"]),ensure_ascii=False,indent=2))


if __name__=="__main__":
    main()
