"""Single GPU eager smoke test; actual output text is not deterministic acceptance."""
import argparse
import json
import torch
from transformers import AutoTokenizer
from nanovllm import LLM, SamplingParams


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--model", required=True)
    a = p.parse_args()
    tok = AutoTokenizer.from_pretrained(a.model, local_files_only=True)
    prompt = tok.apply_chat_template([{"role":"user","content":"用一句话解释 KV cache。"}],
                                    tokenize=False, add_generation_prompt=True, enable_thinking=False)
    torch.manual_seed(0)
    llm = LLM(a.model, enforce_eager=True, tensor_parallel_size=1, max_model_len=1024,
              max_num_seqs=8, max_num_batched_tokens=512, gpu_memory_utilization=0.5)
    outputs = llm.generate([prompt], SamplingParams(temperature=0.6,max_tokens=2,ignore_eos=True),
                           use_tqdm=False)
    assert len(outputs) == 1 and len(outputs[0]["token_ids"]) == 2
    print(json.dumps(dict(check="PASS",scope="nano eager actual generation",outputs=outputs,
                         kv_blocks=llm.model_runner.config.num_kvcache_blocks),ensure_ascii=False))


if __name__ == "__main__":
    main()
