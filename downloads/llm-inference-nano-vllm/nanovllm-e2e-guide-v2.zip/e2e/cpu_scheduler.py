"""Run real pinned Scheduler/BlockManager on CPU, with supplied token IDs.

This is NOT LLM inference: no Runner, weights, CUDA, or attention kernels run.
The package namespace is isolated to avoid importing nanovllm.__init__ (CUDA).
Config is only a type annotation here; a SimpleNamespace supplies its fields.
"""
import argparse
import importlib.util
import json
import sys
import types
from pathlib import Path


def load_source(repo):
    root = Path(repo)
    for name in ["nanovllm", "nanovllm.engine"]:
        mod = types.ModuleType(name)
        mod.__path__ = []
        sys.modules[name] = mod
    cfg = types.ModuleType("nanovllm.config")
    cfg.Config = types.SimpleNamespace
    sys.modules[cfg.__name__] = cfg
    for rel in ["sampling_params", "engine.sequence", "engine.block_manager", "engine.scheduler"]:
        name = "nanovllm." + rel
        spec = importlib.util.spec_from_file_location(name, root / "nanovllm" / (rel.replace(".", "/") + ".py"))
        mod = importlib.util.module_from_spec(spec)
        sys.modules[name] = mod
        spec.loader.exec_module(mod)
    from nanovllm.engine.sequence import Sequence
    from nanovllm.sampling_params import SamplingParams
    from nanovllm.engine.scheduler import Scheduler
    from nanovllm.engine.block_manager import BlockManager
    return Sequence, SamplingParams, Scheduler, BlockManager


def state(s):
    return dict(id=s.seq_id, status=s.status.name, total=len(s), cached=s.num_cached_tokens,
                scheduled=s.num_scheduled_tokens, blocks=list(s.block_table))


def main():
    p = argparse.ArgumentParser()
    p.add_argument("case", choices=["preempt", "refs"])
    p.add_argument("--repo", required=True)
    p.add_argument("--out", required=True)
    a = p.parse_args()
    Seq, SP, Scheduler, BM = load_source(a.repo)
    if a.case == "preempt":
        Seq.block_size = 4  # CPU teaching size only; production Config requires multiples of 256.
        sched = Scheduler(types.SimpleNamespace(max_num_seqs=3, max_num_batched_tokens=12,
                          eos=-1, kvcache_block_size=4, num_kvcache_blocks=4))
        seqs = [Seq([100+i]*4, SP(max_tokens=8, ignore_eos=True)) for i in range(3)]
        for s in seqs:
            sched.add(s)
        selected, prefill = sched.schedule()
        assert prefill and len(selected) == 3
        sched.postprocess(selected, [1000,1001,1002], prefill)
        before = [state(s) for s in seqs]
        selected, prefill = sched.schedule()
        assert not prefill and [s.seq_id for s in selected] == [seqs[0].seq_id,seqs[1].seq_id]
        assert list(sched.waiting) == [seqs[2]]
        assert seqs[2].num_cached_tokens == 0 and not seqs[2].block_table
        result = dict(before_decode=before, selected=[state(s) for s in selected],
                      waiting=[state(s) for s in sched.waiting], victim="C (tail of running deque)",
                      free_blocks=len(sched.block_manager.free_block_ids))
    else:
        Seq.block_size = 256
        bm = BM(12,256)
        first = Seq([100]*512+[101]*108)
        bm.allocate(first, bm.can_allocate(first))
        first.num_scheduled_tokens = 620
        bm.hash_blocks(first)
        saved = first.block_table[:2]
        bm.deallocate(first)
        refs0 = [bm.blocks[b].ref_count for b in saved]
        b = Seq([100]*512+[102]*108)
        hit = bm.can_allocate(b)
        assert hit == 2
        bm.allocate(b,hit)
        refs1 = [bm.blocks[x].ref_count for x in saved]
        c = Seq([100]*512+[103]*108)
        bm.allocate(c,bm.can_allocate(c))
        refs2 = [bm.blocks[x].ref_count for x in saved]
        bm.deallocate(b)
        refs3 = [bm.blocks[x].ref_count for x in saved]
        bm.deallocate(c)
        refs4 = [bm.blocks[x].ref_count for x in saved]
        exact = Seq([100]*512)
        exact_hit = bm.can_allocate(exact)
        assert [refs0,refs1,refs2,refs3,refs4] == [[0,0],[1,1],[2,2],[1,1],[0,0]]
        assert exact_hit == 1
        result = dict(shared_blocks=saved, ref_counts_by_stage=[refs0,refs1,refs2,refs3,refs4],
                      hit_blocks_620=hit, hit_blocks_exact512=exact_hit,
                      explanation="hash registration simulated after supplied KV-work count; no KV tensor computed")
    result = dict(case=a.case, check="PASS", mode="CPU source execution, synthetic sampled IDs", **result)
    Path(a.out).parent.mkdir(parents=True, exist_ok=True)
    Path(a.out).write_text(json.dumps(result, indent=2)+"\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
