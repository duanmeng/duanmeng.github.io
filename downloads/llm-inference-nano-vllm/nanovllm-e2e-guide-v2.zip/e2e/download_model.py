"""Download the pinned public model; tokenizer first, weights only with --weights."""
import argparse
import json
from pathlib import Path
from huggingface_hub import snapshot_download

MODEL = "Qwen/Qwen3-0.6B"
REV = "c1899de289a04d12100db370d81485cdf75e47ca"


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--model", required=True)
    p.add_argument("--weights", action="store_true")
    a = p.parse_args()
    patterns = ["*.json", "*.txt", "*.model", "*.jinja"]
    if a.weights:
        patterns.append("*.safetensors")
    snapshot_download(MODEL, revision=REV, local_dir=a.model,
                      allow_patterns=patterns, max_workers=2)
    dest = Path(a.model)
    assert (dest / "config.json").is_file()
    assert (dest / "tokenizer.json").is_file()
    if a.weights:
        assert list(dest.glob("*.safetensors")), "No weights downloaded"
    record = {"repo": MODEL, "revision": REV, "weights_requested": a.weights}
    (dest / "download_record.json").write_text(json.dumps(record, indent=2))
    print(json.dumps({"check": "PASS", **record, "path": str(dest.resolve())}))


if __name__ == "__main__":
    main()
