"""Small inspectable CPU exercises. Toy computations are explicitly labeled."""
import argparse
import json
from pathlib import Path
import numpy as np


def softmax(x):
    e = np.exp(x - np.max(x, axis=-1, keepdims=True))
    return e / e.sum(axis=-1, keepdims=True)


def tokenizer(model):
    from transformers import AutoTokenizer
    t = AutoTokenizer.from_pretrained(model, local_files_only=True)
    text = "你好，推理！ Hello inference."
    ids = t.encode(text, add_special_tokens=False)
    restored = t.decode(ids, skip_special_tokens=False)
    assert restored == text
    prob = softmax(np.array([2., 1., 0.]))
    draws = np.random.default_rng(0).choice(3, 10000, p=prob)
    chat = t.apply_chat_template([{"role": "user", "content": "一句话解释 KV cache。"}],
                                 tokenize=False, add_generation_prompt=True,
                                 enable_thinking=False)
    return dict(mode="real tokenizer + toy logits (not model predictions)", text=text,
                ids=ids, token_pieces=t.convert_ids_to_tokens(ids), decoded=restored,
                toy_logits=[2, 1, 0], probabilities=prob.tolist(), greedy_index=int(prob.argmax()),
                sample_frequencies=(np.bincount(draws, minlength=3) / 10000).tolist(),
                chat_template_text=chat)


def attention():
    x = np.array([[1., 0.], [0., 1.], [1., 1.]])
    def run(z, causal):
        score = z @ z.T / np.sqrt(2)
        if causal:
            score = np.where(np.triu(np.ones(score.shape), 1).astype(bool), -np.inf, score)
        weight = softmax(score)
        return weight, weight @ z
    w, out = run(x, True)
    changed = x.copy()
    changed[-1] = [9., -5.]
    masked_delta = float(np.max(np.abs(out[:2] - run(changed, True)[1][:2])))
    unmasked_delta = float(np.max(np.abs(run(x, False)[1][:2] - run(changed, False)[1][:2])))
    assert masked_delta == 0 and unmasked_delta > 0
    np.testing.assert_allclose(w.sum(-1), 1)
    np.testing.assert_allclose(out[-1], [0.75174492, 0.75174492], atol=1e-7)
    return dict(mode="toy single-head attention, Q=K=V=X", X=x.tolist(),
                Q_shape=list(x.shape), score_shape=list(w.shape), weights=w.tolist(),
                output=out.tolist(), masked_earlier_delta=masked_delta,
                unmasked_earlier_delta=unmasked_delta)


def timeline():
    rows = []
    for step in range(3):
        rows.append(dict(round=step + 1, phase="prefill" if step == 0 else "decode",
                         forward_input=["t1", "t2", "t3"] if step == 0 else [f"t{step+3}"],
                         kv_after_forward=[f"t{i}" for i in range(1, step + 4)],
                         emitted=f"t{step+4}", kv_count=step+3, known_token_count=step+4))
    assert all(r["known_token_count"] == r["kv_count"] + 1 for r in rows)
    return dict(mode="symbolic generation timeline; no model executed", rounds=rows)


def cache():
    x = np.array([[1., 0.], [0., 1.], [1., 1.], [0., 2.]])
    score = x @ x.T / np.sqrt(2)
    score[np.triu_indices(4, 1)] = -np.inf
    full = (softmax(score) @ x)[-1]
    only_new_query = (softmax(x[-1:] @ x.T / np.sqrt(2)) @ x)[0]
    np.testing.assert_allclose(full, only_new_query, atol=1e-12)
    no_cache = list(range(64, 72))
    cached = [64] + [1] * 7
    assert sum(no_cache) == 540 and sum(cached) == 71
    return dict(mode="toy cache equivalence + input-position count", full_last=full.tolist(),
                cached_last=only_new_query.tolist(), max_error=float(np.max(np.abs(full-only_new_query))),
                no_cache_widths=no_cache, cache_widths=cached,
                no_cache_positions=sum(no_cache), cache_positions=sum(cached),
                note="Position count is not a measured speedup; historical KV is still read.")


def memory():
    per_token = 2 * 28 * 8 * 128 * 2
    result = dict(mode="estimate, not GPU measurement", kv_bytes_per_token=per_token,
                  kv_KiB_per_token=per_token/1024,
                  kv_MiB_4096_tokens=4096*per_token/2**20,
                  kv_MiB_per_256_block=256*per_token/2**20,
                  eight_requests_4096_tokens_GiB=8*4096*per_token/2**30,
                  example_token_arrival_seconds=[0.12, 0.16, 0.21, 0.25],
                  example_TTFT_ms=120, example_ITL_ms=[40, 50, 40],
                  example_TPOT_ms=(0.25-0.12)/3*1000)
    assert per_token == 114688 and result["kv_MiB_4096_tokens"] == 448
    return result


def slots():
    mapping = [{"position": p, "logical_block": p//4, "physical_block": [17,5,23][p//4],
                "offset": p%4, "slot": [17,5,23][p//4]*4+p%4} for p in [0,6,8]]
    assert [r["slot"] for r in mapping] == [68,22,92]
    return dict(mode="address arithmetic, not GPU memory access", block_size=4,
                block_table=[17,5,23], mapping=mapping,
                real_block_size=256, lengths=[255,256,257], blocks=[1,1,2],
                allocation_note="After sampling token 257, its KV is absent; allocate before its next forward.")


def shapes(tp):
    assert tp in (1, 2)
    q, kv, mlp = 16//tp, 8//tp, 3072//tp
    return dict(mode="static shape derivation, not multi-GPU execution", tp=tp, hidden=1024,
                q_heads_per_rank=q, kv_heads_per_rank=kv, head_dim=128,
                Q=["T",q,128], K_and_V=["T",kv,128],
                qkv_output_per_rank=q*128+2*kv*128,
                qkv_weight_per_rank=[q*128+2*kv*128,1024],
                packed_Q_rows=[0,q*128], packed_K_rows=[q*128,(q+kv)*128],
                packed_V_rows=[(q+kv)*128,(q+2*kv)*128],
                o_proj_input_per_rank=q*128, o_proj_partial_output=["T",1024],
                gate_up_per_rank=2*mlp, down_proj_input_per_rank=mlp,
                vocab_per_rank=151936//tp, logits_rank0=["N",151936],
                kv_KiB_per_token_per_rank=112/tp,
                collectives=["embedding all_reduce", "o_proj all_reduce",
                             "down_proj all_reduce", "LM head gather to rank 0"],
                graph_buckets_at_max32=[1,2,4,8,16,32], graph_bucket_for_batch9=16)


def main():
    p = argparse.ArgumentParser()
    p.add_argument("case", choices=["tokenizer","attention","timeline","cache","memory","slots","shapes"])
    p.add_argument("--model")
    p.add_argument("--tp", type=int, default=1)
    p.add_argument("--out", required=True)
    a = p.parse_args()
    if a.case == "tokenizer":
        p.error("tokenizer requires --model") if not a.model else None
        result = tokenizer(a.model)
    elif a.case == "shapes":
        result = shapes(a.tp)
    else:
        result = globals()[a.case]()
    result = {"case": a.case, "check": "PASS", **result}
    target = Path(a.out)
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n")
    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
