"""GPU dependency/ABI and device checks. No model weights are loaded."""
import importlib.metadata as md
import json
import platform
import subprocess
import sys
from pathlib import Path
import torch
import flash_attn
import triton
import transformers

assert sys.version_info[:2] == (3,11), "Use the guide's Python 3.11 GPU venv"
assert platform.system() == "Linux", "nano baseline is Linux/NVIDIA"
assert torch.cuda.is_available(), "CUDA unavailable: inspect nvidia-smi and installed torch wheel"
assert torch.cuda.is_bf16_supported(), "Baseline requires BF16-capable NVIDIA GPU"
assert torch.cuda.get_device_capability(0)[0] in (8,9), "Guide baseline: Ampere/Ada/Hopper"
x = torch.ones(8, device="cuda", dtype=torch.bfloat16)
assert float((x+x).sum()) == 16
torch.cuda.synchronize()
result = dict(check="PASS", scope="imports + small CUDA tensor; not model inference",
              python=sys.version, platform=platform.platform(), torch=torch.__version__,
              torch_cuda=torch.version.cuda, flash_attn=flash_attn.__version__,
              triton=triton.__version__, transformers=transformers.__version__,
              packages={k:md.version(k) for k in ["numpy","xxhash","safetensors","tokenizers"]},
              gpus=[dict(index=i,name=torch.cuda.get_device_name(i),
                         total_GiB=torch.cuda.get_device_properties(i).total_memory/2**30)
                    for i in range(torch.cuda.device_count())],
              nvidia_smi=subprocess.check_output(["nvidia-smi"],text=True))
print(json.dumps(result, indent=2))
