"""Turn actual logs into checked evidence. No GPU results are invented here."""
import argparse
import json
import math
import re
from pathlib import Path


def objects(path):
    text = Path(path).read_text()
    decoder = json.JSONDecoder()
    result, pos = [], 0
    while match := re.search(r"(?m)^\s*\{", text[pos:]):
        start = pos + match.start()
        start += len(text[start:]) - len(text[start:].lstrip())
        try:
            obj, end = decoder.raw_decode(text, start)
        except json.JSONDecodeError:
            pos = start+1
            continue
        result.append(obj)
        pos = end
    assert result, f"No JSON found in {path}; inspect the original log for errors"
    return result


def cycles(events):
    rows, active = [], None
    for event in events:
        if event.get("event") == "scheduled":
            assert active is None, "Previous step did not finish"
            active = {"scheduled": event}
        elif event.get("event") == "gpu_inputs" and active is not None:
            active["inputs"] = event
        elif event.get("event") == "after_postprocess":
            assert active is not None and "inputs" in active, "Incomplete step"
            active["after"] = event
            rows.append(active)
            active = None
    assert rows and active is None, "Missing or truncated trace"
    return rows


def check_lifecycle(rows):
    assert [r["scheduled"]["prefill"] for r in rows] == [True,False,False]
    assert [s["prompt"] for s in rows[0]["scheduled"]["seqs"]] == [64,96]
    assert [s["total"] for s in rows[0]["after"]["seqs"]] == [65,97]
    assert [s["cached"] for s in rows[0]["after"]["seqs"]] == [64,96]
    finished = [s for r in rows for s in r["after"]["seqs"] if s["status"]=="FINISHED"]
    assert sorted((s["prompt"],s["total"]-s["prompt"]) for s in finished)==[(64,2),(96,3)]
    assert all(s["cached"]==0 and s["blocks"]==[] for s in finished)
    return dict(phases=["prefill","decode","decode"], completed_output_lengths=[2,3])


def check_chunk(rows):
    first,second,third=rows[:3]
    assert [s["scheduled"] for s in first["scheduled"]["seqs"]]==[512]
    assert first["after"]["seqs"][0]["total"]==700
    assert first["after"]["seqs"][0]["cached"]==512
    assert [s["scheduled"] for s in second["scheduled"]["seqs"]]==[188,32]
    assert [s["total"] for s in second["after"]["seqs"]]==[701,33]
    assert third["scheduled"]["prefill"] is False
    assert first["inputs"]["cu_seqlens_q"]==[0,512]
    assert second["inputs"]["cu_seqlens_q"]==[0,188,220]
    assert second["inputs"]["cu_seqlens_k"]==[0,700,732]
    return dict(first_prefill_queries=512,second_prefill_queries=220,
                second_cu_q=[0,188,220],second_cu_k=[0,700,732],
                intermediate_chunk_did_not_append=True)


def check_prefix(events):
    marker=next(i for i,e in enumerate(events) if e.get("event")=="prefix_second_request")
    rows=cycles(events[marker+1:])
    seq=rows[0]["scheduled"]["seqs"][0]
    assert seq["prompt"]==620 and seq["cached"]==512 and seq["scheduled"]==108
    inp=rows[0]["inputs"]
    assert inp["cu_seqlens_q"]==[0,108] and inp["cu_seqlens_k"]==[0,620]
    assert inp["positions_first8"][0]==512 and inp["block_tables"] is not None
    return dict(second_request_cached=512,second_request_queries=108,
                cu_q=inp["cu_seqlens_q"],cu_k=inp["cu_seqlens_k"])


def check_slots(rows):
    checked=[]
    for step,row in enumerate(rows,1):
        sched,inp=row["scheduled"],row["inputs"]
        positions,slots=[],[]
        for seq in sched["seqs"]:
            ps=range(seq["cached"],seq["cached"]+seq["scheduled"]) if sched["prefill"] else [seq["total"]-1]
            for p in ps:
                positions.append(p)
                slot=seq["blocks"][p//256]*256+p%256
                slots.append(slot)
        assert positions[:8]==inp["positions_first8"]
        assert slots[:8]==inp["slots_first8"]
        checked.append(dict(step=step,positions_first8=positions[:8],expected_slots_first8=slots[:8]))
    return dict(checked_positions="first eight input positions per step, matching emitted trace",steps=checked)


def check_runner(rows):
    check_lifecycle(rows)
    first,second,third=[r["inputs"] for r in rows]
    assert first["input_shape"]==[160]
    assert first["cu_seqlens_q"]==[0,64,160] and first["cu_seqlens_k"]==[0,64,160]
    assert first["block_tables"] is None
    assert second["input_shape"]==[2] and second["positions_first8"]==[64,96]
    assert second["context_lens"]==[65,97] and second["block_tables"] is not None
    assert third["input_shape"]==[1] and third["context_lens"]==[98]
    return dict(prefill_T=160,prefill_cu_q=[0,64,160],decode_positions=[64,96],decode_context=[65,97])


def check_shapes(events):
    shapes={(e["phase"],e["name"]):e for e in events if e.get("event")=="model_shape"}
    assert shapes, "Re-run lifecycle with --shapes"
    expected={"qkv_proj":[160,4096],"o_proj":[160,1024],
              "gate_up_proj":[160,6144],"down_proj":[160,1024],"lm_head":[2,151936]}
    for name,shape in expected.items():
        assert shapes[("prefill",name)]["output"]==shape, (name,shapes[("prefill",name)])
    qkv=shapes[("prefill","attention_inputs")]["input"]
    assert qkv==[[160,16,128],[160,8,128],[160,8,128]]
    assert shapes[("decode","qkv_proj")]["output"]==[2,4096]
    return dict(first_prefill_shapes=expected,QKV_attention_inputs=qkv,
                note="Hooks capture first prefill/decode per named module; traces are not benchmarks")


def last_with(path,key):
    found=[o for o in objects(path) if key in o]
    assert found, f"Missing {key} in {path}"
    return found[-1]


def main():
    p=argparse.ArgumentParser()
    p.add_argument("case",choices=["lifecycle","chunk","prefix","slots","runner","shapes","cache","compare"])
    p.add_argument("--log",required=True)
    p.add_argument("--other")
    p.add_argument("--variable",choices=["eager","tp"],default="eager")
    p.add_argument("--out",required=True)
    a=p.parse_args()
    if a.case=="cache":
        d=last_with(a.log,"input_widths_cache")
        assert d["input_widths_no_cache"]==list(range(64,72))
        assert d["input_widths_cache"]==[64]+[1]*7
        assert d["forward_input_tokens_no_cache"]==540 and d["forward_input_tokens_cache"]==71
        for key in ["max_abs_logit_error","relative_l2_logit_error"]:
            assert math.isfinite(d[key]) and d[key]>=0
        result=dict(metrics=d,numerical_equivalence="REVIEW: compare logits/top1; no universal BF16 tolerance imposed")
    elif a.case=="compare":
        assert a.other, "compare requires --other"
        left,right=[last_with(path,"median_tokens_per_second") for path in [a.log,a.other]]
        lcfg,rcfg=dict(left["config"]),dict(right["config"])
        lv,rv=lcfg.pop(a.variable),rcfg.pop(a.variable)
        assert lcfg==rcfg and lv!=rv, "Comparison must change only --variable"
        assert (left["gpu_rank0"],left["torch_version"],left["cuda"])==(right["gpu_rank0"],right["torch_version"],right["cuda"])
        for d in [left,right]:
            assert len(d["runs"])==d["config"]["repeats"]
            assert all(r["output_tokens"]==d["config"]["seqs"]*d["config"]["output_len"] and r["seconds"]>0 for r in d["runs"])
        result=dict(variable=a.variable,values=[lv,rv],
                    median_tokens_per_second=[left["median_tokens_per_second"],right["median_tokens_per_second"]],
                    second_over_first=right["median_tokens_per_second"]/left["median_tokens_per_second"],
                    init_seconds=[left["init_seconds"],right["init_seconds"]],
                    note="Offline generation throughput; not TTFT/TPOT. GPU-memory fields cover rank 0 only.")
    else:
        events=objects(a.log)
        rows=cycles(events)
        if a.case=="prefix":
            result=check_prefix(events)
        elif a.case=="shapes":
            result=check_shapes(events)
        else:
            result=globals()["check_"+a.case](rows)
        tsv=Path(a.out).with_suffix(".tsv")
        lines=["step\tphase\tid\tprompt\ttotal_before\tcached_before\tscheduled\ttotal_after\tcached_after\tstatus_after\tblocks_before"]
        for step,row in enumerate(rows,1):
            post={s["id"]:s for s in row["after"]["seqs"]}
            for s in row["scheduled"]["seqs"]:
                end=post[s["id"]]
                values=[step,"prefill" if row["scheduled"]["prefill"] else "decode",s["id"],s["prompt"],
                        s["total"],s["cached"],s["scheduled"],end["total"],end["cached"],end["status"],s["blocks"]]
                lines.append("\t".join(map(str,values)))
        tsv.parent.mkdir(parents=True,exist_ok=True)
        tsv.write_text("\n".join(lines)+"\n")
        result["state_table"]=str(tsv)
    result=dict(case=a.case,check="PASS",scope="structural/log checks; read stated numeric/performance limits",**result)
    out=Path(a.out)
    out.parent.mkdir(parents=True,exist_ok=True)
    out.write_text(json.dumps(result,ensure_ascii=False,indent=2)+"\n")
    print(json.dumps(result,ensure_ascii=False,indent=2))


if __name__=="__main__":
    main()
