# 大模型推理入门：配图与无缓存实验（2026-09-09）

对应飞书文档：https://bytedance.larkoffice.com/docx/KoiNd9URGohmWGxB2WlcOUA4ndh

本包包含当前文档的 9 张可编辑 SVG、一个完整无缓存小模型实验，以及这次 CPU 验证的记录。第 18 章原有 `nanovllm-e2e-guide-v2.zip` 仍用于两周主线；本包补充第 2.8 节，不替代两周实验包。

## 从零跑这个小实验

1. 按飞书第 18.0 节下载两周实验包并准备 CPU 环境，确认 `env.sh`、`.venv-cpu` 与 `runs` 已存在。
2. 下载本包到运行实验的同一台机器。远端实验时先上传文件；下面 `ZIP_PATH` 换成实际路径。
3. 运行：

```bash
source "$HOME/llm-inference-lab/env.sh"
cd "$LAB_ROOT"
source .venv-cpu/bin/activate
ZIP_PATH="$HOME/Downloads/llm-inference-pedagogy-20260909.zip"
mkdir -p pedagogy
unzip -o "$ZIP_PATH" -d pedagogy
python pedagogy/00_uncached_walkthrough.py | tee runs/uncached-walkthrough.txt
```

也可在任何装有 Python 3 与 NumPy 的 CPU 环境中直接运行 `python 00_uncached_walkthrough.py`。本脚本无需模型下载或 GPU；遇到 NumPy 缺失先检查环境是否正确激活。

## 观察与验收

权重固定为随机生成的小矩阵，未经训练；6 个 id 没有中文和 EOS 含义。固定走三轮只是为了观察计算，不是一次语言理解测验，也不会按文中的假设生成“北京”。

- 输入 id 列表长度依次 3、4、5；每轮全部重新计算。
- H 的列数一直为 4，行数为当前上下文长度。
- Q/K/V 每行 2 维；Attention 的匹配矩阵依次 3×3、4×4、5×5。
- 每轮打印 Attention 最后一行、层输出最后一行、6 个 logits、采样概率及 greedy 选择的 id。
- 固定种子下本次实测三个输出 id 都为 4；真正要理解的是计算关系，而非 id 的语言含义。
- `causal prefix error` 接近 0，说明末尾追加新 token 不改变旧位置表示；最后打印 `total input positions = 12`、`CHECK: PASS`。

`uncached-example-output.txt` 为本次 CPU 输出，`VALIDATION.json` 记录实际 Python/NumPy 环境。此包未执行 NVIDIA GPU 性能测试。

## 图源

`svg/` 按对应章节编号。全部保留独立文字、形状和连线；可用 Inkscape、Figma 等矢量工具编辑，文档里的对应图也为原生画板节点。SVG 文字未转路径，没有整张内嵌位图。不同编辑器可能因中文字体和箭头实现产生轻微排版差异。

`manifest.json` 记录各图文件、章节、线上画板 token 和 block id。1、2、4 章为本轮重写/新增或迁移后的图，3、7、8、9、12、14 章沿用此前已验收的 SVG。

## 阅读顺序与参考

先跟随 token 表示走完整个模型，再理解上下文如何改变表示，接着展开 Attention 的计算；在完整无缓存循环之后，利用因果性推导 KV cache，最后学习 GPU、显存与引擎。

- Jay Alammar：[The Illustrated GPT-2](https://jalammar.github.io/illustrated-gpt2/)。借鉴输入到输出的向量追踪与逐层放大。其 GPT-2 结构不能直接代替 Qwen3。
- 3Blue1Brown：[Attention in transformers, step-by-step](https://www.3blue1brown.com/lessons/attention)。借鉴从上下文动机到 Q/K/V 数学的顺序。其常用列向量记法；本文统一为每行一个位置。
- Hugging Face：[How caching works](https://huggingface.co/docs/transformers/main/en/cache_explanation)。用于核对逐层缓存与增量计算。
- Kipply：[Transformer Inference Arithmetic](https://kipp.ly/transformer-inference-arithmetic/)。用于理解计算、带宽、容量的估算方法；旧硬件数字不直接复用。
- vLLM：[PagedAttention 介绍](https://blog.vllm.ai/2023/06/20/vllm.html)。从动态缓存分配理解工业引擎。

中文正文、例子与配图按本文教学目标重新组织和绘制，不是上述文章的逐段翻译。
