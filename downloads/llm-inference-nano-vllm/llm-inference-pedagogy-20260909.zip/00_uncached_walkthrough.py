"""A tiny, untrained, uncached causal Transformer; CPU + NumPy only."""
import numpy as np

np.set_printoptions(precision=4, suppress=True)
rng = np.random.default_rng(7)
D, DH, FF, N_LAYER, N_VOCAB = 4, 2, 8, 2, 6
embedding = rng.normal(0, 0.3, (N_VOCAB, D))
position = rng.normal(0, 0.1, (16, D))
layers = []
for _ in range(N_LAYER):
    layers.append({
        "q": rng.normal(0, 0.3, (D, DH)),
        "k": rng.normal(0, 0.3, (D, DH)),
        "v": rng.normal(0, 0.3, (D, DH)),
        "o": rng.normal(0, 0.3, (DH, D)),
        "up": rng.normal(0, 0.3, (D, FF)),
        "down": rng.normal(0, 0.3, (FF, D)),
    })
lm_head = rng.normal(0, 0.3, (D, N_VOCAB))


def norm(x):
    # RMSNorm with scale fixed at 1, independently for every row.
    return x / np.sqrt(np.mean(x * x, axis=-1, keepdims=True) + 1e-6)


def softmax(x):
    e = np.exp(x - np.max(x, axis=-1, keepdims=True))
    return e / np.sum(e, axis=-1, keepdims=True)


def forward(ids, trace=False):
    # Always receives ALL currently known ids. No cache is read or written.
    h = embedding[ids] + position[np.arange(len(ids))]
    if trace:
        print("H0 shape =", h.shape, "last row =", h[-1])
    for i, w in enumerate(layers, 1):
        u = norm(h)
        q, k, v = u @ w["q"], u @ w["k"], u @ w["v"]
        scores = q @ k.T / np.sqrt(DH)
        future = np.triu(np.ones(scores.shape, dtype=bool), k=1)
        attention = softmax(np.where(future, -np.inf, scores))
        h = h + (attention @ v) @ w["o"]
        h = h + np.maximum(norm(h) @ w["up"], 0) @ w["down"]
        if trace:
            print(f"layer {i}: Q/K/V {q.shape}, attention {attention.shape}, H {h.shape}")
            print("  attention last row =", attention[-1])
            print("  H last row =", h[-1])
    final = norm(h)
    logits = final @ lm_head
    return logits[-1], final


if __name__ == "__main__":
    # Numerical causality check: appending a token leaves old rows unchanged.
    _, old_rows = forward([0, 1, 2])
    _, longer_rows = forward([0, 1, 2, 3])
    error = float(np.max(np.abs(old_rows - longer_rows[:3])))
    assert np.allclose(old_rows, longer_rows[:3], atol=1e-12, rtol=0)
    print("causal prefix error =", error)
    ids = [0, 1, 2]
    positions_processed = 0
    # Exactly three rounds for observation. These six ids have no EOS semantics.
    for step in range(1, 4):
        print(f"\nround {step}: full input ids = {ids}")
        positions_processed += len(ids)
        logits, _ = forward(ids, trace=True)
        new_id = int(np.argmax(logits))
        print("logits =", logits)
        print("probabilities =", softmax(logits))
        print("selected id =", new_id)
        ids.append(new_id)
    assert positions_processed == 12
    print("\ntotal input positions =", positions_processed)
    print("CHECK: PASS")
