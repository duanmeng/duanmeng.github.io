# nano-vLLM 推理实验包 v6

这是一个逐步改造的学习项目：单卡基线 → 正确性护栏 → 可观测服务 → 调度改造 → GPU 执行分析 → 两卡分工 → 生命周期与回归。各阶段复用同一套请求、运行入口和证据格式。

先用浏览器打开 **实验手册.html**，按照第 5.1 节完成安装；进入实验后用 **CHECKPOINTS.md** 快速查命令。命令在 GPU 实验机终端执行。在线教程：[大模型推理与 nano-vLLM](https://bytedance.larkoffice.com/docx/KoiNd9URGohmWGxB2WlcOUA4ndh)。

## 固定基线

- Linux x86_64、Python 3.11.2、CUDA Toolkit 12.9.86、A800-SXM4-80GB；假定系统 CUDA 已正常工作。
- 源码 GeeeekExplorer/nano-vllm：`bb823b3e06983d71485a8e1f23715ebd87d98ef8`。
- Qwen/Qwen3-0.6B：`c1899de289a04d12100db370d81485cdf75e47ca`，配套 Tokenizer、配置与权重一起固定。
- 参考依赖：PyTorch 2.8.0+cu129、Triton 3.4.0、FlashAttention 2.8.3、Transformers 4.57.1。
- ZIP 不含上游仓库、权重与虚拟环境；`SHA256SUMS` 校验本包文件。

## 入口与职责

| 路径 | 用途 |
| --- | --- |
| 实验手册.html | Setup、原理观察、逐步修改与验收步骤 |
| CHECKPOINTS.md | 各阶段可运行命令、证据与失败检查 |
| practice/worker.py | 单 owner 的引擎循环、请求与有界输出流 |
| practice/run.py | CPU 模拟、固定负载、进程内/HTTP 服务与客户端 |
| practice/report.py | 按观测点分开的延迟、完成数与完整窗口吞吐报告 |
| e2e/ | 基线、源码、数值护栏、调度 CPU 集成与最终报告 |
| labs/、pedagogy/ | 按问题选读的原理与 GPU 深入实验 |
| patches/ | 可审阅、可应用与反向撤销的源码修改 |
| workloads/ | 固定到达轨迹；所有对照使用同一文件 |
| notes/ | 你的假设、修改、观察与结论 |
| validation/ | 发布时实际执行的本地检查，明确证据范围 |
| nano-vllm/、models/ | Setup 时获取的固定源码和模型 |
| runs/ | 实验机产生的结果；发布检查不冒充你的 GPU 运行结果 |

重新登录后：

```bash
source "$HOME/nanovllm-inference-lab/env.sh"
source "$LAB_ROOT/.venv-nano/bin/activate"
cd "$LAB_ROOT"
```

`env.sh` 根据自己的位置设置 LAB_ROOT、NANO_DIR、MODEL_DIR，也支持在其他目录使用。

## 修改顺序

第 5.2 节先观察 A/B/C/D 与 nano/HF 固定输入轨迹的 logits。第 5.3 节的 `prefill_first` 单实例入口可直接运行固定提交。第 5.4 节应用 `03-fair-scheduler.patch`，新增 `balanced`；第 5.5 节依附录 B.5 验证并应用 `02-graph-eager-fallback.patch`；第 5.6 节应用 `04-replica-isolation.patch`。`01-step-trace.patch` 是可选观测，性能测试前关闭逐轮日志。

每个补丁先 `git apply --check`，成功后只应用一次。手工修改与直接应用二选一；检查失败时先查看自己的 diff。引擎采用 editable 安装，修改后重新启动程序生效。主线保持每轮只有一个阶段；同批混合 Prefill/Decode 是进阶分支。

## 怎样判断完成

每一步留下：现象、假设、固定负载、具体文件/函数与 diff、正确性结果、测量口径、收益和代价。CPU 模拟、真实 Scheduler 的 CPU 状态流、静态估算与真实 GPU 证据分别标注；GPU 待验项目见 VALIDATION.md。

```bash
python e2e/final_report.py --root "$LAB_ROOT" --init-notes
python e2e/final_report.py --root "$LAB_ROOT"
```

初始化保留已有笔记。缺失实验保持 MISSING；报告生成成功不等于数值、性能或生产可靠性已经通过。
