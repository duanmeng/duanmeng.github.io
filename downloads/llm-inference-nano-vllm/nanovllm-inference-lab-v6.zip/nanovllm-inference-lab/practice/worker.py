"""One owner thread, one persistent Engine, and accepted-token event streams.

The model, scheduler and allocator stay upstream. This adapter owns request
admission and observes Sequence objects across a completed engine.step().
"""
from __future__ import annotations

import atexit
from collections import deque
from dataclasses import dataclass, fields
import json
import math
from pathlib import Path
import queue
import sys
import threading
import time
from typing import Any, Callable


class RequestRejected(ValueError):
    pass


class JsonlLog:
    def __init__(self, path: str | None = None):
        self.lock = threading.Lock()
        self.file = None
        if path:
            Path(path).parent.mkdir(parents=True, exist_ok=True)
            self.file = open(path, "w", encoding="utf-8")

    def __call__(self, event: dict):
        if self.file:
            with self.lock:
                self.file.write(json.dumps(event, ensure_ascii=False) + "\n")
                self.file.flush()

    def close(self):
        if self.file:
            self.file.close()


class EventStream:
    """Bounded nonblocking producer; one reserved terminal, never a lost EOF.

    On overflow queued events are discarded and the request is cancelled.
    The terminal reports the accepted count; the independent engine log keeps
    the accepted events. A disconnected/slow client is not a successful run.
    """
    def __init__(self, capacity: int):
        self.capacity = capacity
        self.items: deque[dict] = deque()
        self.condition = threading.Condition()
        self.terminal = False
        self.consumed_terminal = False

    def put(self, event: dict) -> bool:
        with self.condition:
            if self.terminal:
                return False
            if len(self.items) >= self.capacity:
                return False
            self.items.append(event)
            self.condition.notify()
            return True

    def finish(self, event: dict):
        with self.condition:
            if self.terminal:
                raise RuntimeError("duplicate terminal event")
            self.terminal = True
            if event["reason"] == "slow_consumer" and len(self.items) >= self.capacity:
                self.items.clear()
                event = {**event, "buffer_discarded": True}
            self.items.append(event)  # at most capacity + one reserved terminal
            self.condition.notify_all()

    def get(self, timeout: float | None = None) -> dict:
        with self.condition:
            if self.consumed_terminal:
                raise StopIteration
            if not self.condition.wait_for(lambda: bool(self.items), timeout):
                raise TimeoutError("event stream timeout")
            event = self.items.popleft()
            self.consumed_terminal = event["event"] == "finished"
            return event

    def __iter__(self):
        return self

    def __next__(self):
        return self.get()


@dataclass
class Request:
    request_id: str
    prompt: str | list[int]
    max_tokens: int
    temperature: float
    ignore_eos: bool
    stream: EventStream
    submitted_ns: int
    cancel_event: threading.Event
    seq: Any = None
    prompt_ids: list[int] | None = None
    reserved_blocks: int = 0
    reservation_acquired: bool = False
    admitted_ns: int | None = None
    last_token_ns: int | None = None
    token_count: int = 0
    finished: bool = False
    pending_slot: bool = True

    def cancel(self):
        self.cancel_event.set()


@dataclass
class EngineResources:
    engine: Any
    sampling_params: Callable
    max_model_len: int
    vocab_size: int
    block_size: int
    total_blocks: int
    simulated: bool = False


def gpu_factory(args) -> Callable[[], EngineResources]:
    """Imports and GPU initialization happen only on the owner thread."""
    def create():
        if not args.model:
            raise ValueError("GPU execution requires --model with existing local weights")
        if args.source:
            sys.path.insert(0, str(Path(args.source).resolve()))
        from nanovllm.config import Config
        from nanovllm.engine.llm_engine import LLMEngine
        from nanovllm.sampling_params import SamplingParams
        available = {f.name for f in fields(Config)}
        required = set()
        optional = {}
        if args.policy == "balanced":
            required.add("scheduling_policy")
        if "scheduling_policy" in available:
            optional["scheduling_policy"] = args.policy
        for arg, field in (("dist_init", "distributed_init_method"), ("shm_name", "shared_memory_name")):
            value = getattr(args, arg)
            if value is not None:
                required.add(field)
                optional[field] = value
        if required - available:
            raise RuntimeError("apply the requested capability's patch (03 scheduler / 04 isolation); missing Config fields: "
                               + ", ".join(sorted(required - available)))
        engine = LLMEngine(
            args.model, tensor_parallel_size=args.tp,
            max_model_len=args.max_model_len,
            max_num_seqs=args.batch_seqs,
            max_num_batched_tokens=args.batch_tokens,
            gpu_memory_utilization=args.gpu_memory_utilization,
            enforce_eager=args.eager,
            **optional,
        )
        # All normal cleanup belongs to the owner. Patch 04 makes exit idempotent.
        atexit.unregister(engine.exit)
        config = engine.model_runner.config
        return EngineResources(engine, SamplingParams, config.max_model_len,
                               config.hf_config.vocab_size, config.kvcache_block_size,
                               len(engine.scheduler.block_manager.blocks))
    return create


class StepProfiler:
    def __init__(self, engine, directory: str):
        import torch
        self.torch = torch
        self.directory = Path(directory)
        self.directory.mkdir(parents=True, exist_ok=True)
        self.wrapped = []
        runner = engine.model_runner
        for name in ("prepare_prefill", "prepare_decode", "run_model"):
            original = getattr(runner, name, None)
            if original is None:
                continue
            def wrapper(*args, _name=name, _original=original, **kwargs):
                with torch.profiler.record_function("runner." + _name):
                    return _original(*args, **kwargs)
            self.wrapped.append((runner, name, original))
            setattr(runner, name, wrapper)
        self.profiler = torch.profiler.profile(
            activities=[torch.profiler.ProfilerActivity.CPU, torch.profiler.ProfilerActivity.CUDA],
            record_shapes=True, profile_memory=True,
        )
        self.profiler.__enter__()

    def step(self, engine):
        with self.torch.profiler.record_function("engine.step"):
            result = engine.step()
        self.profiler.step()
        return result

    def close(self):
        self.profiler.__exit__(None, None, None)
        for runner, name, original in self.wrapped:
            setattr(runner, name, original)
        self.profiler.export_chrome_trace(str(self.directory / "engine-trace.json"))
        (self.directory / "operator-summary.txt").write_text(
            "Profiling run; not performance evidence. Rank 0 of this worker only.\n"
            + self.profiler.key_averages(group_by_input_shape=True).table(
                sort_by="self_cuda_time_total", row_limit=80), encoding="utf-8")


class Worker:
    def __init__(self, factory: Callable[[], EngineResources], *, worker_id="worker-0",
                 max_active=8, queue_depth=32, event_capacity=256,
                 log: Callable[[dict], None] | None = None, profile_dir=None,
                 boundary_hook: Callable[[Any, int], None] | None = None):
        if min(max_active, queue_depth, event_capacity) < 1:
            raise ValueError("all queue/active capacities must be positive")
        self.factory, self.worker_id = factory, worker_id
        self.max_active, self.event_capacity = max_active, event_capacity
        self.incoming: queue.Queue[Request] = queue.Queue(queue_depth)
        self.pending_slots = threading.BoundedSemaphore(queue_depth)
        self.active: dict[str, Request] = {}
        self.registry: dict[str, Request] = {}
        self.registry_lock = threading.Lock()
        self.log = log or (lambda event: None)
        self.profile_dir, self.boundary_hook = profile_dir, boundary_hook
        self.profile_requested = threading.Event()
        self.profile_ready = threading.Event()
        self.stop = threading.Event()
        self.ready = threading.Event()
        self.done = threading.Event()
        self.wakeup = threading.Event()
        self.failure: BaseException | None = None
        self.resources: EngineResources | None = None
        self.head: Request | None = None
        self.round = 0
        self.reserved_blocks = 0
        self.thread = threading.Thread(target=self._run, name=worker_id + "-owner", daemon=True)

    def start(self, timeout=300):
        self.thread.start()
        if not self.ready.wait(timeout):
            self.stop.set()
            raise TimeoutError("engine startup timed out; terminate the worker process if GPU is hung")
        self.check_health()
        return self

    def check_health(self):
        if self.failure:
            raise RuntimeError("worker failed") from self.failure

    def enable_profiling(self, timeout=30):
        if not self.profile_dir:
            return
        self.profile_requested.set()
        self.wakeup.set()
        if not self.profile_ready.wait(timeout):
            raise TimeoutError("owner did not start profiling")
        self.check_health()

    def _event(self, kind: str, request: Request | None = None, **values):
        event = dict(schema_version=1, event=kind,
                     observer="engine",
                     request_id=request.request_id if request else None,
                     worker_id=self.worker_id, t_ns=time.perf_counter_ns(), round=self.round,
                     simulated=bool(self.resources and self.resources.simulated),
                     profiling=bool(self.profile_dir))
        event.update(values)
        self.log(event)
        return event

    def submit(self, request_id: str, prompt: str | list[int], *, max_tokens=32,
               temperature=0.6, ignore_eos=True) -> Request:
        if not isinstance(request_id, str) or not request_id or len(request_id) > 128:
            raise RequestRejected("request_id must be a nonempty string of at most 128 characters")
        self.check_health()
        if not self.ready.is_set() or self.stop.is_set() or self.done.is_set():
            raise RequestRejected("worker is not accepting requests")
        if not self.pending_slots.acquire(blocking=False):
            raise RequestRejected("request queue is full")
        # Copy caller-owned IDs: callers must not mutate an in-flight prompt.
        if isinstance(prompt, list):
            prompt = list(prompt)
        request = Request(request_id, prompt, max_tokens, temperature, ignore_eos,
                          EventStream(self.event_capacity), time.perf_counter_ns(), threading.Event())
        with self.registry_lock:
            if self.stop.is_set() or self.done.is_set() or request_id in self.registry:
                self.pending_slots.release()
                raise RequestRejected("worker closed or request_id already in flight")
            self.registry[request_id] = request
            self.incoming.put_nowait(request)
        self.wakeup.set()
        return request

    def cancel(self, request_id: str) -> bool:
        with self.registry_lock:
            request = self.registry.get(request_id)
            if request:
                request.cancel()
        self.wakeup.set()
        return request is not None

    def _release_pending(self, request):
        if request.pending_slot:
            request.pending_slot = False
            self.pending_slots.release()

    def _finish(self, request, reason, detail=None):
        if request.finished:
            raise RuntimeError("request finished more than once")
        engine = self.resources.engine
        seq = request.seq
        values = dict(reason=reason, token_count=request.token_count, detail=detail)
        if reason == "completed":
            values["text"] = engine.tokenizer.decode(seq.completion_token_ids)
        if seq is not None and not seq.is_finished:
            # Only this request's references are returned. Never clear the pool.
            for group in (engine.scheduler.waiting, engine.scheduler.running):
                if seq in group:
                    group.remove(seq)
            engine.scheduler.block_manager.deallocate(seq)
        if request.reservation_acquired:
            self.reserved_blocks -= request.reserved_blocks
            request.reservation_acquired = False
        request.reserved_blocks = 0
        self.active.pop(request.request_id, None)
        self._release_pending(request)
        event = self._event("finished", request, **values)
        request.finished = True
        with self.registry_lock:
            self.registry.pop(request.request_id, None)
        request.stream.finish(event)

    def _cancel_pending(self):
        """Cancellation at every boundary must not wait for an active slot."""
        cancelled = []
        if self.head and self.head.cancel_event.is_set():
            cancelled.append(self.head)
            self.head = None
        with self.registry_lock:
            kept = []
            while True:
                try:
                    request = self.incoming.get_nowait()
                except queue.Empty:
                    break
                (cancelled if request.cancel_event.is_set() else kept).append(request)
            for request in kept:
                self.incoming.put_nowait(request)
        for request in cancelled:
            self._finish(request, "cancelled")

    def _validate(self, request):
        resources = self.resources
        if type(request.max_tokens) is not int or request.max_tokens < 1:
            raise RequestRejected("max_tokens must be a positive integer")
        if type(request.ignore_eos) is not bool:
            raise RequestRejected("ignore_eos must be boolean")
        if (type(request.temperature) not in (float, int)
                or not math.isfinite(request.temperature) or request.temperature <= 1e-10):
            raise RequestRejected("temperature must be finite and > 1e-10; upstream has no greedy mode")
        prompt = request.prompt
        if isinstance(prompt, str):
            if len(prompt) > resources.max_model_len * 32:
                raise RequestRejected("raw prompt exceeds bounded input size")
            ids = resources.engine.tokenizer.encode(prompt)
        elif isinstance(prompt, list):
            ids = prompt
        else:
            raise RequestRejected("prompt must be text or a list of token IDs")
        if not ids or any(type(token) is not int or not 0 <= token < resources.vocab_size for token in ids):
            raise RequestRejected("prompt IDs must be nonempty integers within model vocabulary")
        if len(ids) + request.max_tokens > resources.max_model_len:
            raise RequestRejected("prompt + max_tokens exceeds max_model_len")
        blocks = math.ceil((len(ids) + request.max_tokens) / resources.block_size)
        if blocks > resources.total_blocks:
            raise RequestRejected("one request's worst-case KV footprint exceeds the total KV pool")
        request.prompt_ids, request.reserved_blocks = ids, blocks

    def _admit(self):
        while len(self.active) < self.max_active:
            if self.head is None:
                try:
                    self.head = self.incoming.get_nowait()
                except queue.Empty:
                    return
            request = self.head
            if request.cancel_event.is_set():
                self.head = None
                self._finish(request, "cancelled")
                continue
            if request.prompt_ids is None:
                try:
                    self._validate(request)
                except RequestRejected as error:
                    self.head = None
                    self._finish(request, "rejected", str(error))
                    continue
            if self.reserved_blocks + request.reserved_blocks > self.resources.total_blocks:
                return  # conservative reservation; keep FIFO head within queue capacity
            engine = self.resources.engine
            params = self.resources.sampling_params(temperature=request.temperature,
                max_tokens=request.max_tokens, ignore_eos=request.ignore_eos)
            engine.add_request(request.prompt_ids, params)
            request.seq = engine.scheduler.waiting[-1]  # only owner calls add_request
            self.reserved_blocks += request.reserved_blocks
            request.reservation_acquired = True
            self.head = None
            self._release_pending(request)
            self.active[request.request_id] = request
            event = self._event("admitted", request, seq_id=request.seq.seq_id,
                prompt_tokens=len(request.prompt_ids), max_tokens=request.max_tokens,
                submitted_ns=request.submitted_ns,
                queue_ms=(time.perf_counter_ns() - request.submitted_ns) / 1e6,
                reserved_blocks=request.reserved_blocks)
            request.admitted_ns = event["t_ns"]
            if not request.stream.put(event):
                self._finish(request, "slow_consumer")

    def _run(self):
        profiler = None
        try:
            self.resources = self.factory()
            if self.resources.total_blocks < 1:
                raise RuntimeError("engine has no usable KV blocks")
            if self.profile_dir and self.resources.simulated:
                raise ValueError("--profile-dir requires the GPU engine")
            self._event("worker_ready", total_blocks=self.resources.total_blocks,
                        block_size=self.resources.block_size,
                        max_model_len=self.resources.max_model_len,
                        owner_thread=threading.get_ident())
            self.ready.set()
            while not self.stop.is_set():
                if self.profile_dir and self.profile_requested.is_set() and profiler is None:
                    profiler = StepProfiler(self.resources.engine, self.profile_dir)
                    self.profile_ready.set()
                if self.boundary_hook:
                    self.boundary_hook(self, self.round)
                for request in list(self.active.values()):
                    if request.cancel_event.is_set():
                        self._finish(request, "cancelled")
                self._cancel_pending()
                self._admit()
                if not self.active:
                    self.wakeup.wait(0.01)
                    self.wakeup.clear()
                    continue
                # Keep the actual objects: scheduler.postprocess may remove them.
                snapshots = [(request, request.seq, request.seq.num_completion_tokens)
                             for request in self.active.values()]
                before = time.perf_counter_ns()
                self.round += 1
                engine = self.resources.engine
                _, scheduled_tokens = profiler.step(engine) if profiler else engine.step()
                after = time.perf_counter_ns()
                accepted = 0
                for request, seq, old_count in snapshots:
                    new_count = seq.num_completion_tokens
                    if new_count < old_count:
                        raise RuntimeError("completion count moved backwards")
                    for index in range(old_count, new_count):
                        # Intermediate prefill candidates never increase this count.
                        request.token_count += 1
                        accepted += 1
                        latency = {"engine_itl_ms": (after - request.last_token_ns) / 1e6} if request.last_token_ns else {
                            "engine_ttft_ms": (after - request.admitted_ns) / 1e6}
                        event = self._event("token", request,
                            token_id=seq.completion_token_ids[index], token_index=index + 1,
                            t_ns=after, **latency)
                        request.last_token_ns = after
                        if not request.stream.put(event):
                            self._finish(request, "slow_consumer")
                            break
                    if not request.finished and seq.is_finished:
                        self._finish(request, "completed")
                self._event("step", t_ns=after, duration_ms=(after - before) / 1e6,
                            scheduled_tokens=scheduled_tokens, phase="prefill" if scheduled_tokens > 0 else "decode",
                            accepted_tokens=accepted, active_requests=len(self.active))
        except BaseException as error:
            self.failure = error
            self.stop.set()
        finally:
            self.stop.set()
            self.ready.set()
            self.profile_ready.set()
            reason = "error" if self.failure else "closed"
            # The lock closes the submit/cleanup race. Pending slots remain bounded.
            with self.registry_lock:
                remaining = list(self.registry.values())
            for request in remaining:
                try:
                    self._finish(request, reason, repr(self.failure) if self.failure else None)
                except BaseException as error:
                    self.failure = self.failure or error
                    # Cleanup failure must still unblock the consumer, with an error.
                    if not request.stream.terminal:
                        request.stream.finish(dict(schema_version=1, event="finished",
                            request_id=request.request_id, worker_id=self.worker_id,
                            t_ns=time.perf_counter_ns(), round=self.round, reason="error",
                            token_count=request.token_count, detail=repr(error)))
            if profiler:
                try:
                    profiler.close()
                except BaseException as error:
                    self.failure = self.failure or error
            if self.resources:
                try:
                    self.resources.engine.exit()
                except BaseException as error:
                    self.failure = self.failure or error
            try:
                self._event("worker_failed" if self.failure else "worker_closed",
                            detail=repr(self.failure) if self.failure else None)
            except BaseException as error:
                self.failure = self.failure or error
            finally:
                self.done.set()

    def close(self, timeout=30):
        self.stop.set()
        self.wakeup.set()
        if self.thread.ident is not None:
            self.thread.join(timeout)
            if self.thread.is_alive():
                raise TimeoutError("worker did not stop; GPU/process cleanup is unverified")
        self.check_health()
