"""Observer-separated, full-workload E2E reporting; no cross-run tail clipping."""
from collections import Counter
import json
import math
from pathlib import Path


def quantiles(values):
    values = sorted(value for value in values if value is not None)
    return {name: values[math.ceil(q * len(values)) - 1] for name, q in (("p50", .5), ("p95", .95), ("p99", .99))} if values else None


def summarize(path):
    rows = [json.loads(line) for line in Path(path).read_text(encoding="utf-8").splitlines() if line.strip()]
    starts = [row for row in rows if row.get("event") == "run_start"]
    if len(starts) != 1:
        raise ValueError(f"{path}: expected one load run_start; use an unmerged load event log")
    metadata = starts[0]
    arrivals = [row for row in rows if row.get("event") == "arrival" and row.get("observer") == "client"]
    ids = {row["request_id"] for row in arrivals}
    relevant = [row for row in rows if row.get("request_id") in ids]
    client = [row for row in relevant if row.get("observer") == "client"]
    engine = [row for row in relevant if row.get("observer") == "engine"]
    engine_visible = any(row.get("event") == "admitted" for row in engine)
    terminals = [row for row in client if row.get("event") == "finished"]
    if not terminals:
        terminals = [row for row in engine if row.get("event") == "finished"]
    final_by_id = {row["request_id"]: row for row in terminals}
    completed_clients = [row for row in client if row.get("event") == "client_finished"]
    completion_times = [row["finished_ns"] for row in completed_clients]
    sent_times = [row["sent_ns"] for row in arrivals]
    duration = (max(completion_times) - min(sent_times)) / 1e9 if sent_times and completion_times else None
    accepted = sum(row["token_count"] for row in final_by_id.values())
    successful = {key for key, row in final_by_id.items() if row["reason"] == "completed"}
    errors = [row for row in rows if row.get("event") == "client_error"]
    worker_failures = [row for row in rows if row.get("event") == "worker_failed"]
    duplicate_terminals = len(terminals) - len(final_by_id)
    simulated = any(row.get("simulated") for row in rows)
    profiling = any(row.get("profiling") for row in rows)
    complete = bool(ids) and len(successful) == len(ids) and not errors and not duplicate_terminals and not worker_failures
    tokens = [row for row in client if row.get("event") == "token"]
    accepted_observations = [row for row in (engine if engine_visible else client) if row.get("event") == "token"]
    info = dict(
        input=str(path), mode=metadata.get("mode"), policy=metadata.get("policy"), tp=metadata.get("tp"),
        trace_sha256=metadata.get("trace_sha256"), config_source=metadata.get("config_source"),
        warmup_state=metadata.get("warmup_state", "unknown"), cache_state=metadata.get("cache_state"),
        offered=len(ids) + len([row for row in errors if row.get("request_id") not in ids]),
        submitted=len(ids), admitted=len({row["request_id"] for row in (engine if engine_visible else client) if row.get("event") == "admitted"}),
        finished=len(final_by_id), completed=len(successful), finished_by_reason=dict(Counter(row["reason"] for row in final_by_id.values())),
        duplicate_terminals=duplicate_terminals, errors=len(errors), worker_failures=len(worker_failures),
        accepted_tokens=accepted,
        engine_token_events=len(accepted_observations) if engine_visible else None,
        client_token_events=len(tokens),
        accepted_source="unique request terminal token_count", engine_events_available=engine_visible,
        full_workload_window_s=duration,
        aggregate_tokens_s=accepted / duration if duration and complete else None,
        throughput_window="this run: global first client submission to last client terminal; all endpoints together",
        client_ttft_ms=quantiles([row.get("client_ttft_ms") for row in tokens if row["request_id"] in successful]),
        client_itl_ms=quantiles([row.get("client_itl_ms") for row in tokens if row["request_id"] in successful]),
        engine_ttft_ms=quantiles([row.get("engine_ttft_ms") for row in accepted_observations if row["request_id"] in successful]),
        engine_itl_ms=quantiles([row.get("engine_itl_ms") for row in accepted_observations if row["request_id"] in successful]),
        send_lag_ms=quantiles([row.get("arrival_lag_ms") for row in arrivals]),
        simulated=simulated, profiling=profiling, workload_complete=complete,
        performance_eligible=complete and metadata.get("mode") == "wall" and not simulated and not profiling,
        performance_note="Eligibility excludes simulation/profiling/incomplete loads; it does not establish steady state or GPU validation.",
    )
    return info


def run_report(args):
    runs = [summarize(path) for path in args.inputs.split(",")]
    same_trace = len({run["trace_sha256"] for run in runs}) == 1 and all(run["trace_sha256"] for run in runs)
    report = dict(kind="E2E workload comparison", same_trace=same_trace, runs=runs,
                  comparison_note="Each run retains its complete workload and tail. Throughput is aggregated across replicas in that run's one common wall-clock window.")
    path = Path(args.out)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    lines = ["# E2E workload comparison", "", report["comparison_note"], "",
             f"Same trace: {same_trace}. CPU simulation and profiling are not performance evidence.", "",
             "| Run | Mode | Simulated / profile | Offered / admitted / completed | Accepted tokens | Full window (s) | Aggregate token/s | TTFT p50/p95 (ms) | ITL p50/p95 (ms) | Send lag p95 (ms) |",
             "| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |"]
    def number(value):
        return f"{value:.3f}" if value is not None else "unavailable"
    def pair(value):
        return f"{value['p50']:.3f} / {value['p95']:.3f}" if value else "unavailable"
    for run in runs:
        label = Path(run["input"]).name.replace("|", "_")
        lines.append(f"| {label} | {run['mode']} | {run['simulated']} / {run['profiling']} | "
                     f"{run['offered']} / {run['admitted']} / {run['completed']} | {run['accepted_tokens']} | "
                     f"{number(run['full_workload_window_s'])} | {number(run['aggregate_tokens_s'])} | "
                     f"{pair(run['client_ttft_ms'])} | {pair(run['client_itl_ms'])} | "
                     f"{number(run['send_lag_ms']['p95'] if run['send_lag_ms'] else None)} |")
    for run in runs:
        lines.extend(["", f"## {Path(run['input']).name}", "",
                      f"Policy: {run['policy']}; TP: {run['tp']}; configuration source: {run['config_source']}.", "",
                      f"Warmup: {run['warmup_state']}; cache history: {run['cache_state']}.", "",
                      f"Finished: {json.dumps(run['finished_by_reason'])}; errors: {run['errors']}; duplicate terminals: {run['duplicate_terminals']}.", "",
                      f"Performance eligible: {run['performance_eligible']}. {run['performance_note']}"])
    path.with_suffix(".md").write_text("\n".join(lines) + "\n", encoding="utf-8")
    print(json.dumps({"json": str(path), "markdown": str(path.with_suffix('.md')), "runs": len(runs), "same_trace": same_trace}, indent=2))
    return 0
