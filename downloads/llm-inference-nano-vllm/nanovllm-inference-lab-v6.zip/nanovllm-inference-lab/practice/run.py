#!/usr/bin/env python3
"""Runnable E2E practice: simulate, trace, load, serve, client.

No GPU dependencies are imported by the CPU simulation or HTTP client.
Run from the lab root: python3 practice/run.py --help
"""
from __future__ import annotations

import argparse
from collections import deque
from concurrent.futures import ThreadPoolExecutor
import hashlib
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import itertools
import json
import math
from pathlib import Path
import random
import socket
import sys
import threading
import time
from types import SimpleNamespace
from urllib.error import HTTPError
from urllib.parse import urlparse
from urllib.request import Request as URLRequest, urlopen

if __package__:
    from .worker import EngineResources, JsonlLog, RequestRejected, Worker, gpu_factory
    from .report import run_report
else:
    from worker import EngineResources, JsonlLog, RequestRejected, Worker, gpu_factory
    from report import run_report


class FakeSequence:
    def __init__(self, seq_id, ids, params):
        self.seq_id, self.token_ids = seq_id, list(ids)
        self.num_prompt_tokens, self.max_tokens = len(ids), params.max_tokens
        self.num_cached_tokens = 0
        self.block_table = []
        self.is_finished = False

    @property
    def num_completion_tokens(self):
        return len(self.token_ids) - self.num_prompt_tokens

    @property
    def completion_token_ids(self):
        return self.token_ids[self.num_prompt_tokens:]


class FakeBlockManager:
    """Reference bookkeeping only: no attention, CUDA, memory or speed claims."""
    def __init__(self, total_blocks):
        self.blocks = [SimpleNamespace(ref_count=0) for _ in range(total_blocks)]

    def allocate(self, seq):
        count = math.ceil((seq.num_prompt_tokens + seq.max_tokens) / 16)
        free = [i for i, block in enumerate(self.blocks) if block.ref_count == 0]
        if len(free) < count:
            raise RuntimeError("simulation allocator exhausted")
        seq.block_table = free[:count]
        for block_id in seq.block_table:
            self.blocks[block_id].ref_count += 1

    def deallocate(self, seq):
        for block_id in seq.block_table:
            self.blocks[block_id].ref_count -= 1
            assert self.blocks[block_id].ref_count >= 0
        seq.block_table.clear()


class FakeEngine:
    def __init__(self, *, delay=0.003, policy="prefill_first", fail_round=None, total_blocks=128):
        self.owner = threading.get_ident()
        self.delay, self.policy, self.fail_round = delay, policy, fail_round
        self.round, self.counter, self.last_prefill = 0, itertools.count(), False
        self.scheduler = SimpleNamespace(waiting=deque(), running=deque(),
                                         block_manager=FakeBlockManager(total_blocks))
        self.tokenizer = SimpleNamespace(encode=lambda text: [3 + ord(c) % 120 for c in text],
                                         decode=lambda ids: " ".join(map(str, ids)))
        self.exited = False

    def _assert_owner(self):
        assert threading.get_ident() == self.owner, "Engine used outside its owner"

    def add_request(self, ids, params):
        self._assert_owner()
        self.scheduler.waiting.append(FakeSequence(next(self.counter), ids, params))

    def step(self):
        self._assert_owner()
        self.round += 1
        if self.round == self.fail_round:
            raise RuntimeError("injected simulation engine failure")
        time.sleep(self.delay)
        scheduler = self.scheduler
        prefill = bool(scheduler.waiting) and not (
            self.policy == "balanced" and self.last_prefill and scheduler.running)
        outputs = []
        scheduled = 0
        if prefill:
            seq = scheduler.waiting[0]
            if not seq.block_table:
                scheduler.block_manager.allocate(seq)
            chunk = min(4, seq.num_prompt_tokens - seq.num_cached_tokens)
            seq.num_cached_tokens += chunk
            scheduled += chunk
            seqs = [seq] if seq.num_cached_tokens == seq.num_prompt_tokens else []
            if seqs:
                scheduler.waiting.popleft()
                scheduler.running.append(seq)
        else:
            seqs = list(scheduler.running)
            scheduled = -len(seqs)
        self.last_prefill = prefill
        for seq in seqs:
            seq.token_ids.append(10 + seq.num_completion_tokens)
            if seq.num_completion_tokens >= seq.max_tokens:
                seq.is_finished = True
                scheduler.running.remove(seq)
                scheduler.block_manager.deallocate(seq)
                outputs.append((seq.seq_id, seq.completion_token_ids))
        return outputs, scheduled

    def exit(self):
        self._assert_owner()
        assert not self.scheduler.waiting and not self.scheduler.running
        assert all(block.ref_count == 0 for block in self.scheduler.block_manager.blocks)
        self.exited = True


def simulation_factory(*, max_model_len=2048, **kwargs):
    def create():
        engine = FakeEngine(**kwargs)
        return EngineResources(engine, SimpleNamespace, max_model_len, 128, 16,
                               len(engine.scheduler.block_manager.blocks), simulated=True)
    return create


def local_event(log, kind, **values):
    event = dict(schema_version=1, event=kind, observer="client", request_id=None, worker_id="client",
                 t_ns=time.perf_counter_ns(), round=None)
    event.update(values)
    log(event)
    return event


def consume_stream(stream, log, *, request_id, sent_ns, cancel=None, cancel_after=None,
                   read_delay_ms=0, endpoint="local", timeout=120):
    first_ns = last_ns = None
    tokens, itls = 0, []
    terminal = None
    for event in stream:
        now = time.perf_counter_ns()
        record = dict(event, observer="client", client_received_ns=now, endpoint=endpoint)
        if event["event"] == "token":
            tokens += 1
            if first_ns is None:
                first_ns = now
                record["client_ttft_ms"] = (now - sent_ns) / 1e6
            else:
                itls.append((now - last_ns) / 1e6)
                record["client_itl_ms"] = itls[-1]
            last_ns = now
        log(record)
        if event["event"] == "finished":
            terminal = event
            break
        if cancel_after and tokens == cancel_after and event["event"] == "token" and cancel:
            cancel()
        if read_delay_ms:
            time.sleep(read_delay_ms / 1000)
        if (now - sent_ns) / 1e9 > timeout:
            if cancel:
                cancel()
            raise TimeoutError("client request deadline exceeded")
    if terminal is None:
        raise RuntimeError("stream ended without finished; request outcome is unknown")
    result = dict(request_id=request_id, reason=terminal["reason"], tokens_received=tokens,
                  accepted_tokens=terminal["token_count"],
                  ttft_ms=(first_ns - sent_ns) / 1e6 if first_ns else None,
                  itl_ms=itls, sent_ns=sent_ns, finished_ns=time.perf_counter_ns(),
                  simulated=terminal.get("simulated", False), profiling=terminal.get("profiling", False), endpoint=endpoint)
    local_event(log, "client_finished", **result)
    return result


def http_json(url, payload, timeout):
    body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
    return urlopen(URLRequest(url, body, {"Content-Type": "application/json"}), timeout=timeout)


def parse_endpoints(value):
    endpoints = [item.rstrip("/") for item in value.split(",")]
    for endpoint in endpoints:
        parsed = urlparse(endpoint)
        if (parsed.scheme != "http" or parsed.hostname != "127.0.0.1"
                or parsed.username or parsed.password or parsed.path or parsed.query or parsed.fragment):
            raise ValueError("endpoints must be http://127.0.0.1:<port>, without extra path/credentials")
        if parsed.port is None:
            raise ValueError("endpoint needs an explicit port")
    return endpoints


def http_request(endpoint, payload, log, *, cancel_after=None, read_delay_ms=0, timeout=120,
                 sent_ns=None):
    sent_ns = sent_ns or time.perf_counter_ns()
    def cancel():
        with http_json(endpoint + "/cancel", {"request_id": payload["request_id"]}, timeout) as response:
            local_event(log, "client_cancel", request_id=payload["request_id"],
                        endpoint=endpoint, reply=json.load(response))
    try:
        with http_json(endpoint + "/generate", payload, timeout) as response:
            events = (json.loads(line) for line in response if line.strip())
            return consume_stream(events, log, request_id=payload["request_id"], sent_ns=sent_ns,
                                  cancel=cancel, cancel_after=cancel_after,
                                  read_delay_ms=read_delay_ms, endpoint=endpoint, timeout=timeout)
    except HTTPError as error:
        detail = error.read(8192).decode("utf-8", errors="replace")
        raise RuntimeError(f"HTTP {error.code}: {detail}") from error


class LocalServer(ThreadingHTTPServer):
    daemon_threads = True
    block_on_close = False

    def __init__(self, worker, port, *, max_clients=64, stream_timeout=2.0):
        self.worker = worker
        self.client_slots = threading.BoundedSemaphore(max_clients)
        self.stream_timeout = stream_timeout
        super().__init__(("127.0.0.1", port), Handler)

    def process_request(self, request, client_address):
        if not self.client_slots.acquire(blocking=False):
            try:
                request.settimeout(0.1)
                request.sendall(b"HTTP/1.0 503 Service Unavailable\r\nContent-Length: 0\r\n\r\n")
            finally:
                self.shutdown_request(request)
            return
        try:
            super().process_request(request, client_address)
        except BaseException:
            self.client_slots.release()
            raise

    def process_request_thread(self, request, client_address):
        try:
            super().process_request_thread(request, client_address)
        finally:
            self.client_slots.release()


class Handler(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.0"  # response EOF delimits the JSONL stream

    def log_message(self, *_):
        pass

    def _reply(self, status, payload):
        data = json.dumps(payload).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def do_GET(self):
        if self.path != "/health":
            return self._reply(404, {"error": "unknown path"})
        worker = self.server.worker
        self._reply(503 if worker.failure or worker.stop.is_set() else 200,
                    {"worker_id": worker.worker_id, "ready": worker.ready.is_set(),
                     "failed": repr(worker.failure) if worker.failure else None,
                     "simulated": bool(worker.resources and worker.resources.simulated)})

    def do_POST(self):
        request = None
        self.connection.settimeout(self.server.stream_timeout)
        try:
            size = int(self.headers.get("Content-Length", "0"))
            if size < 1 or size > 1024 * 1024 or self.headers.get("Transfer-Encoding"):
                return self._reply(413, {"error": "provide Content-Length in 1..1048576"})
            payload = json.loads(self.rfile.read(size))
            if not isinstance(payload, dict):
                raise ValueError("JSON object required")
            if self.path == "/cancel":
                return self._reply(200, {"cancelled": self.server.worker.cancel(payload["request_id"])})
            if self.path != "/generate":
                return self._reply(404, {"error": "unknown path"})
            request = self.server.worker.submit(**payload)
            self.send_response(200)
            self.send_header("Content-Type", "application/x-ndjson; charset=utf-8")
            self.send_header("Cache-Control", "no-store")
            self.end_headers()
            while True:
                event = request.stream.get(timeout=120)
                self.wfile.write((json.dumps(event, ensure_ascii=False) + "\n").encode("utf-8"))
                self.wfile.flush()
                if event["event"] == "finished":
                    break
        except RequestRejected as error:
            self._reply(429, {"error": str(error)})
        except (ValueError, TypeError, KeyError) as error:
            if request is None:
                self._reply(400, {"error": str(error)})
        except (BrokenPipeError, ConnectionResetError, socket.timeout, TimeoutError):
            pass
        except RuntimeError as error:
            if request is None:
                self._reply(503, {"error": str(error)})
        finally:
            if request and not request.finished:
                request.cancel()  # owner releases this request at the next boundary


def build_worker(args, log, *, boundary_hook=None):
    factory = (simulation_factory(policy=args.policy, delay=args.sim_step_ms / 1000,
                                  max_model_len=args.max_model_len)
               if args.simulate else gpu_factory(args))
    return Worker(factory, worker_id=args.worker_id, max_active=args.max_active,
                  queue_depth=args.queue_depth, event_capacity=args.event_capacity, log=log,
                  profile_dir=args.profile_dir, boundary_hook=boundary_hook)


def write_summary(path, summary):
    destination = Path(path).with_suffix(".summary.json")
    destination.write_text(json.dumps(summary, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(summary, ensure_ascii=False, indent=2))


def quantiles(values):
    values = sorted(value for value in values if value is not None)
    if not values:
        return None
    return {name: values[math.ceil(q * len(values)) - 1] for name, q in (("p50", .5), ("p95", .95), ("p99", .99))}


def create_trace(args):
    if min(args.requests, args.prompt_tokens, args.long_prompt_tokens, args.max_tokens, args.long_every) < 1:
        raise ValueError("trace sizes/counts must be positive")
    if args.interval_ms < 0:
        raise ValueError("interval-ms must be nonnegative")
    rng = random.Random(args.seed)
    records = []
    for i in range(args.requests):
        is_long = (i + 1) % args.long_every == 0
        length = args.long_prompt_tokens if is_long else args.prompt_tokens
        records.append(dict(request_id=f"request-{i:04d}", arrival_ms=i * args.interval_ms,
                            arrival_round=i, cohort="long" if is_long else "short",
                            prompt=[rng.randrange(3, 127) for _ in range(length)],
                            max_tokens=args.max_tokens, temperature=0.6, ignore_eos=True))
    path = Path(args.out)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text("".join(json.dumps(record) + "\n" for record in records), encoding="utf-8")
    print(json.dumps({"trace": str(path), "requests": len(records), "seed": args.seed,
                      "arrival_modes": ["wall: arrival_ms", "round: arrival_round (mechanism only)"],
                      "sha256": hashlib.sha256(path.read_bytes()).hexdigest()}, indent=2))


def read_trace(path):
    records = [json.loads(line) for line in Path(path).read_text(encoding="utf-8").splitlines() if line.strip()]
    if not records or len(records) > 10000:
        raise ValueError("trace must contain 1..10000 requests")
    ids = [record["request_id"] for record in records]
    if len(set(ids)) != len(ids):
        raise ValueError("trace request IDs must be unique")
    for record in records:
        for field in ("arrival_ms", "arrival_round"):
            value = record[field]
            if type(value) not in (int, float) or not math.isfinite(value) or value < 0:
                raise ValueError(f"{field} must be finite and nonnegative")
        if type(record["arrival_round"]) is not int:
            raise ValueError("arrival_round must be an integer")
    return records


def payload_of(record):
    return {key: record[key] for key in ("request_id", "prompt", "max_tokens", "temperature", "ignore_eos")
            if key in record}


def run_load(args):
    records = read_trace(args.trace)
    endpoints = parse_endpoints(args.endpoints) if args.endpoints else None
    if endpoints and args.mode != "wall":
        raise ValueError("round injection requires a local owner; HTTP supports wall arrivals")
    if endpoints and args.profile_dir:
        raise ValueError("profile the local GPU load or the serving worker; a client cannot profile remote workers")
    order = sorted(records, key=lambda item: item["arrival_ms" if args.mode == "wall" else "arrival_round"])
    if args.mode == "round" and [record["arrival_round"] for record in order] != list(range(len(order))):
        raise ValueError("round trace must inject one request at each round 0..N-1 to avoid idle gaps")
    log = JsonlLog(args.out)
    futures, errors = [], []
    result_lock = threading.Lock()
    slots = threading.BoundedSemaphore(args.max_clients)
    pool = ThreadPoolExecutor(max_workers=args.max_clients, thread_name_prefix="load-client")
    worker = None
    origin = None
    next_round_request = 0

    def dispatch(record, index, owner=None):
        if not slots.acquire(blocking=False):
            message = "load generator max-clients reached; arrival was rejected, not postponed"
            errors.append(dict(request_id=record["request_id"], error=message))
            local_event(log, "client_error", request_id=record["request_id"], detail=message)
            return
        sent_ns = time.perf_counter_ns()
        endpoint = endpoints[index % len(endpoints)] if endpoints else "local"
        dispatched_ns = sent_ns
        def record_arrival(actual_ns):
            local_event(log, "arrival", request_id=record["request_id"], endpoint=endpoint,
                        cohort=record.get("cohort"), offered_ms=record["arrival_ms"],
                        offered_round=record["arrival_round"], sent_ns=actual_ns, dispatched_ns=dispatched_ns,
                        arrival_lag_ms=(actual_ns - origin) / 1e6 - record["arrival_ms"] if args.mode == "wall" else None)
        if not endpoints:
            record_arrival(sent_ns)
        try:
            handle = (owner or worker).submit(**payload_of(record)) if not endpoints else None
        except Exception as error:
            errors.append(dict(request_id=record["request_id"], error=repr(error)))
            local_event(log, "client_error", request_id=record["request_id"], detail=repr(error))
            slots.release()
            return
        def consume():
            nonlocal sent_ns
            try:
                if endpoints:
                    sent_ns = time.perf_counter_ns()
                    record_arrival(sent_ns)
                    result = http_request(endpoint, payload_of(record), log, timeout=args.timeout, sent_ns=sent_ns)
                else:
                    def events():
                        while True:
                            event = handle.stream.get(timeout=args.timeout)
                            yield event
                            if event["event"] == "finished":
                                return
                    result = consume_stream(events(), log, request_id=record["request_id"],
                                            sent_ns=sent_ns, cancel=handle.cancel, timeout=args.timeout)
                result["cohort"] = record.get("cohort", "unspecified")
                return result
            except Exception as error:
                if handle:
                    handle.cancel()
                with result_lock:
                    errors.append(dict(request_id=record["request_id"], error=repr(error)))
                local_event(log, "client_error", request_id=record["request_id"], detail=repr(error))
                return None
            finally:
                slots.release()
        futures.append(pool.submit(consume))

    def boundary(owner, round_number):
        nonlocal next_round_request
        if next_round_request < len(order) and order[next_round_request]["arrival_round"] <= round_number:
            index = next_round_request
            dispatch(order[index], index, owner)
            next_round_request += 1

    try:
        local_event(log, "run_start", mode=args.mode, policy=None if endpoints else args.policy,
                    tp=None if endpoints else args.tp, endpoints=endpoints,
                    config_source="external_worker_unknown" if endpoints else "local_arguments",
                    batch_seqs=None if endpoints else args.batch_seqs,
                    warmup_requests=args.warmup_requests,
                    warmup_state="request_warmup" if args.warmup_requests else "initialization_only",
                    simulated=args.simulate if not endpoints else None,
                    profiling=bool(args.profile_dir), trace_sha256=hashlib.sha256(Path(args.trace).read_bytes()).hexdigest(),
                    cache_state="external_worker_history" if endpoints else "fresh_engine",
                    performance_eligible=args.mode == "wall" and not args.simulate and not args.profile_dir)
        if not endpoints:
            worker = build_worker(args, log)
            worker.start(timeout=args.startup_timeout)
        # Request-level warmup is explicit and outside the measured arrival window.
        # Distinct fixed prefixes avoid warming the measured trace's prefix cache.
        for endpoint in endpoints or ["local"]:
            for index in range(args.warmup_requests):
                payload = payload_of(order[index % len(order)])
                prompt = payload["prompt"]
                if not isinstance(prompt, list):
                    raise ValueError("request warmup requires a fixed token-ID trace")
                original_max = payload.get("max_tokens", 8)
                warmup_max = max(2, min(original_max, 8))
                extra_room = max(0, warmup_max - original_max)
                if extra_room:
                    prompt = prompt[:-extra_room]
                if not prompt:
                    raise ValueError("request warmup needs a nonempty prompt and room for Prefill + Decode")
                payload.update(request_id=f"warmup-{index:04d}",
                               prompt=[3 + ((token - 3 + 61) % 124) for token in prompt],
                               max_tokens=warmup_max, ignore_eos=True)
                sent_ns = time.perf_counter_ns()
                if endpoints:
                    result = http_request(endpoint, payload, log, timeout=args.timeout)
                else:
                    handle = worker.submit(**payload)
                    def warmup_events():
                        while True:
                            event = handle.stream.get(timeout=args.timeout)
                            yield event
                            if event["event"] == "finished":
                                return
                    result = consume_stream(warmup_events(), log, request_id=payload["request_id"],
                                            sent_ns=sent_ns, timeout=args.timeout)
                if result["reason"] != "completed":
                    raise RuntimeError("request warmup did not complete")
        if worker:
            worker.enable_profiling()
        origin = time.perf_counter_ns()
        local_event(log, "load_window_start", t_ns=origin)
        if args.mode == "round":
            worker.boundary_hook = boundary
            worker.wakeup.set()
            deadline = time.monotonic() + args.timeout
            while next_round_request < len(order):
                worker.check_health()
                if time.monotonic() > deadline:
                    raise TimeoutError("round workload stopped making progress")
                time.sleep(.005)
        else:
            for index, record in enumerate(order):
                delay = (origin + int(record["arrival_ms"] * 1e6) - time.perf_counter_ns()) / 1e9
                if delay > 0:
                    time.sleep(delay)
                dispatch(record, index)
        results = [result for future in futures if (result := future.result(timeout=args.timeout)) is not None]
        failed = [result for result in results if result["reason"] != "completed"]
        completed = [result for result in results if result["reason"] == "completed"]
        finished_ns = max((result["finished_ns"] for result in results), default=origin)
        first_submit_ns = min((result["sent_ns"] for result in results), default=origin)
        makespan = (finished_ns - first_submit_ns) / 1e9
        summary = dict(kind="e2e_load", mode=args.mode, policy=None if endpoints else args.policy,
                       tp=None if endpoints else args.tp,
                       requests_offered=len(order), completed=len(completed), terminal_failures=len(failed),
                       errors=errors, makespan_s=makespan,
                       accepted_tokens=sum(result["accepted_tokens"] for result in completed),
                       throughput_tokens_s=sum(result["accepted_tokens"] for result in completed) / makespan if makespan else None,
                       ttft_ms=quantiles([result["ttft_ms"] for result in completed]),
                       itl_ms=quantiles([value for result in completed for value in result["itl_ms"]]),
                       cohorts={cohort: {"requests": len(group := [result for result in completed if result["cohort"] == cohort]),
                                          "ttft_ms": quantiles([result["ttft_ms"] for result in group]),
                                          "itl_ms": quantiles([value for result in group for value in result["itl_ms"]])}
                                for cohort in sorted({result["cohort"] for result in completed})},
                       simulated=any(result["simulated"] for result in results) or bool(args.simulate and not endpoints),
                       profiling=bool(args.profile_dir) or any(result["profiling"] for result in results),
                       warmup_state="request_warmup" if args.warmup_requests else "initialization_only",
                       performance_eligible=args.mode == "wall" and not args.profile_dir and not errors and not failed
                           and bool(results) and not any(result["simulated"] or result["profiling"] for result in results))
        local_event(log, "load_window_end", t_ns=finished_ns, first_submit_ns=first_submit_ns)
        if worker:
            worker.close(timeout=args.shutdown_timeout)
            worker = None
        write_summary(args.out, summary)
        return 2 if errors or failed else 0
    finally:
        try:
            if worker:
                worker.close(timeout=args.shutdown_timeout)
        finally:
            pool.shutdown(wait=True, cancel_futures=True)
            log.close()


def run_serve(args):
    log = JsonlLog(args.out)
    worker = build_worker(args, log)
    server = None
    try:
        worker.start(timeout=args.startup_timeout)
        worker.enable_profiling()
        server = LocalServer(worker, args.port, max_clients=args.max_clients, stream_timeout=args.stream_timeout)
        server.timeout = .2
        print(json.dumps({"listening": f"http://127.0.0.1:{server.server_port}", "worker_id": args.worker_id,
                          "simulated": args.simulate}), flush=True)
        while not worker.done.is_set():
            server.handle_request()
        worker.check_health()
    except KeyboardInterrupt:
        pass
    finally:
        if server:
            server.server_close()
        try:
            worker.close(timeout=args.shutdown_timeout)
        finally:
            log.close()


def run_client(args):
    endpoints = parse_endpoints(args.endpoints)
    log = JsonlLog(args.out)
    try:
        payload = dict(request_id=args.request_id, prompt=args.prompt,
                       max_tokens=args.max_tokens, temperature=0.6, ignore_eos=True)
        if args.prompt_ids:
            payload["prompt"] = json.loads(args.prompt_ids)
        result = http_request(endpoints[0], payload, log, cancel_after=args.cancel_after,
                              read_delay_ms=args.read_delay_ms, timeout=args.timeout)
        write_summary(args.out, result)
        return 0 if result["reason"] in ("completed", "cancelled") else 2
    finally:
        log.close()


def simulate(args):
    log_file = JsonlLog(args.out)
    events, checks = [], []
    def log(event):
        events.append(event)
        log_file(event)
    def collect(handle):
        records = []
        while True:
            event = handle.stream.get(timeout=10)
            records.append(event)
            if event["event"] == "finished":
                break
        return records
    def create(**kwargs):
        return Worker(simulation_factory(**kwargs), log=log, event_capacity=256).start(timeout=5)
    try:
        worker = create()
        try:
            first = worker.submit("first", list(range(3, 15)), max_tokens=16)
            first_records = []
            while not any(event["event"] == "token" for event in first_records):
                first_records.append(first.stream.get(timeout=5))
            second = worker.submit("late", [3, 4, 5, 6], max_tokens=2)
            second_records = collect(second)
            first_records.extend(collect(first))
            assert first_records[-1]["reason"] == second_records[-1]["reason"] == "completed"
            assert [event["token_index"] for event in first_records if event["event"] == "token"] == list(range(1, 17))
            assert len([event for event in first_records if event["event"] == "finished"]) == 1
            first_token = next(event for event in first_records if event["event"] == "token")
            late_admission = next(event for event in second_records if event["event"] == "admitted")
            assert first_token["round"] == 3  # 12 input IDs / 4-token chunk, no candidate leakage
            assert late_admission["t_ns"] > first_token["t_ns"]
            assert second_records[-1]["t_ns"] < first_records[-1]["t_ns"]
            checks.extend(["two requests finish once", "late admission while earlier request is live",
                           "intermediate prefill candidates are not published", "short request leaves before long decode"])
            cancel = worker.submit("cancel", [3] * 9, max_tokens=128)
            survivor = worker.submit("survivor", [7, 8, 9], max_tokens=3)
            while cancel.stream.get(timeout=5)["event"] != "token":
                pass
            cancel.cancel()
            assert collect(cancel)[-1]["reason"] == "cancelled"
            assert collect(survivor)[-1]["reason"] == "completed"
            checks.append("cancel returns only target references; survivor completes")
            for request_id, prompt, maximum in (("empty", [], 1), ("bad-id", [128], 1),
                                               ("zero-output", [3], 0), ("context", [3] * 2048, 1)):
                assert collect(worker.submit(request_id, prompt, max_tokens=maximum))[-1]["reason"] == "rejected"
            checks.append("empty/out-of-vocabulary/output/context admission checks")
        finally:
            worker.close()
        assert worker.resources.engine.exited and worker.reserved_blocks == 0

        tiny = Worker(simulation_factory(total_blocks=1), log=log).start(timeout=5)
        try:
            assert collect(tiny.submit("too-large-kv", [3] * 16, max_tokens=2))[-1]["reason"] == "rejected"
        finally:
            tiny.close()
        checks.append("request larger than total KV capacity rejected before engine admission")

        full = Worker(simulation_factory(delay=.01), max_active=1, log=log).start(timeout=5)
        try:
            busy = full.submit("busy-active", [3], max_tokens=128)
            while busy.stream.get(timeout=5)["event"] != "token":
                pass
            queued = full.submit("cancel-while-full", [3], max_tokens=8)
            queued.cancel()
            assert collect(queued)[-1]["reason"] == "cancelled"
            assert not busy.finished and not queued.pending_slot
            assert full.pending_slots.acquire(blocking=False)
            full.pending_slots.release()
            busy.cancel()
            assert collect(busy)[-1]["reason"] == "cancelled"
        finally:
            full.close()
        checks.append("queued cancellation at next boundary even when active capacity is full")

        limited = Worker(simulation_factory(delay=.01, total_blocks=4), max_active=2, log=log).start(timeout=5)
        try:
            busy = limited.submit("reserved-active", [3], max_tokens=33)
            while busy.stream.get(timeout=5)["event"] != "token":
                pass
            head = limited.submit("reserved-head", [3], max_tokens=33)
            time.sleep(.03)
            head.cancel()
            assert collect(head)[-1]["reason"] == "cancelled"
            assert limited.reserved_blocks == 3 and not busy.finished
            busy.cancel()
            assert collect(busy)[-1]["reason"] == "cancelled"
        finally:
            limited.close()
        checks.append("KV-waiting head cancellation preserves the active request's reservation")

        stalled = Worker(simulation_factory(delay=.01), max_active=1, queue_depth=1,
                         event_capacity=2, log=log).start(timeout=5)
        try:
            slow = stalled.submit("slow", [3], max_tokens=128)
            time.sleep(.08)
            assert collect(slow)[-1]["reason"] == "slow_consumer"
            # Pause exactly at a boundary so queue-capacity check is deterministic.
            entered, release = threading.Event(), threading.Event()
            def gate(owner, round_number):
                entered.set()
                if not release.wait(5):
                    raise TimeoutError("simulation gate timed out")
            stalled.boundary_hook = gate
            assert entered.wait(5)
            pending = stalled.submit("queued", [3], max_tokens=1)
            try:
                stalled.submit("overflow", [3], max_tokens=1)
                raise AssertionError("full request queue was not rejected")
            except RequestRejected:
                pass
            pending.cancel()
            release.set()
            stalled.boundary_hook = None
            assert collect(pending)[-1]["reason"] == "cancelled"
        finally:
            stalled.close()
        checks.extend(["bounded output queue cancels slow consumer with a terminal",
                       "bounded request queue rejects overflow", "queued cancellation"])

        closing = create(delay=.01)
        active = closing.submit("close-active", [3], max_tokens=128)
        while active.stream.get(timeout=5)["event"] != "token":
            pass
        closing.close()
        assert collect(active)[-1]["reason"] == "closed"
        assert closing.resources.engine.exited
        checks.append("close drains live requests and checks zero allocator references")

        failure = create(fail_round=2)
        failed = failure.submit("failure", [3] * 12, max_tokens=8)
        assert collect(failed)[-1]["reason"] == "error"
        try:
            failure.close()
            raise AssertionError("worker failure was hidden")
        except RuntimeError:
            pass
        assert failure.resources.engine.exited
        checks.append("engine exception emits error and worker close raises")

        serving = create(delay=.01)
        server = LocalServer(serving, 0)
        thread = threading.Thread(target=server.serve_forever, kwargs={"poll_interval": .02}, daemon=True)
        thread.start()
        try:
            endpoint = f"http://127.0.0.1:{server.server_port}"
            result = http_request(endpoint, dict(request_id="http", prompt=[3] * 8, max_tokens=3), log)
            assert result["reason"] == "completed" and result["tokens_received"] == 3 and len(result["itl_ms"]) == 2
            result = http_request(endpoint, dict(request_id="http-cancel", prompt=[3], max_tokens=128), log, cancel_after=2)
            assert result["reason"] == "cancelled"
            checks.extend(["loopback HTTP JSONL stream and client TTFT/ITL", "HTTP request-id cancellation"])
        finally:
            server.shutdown()
            server.server_close()
            thread.join(timeout=5)
            serving.close()
        summary = dict(kind="CPU end-to-end simulation", simulated=True, gpu_executed=False,
                       performance_eligible=False, passed=True, checks=checks,
                       event_count=len(events), note="Synthetic Engine; validates request lifecycle and integration only.")
        write_summary(args.out, summary)
        return 0
    finally:
        log_file.close()


def common(parser):
    parser.add_argument("--source", help="existing source checkout; never patched automatically")
    parser.add_argument("--model", help="existing local model directory")
    parser.add_argument("--simulate", action="store_true", help="synthetic CPU engine, not GPU/performance evidence")
    parser.add_argument("--sim-step-ms", type=float, default=3)
    parser.add_argument("--tp", type=int, choices=range(1, 9), default=1)
    parser.add_argument("--policy", choices=("prefill_first", "balanced"), default="prefill_first")
    parser.add_argument("--dist-init", help="explicit per-replica loopback rendezvous; requires patch 04")
    parser.add_argument("--shm-name", help="explicit per-replica shared-memory name; requires patch 04")
    parser.add_argument("--worker-id", default="worker-0")
    parser.add_argument("--max-model-len", type=int, default=1024)
    parser.add_argument("--batch-tokens", type=int, default=256)
    parser.add_argument("--max-active", type=int, default=8)
    parser.add_argument("--batch-seqs", type=int, default=4)
    parser.add_argument("--queue-depth", type=int, default=32)
    parser.add_argument("--event-capacity", type=int, default=256)
    parser.add_argument("--gpu-memory-utilization", type=float, default=.8)
    mode = parser.add_mutually_exclusive_group()
    mode.add_argument("--eager", action="store_true")
    mode.add_argument("--graph", dest="eager", action="store_false")
    parser.set_defaults(eager=False)
    parser.add_argument("--profile-dir", help="GPU rank-0 trace after initialization; no performance conclusions")
    parser.add_argument("--startup-timeout", type=float, default=300)
    parser.add_argument("--shutdown-timeout", type=float, default=30)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest="command", required=True)
    cpu = commands.add_parser("simulate", help="run complete CPU integration checks")
    cpu.add_argument("--out", default="runs/runtime-cpu.jsonl")
    cpu.set_defaults(func=simulate)
    trace = commands.add_parser("trace", help="write a fixed short/late-long arrival trace")
    trace.add_argument("--out", default="workloads/mixed.jsonl")
    trace.add_argument("--requests", type=int, default=12)
    trace.add_argument("--prompt-tokens", type=int, default=32)
    trace.add_argument("--long-prompt-tokens", type=int, default=768)
    trace.add_argument("--long-every", type=int, default=4)
    trace.add_argument("--max-tokens", type=int, default=64)
    trace.add_argument("--interval-ms", type=float, default=40)
    trace.add_argument("--seed", type=int, default=17)
    trace.set_defaults(func=create_trace)
    load = commands.add_parser("load", help="replay trace against local worker or round-robin HTTP endpoints")
    common(load)
    load.add_argument("--trace", required=True)
    load.add_argument("--out", default="runs/load.jsonl")
    load.add_argument("--mode", choices=("wall", "round"), default="wall")
    load.add_argument("--endpoints")
    load.add_argument("--max-clients", type=int, default=64)
    load.add_argument("--timeout", type=float, default=120)
    load.add_argument("--warmup-requests", type=int, default=0,
                      help="per endpoint/local worker requests before measurement; default initialization only")
    load.set_defaults(func=run_load)
    serve = commands.add_parser("serve", help="loopback-only HTTP JSONL server")
    common(serve)
    serve.add_argument("--port", type=int, default=8801)
    serve.add_argument("--out", default="runs/server.jsonl")
    serve.add_argument("--max-clients", type=int, default=64)
    serve.add_argument("--stream-timeout", type=float, default=2)
    serve.set_defaults(func=run_serve)
    client = commands.add_parser("client", help="one request; load distributes multiple requests round-robin")
    client.add_argument("--endpoints", required=True)
    client.add_argument("--prompt", default="Hello")
    client.add_argument("--prompt-ids", help="JSON array overrides text prompt")
    client.add_argument("--request-id", default="demo")
    client.add_argument("--max-tokens", type=int, default=32)
    client.add_argument("--cancel-after", type=int)
    client.add_argument("--read-delay-ms", type=float, default=0)
    client.add_argument("--timeout", type=float, default=120)
    client.add_argument("--out", default="runs/client.jsonl")
    client.set_defaults(func=run_client)
    report = commands.add_parser("report", help="summarize or compare observer-separated load JSONL logs")
    report.add_argument("--inputs", required=True, help="comma-separated load event logs")
    report.add_argument("--out", default="runs/comparison.json", help="JSON output; also writes a sibling .md")
    report.set_defaults(func=run_report)
    args = parser.parse_args()
    for name in ("max_clients", "batch_tokens", "batch_seqs", "max_model_len", "max_active", "queue_depth", "event_capacity"):
        if hasattr(args, name) and getattr(args, name) < 1:
            parser.error(f"{name.replace('_', '-')} must be positive")
    if getattr(args, "warmup_requests", 0) < 0:
        parser.error("warmup-requests must be nonnegative")
    try:
        return args.func(args) or 0
    except Exception as error:
        print(f"ERROR: {error!r}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
