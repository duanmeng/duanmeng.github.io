"""Small, inspectable E2E inference practice; CPU simulation is not GPU evidence."""
