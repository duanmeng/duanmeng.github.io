# 第 5 章运行检查点

先完成手册 5.1；下列命令在实验包根目录、`.venv-nano` 已激活、`env.sh` 已加载的终端执行。上游源码始终在同一个学习分支修改。真实 GPU、Graph 和 NCCL 的结果需在实验机产生。

## 5.1–5.2 基线和正确性

```bash
CUDA_VISIBLE_DEVICES=0 python e2e/doctor.py | tee runs/setup-doctor.json
CUDA_VISIBLE_DEVICES=0 python e2e/smoke.py --model "$MODEL_DIR" 2>&1 | tee runs/setup-smoke.log
for case in A B C D; do
  CUDA_VISIBLE_DEVICES=0 python e2e/quick_walk.py --case "$case" --trace \
    --out "runs/quick-$case.json" 2>&1 | tee "runs/quick-$case.log"
done
```

按手册 5.2.5 执行 `logits_check.py collect` 的 nano/HF 两条命令，再 compare。运行完成应留下 `runs/engine-logits-check.json` 和原始 `.npz`，数值门槛需要校准。A/B/C/D 验收位置与队列；logits 验收计算，两者分别记录。

## 5.3 可观测服务和固定负载

```bash
python practice/run.py simulate --out runs/runtime-cpu.jsonl
python practice/run.py trace --out workloads/mixed.jsonl --requests 12 \
  --prompt-tokens 32 --long-prompt-tokens 768 --long-every 4 \
  --max-tokens 64 --interval-ms 40 --seed 17
CUDA_VISIBLE_DEVICES=0 python practice/run.py load \
  --source "$NANO_DIR" --model "$MODEL_DIR" --trace workloads/mixed.jsonl \
  --mode wall --warmup-requests 2 --policy prefill_first \
  --batch-tokens 256 --batch-seqs 4 --max-active 8 --tp 1 --eager \
  --out runs/prefill-first.jsonl
```

CPU 模拟检查输出 `runtime-cpu.summary.json`。真实负载在全部请求正常完成时应有 12 个终态、768 个正式输出；engine/client 各自记录一次观察，不能把两侧 token 事件相加。预热的请求 ID 有独立前缀，排除在报告中；两次请求预热仅是起点，正式性能还需验证所测批形状已充分预热。

本机 HTTP 的三个命令见手册 5.3.2：`serve` 常驻、`client` 单请求、`load --endpoints` 固定负载。服务监听 127.0.0.1；远程学习时，在 GPU 机器执行客户端或使用自己的 SSH 转发。

## 5.4 调度改造

```bash
git -C "$NANO_DIR" apply --check "$LAB_ROOT/patches/03-fair-scheduler.patch"
git -C "$NANO_DIR" apply "$LAB_ROOT/patches/03-fair-scheduler.patch"
python e2e/scheduler_practice.py --repo "$NANO_DIR" --out runs/scheduler-cpu.json
for policy in prefill_first balanced; do
  CUDA_VISIBLE_DEVICES=0 python practice/run.py load \
    --source "$NANO_DIR" --model "$MODEL_DIR" --trace workloads/mixed.jsonl \
    --mode wall --warmup-requests 2 --policy "$policy" \
    --batch-tokens 256 --batch-seqs 4 --max-active 8 --tp 1 --eager \
    --out "runs/scheduler-$policy.jsonl"
done
python practice/run.py report \
  --inputs runs/scheduler-prefill_first.jsonl,runs/scheduler-balanced.jsonl \
  --out runs/scheduler-comparison.json
```

补丁只应用一次。CPU 驱动从本地 Git 的固定提交提取原始基线到临时目录，并对照当前工作树；不更改你的源码。若使用没有 Git 的源码压缩包，可显式指定 `--original-repo` 指向未修改基线。

报告应 `same_trace=true`，核对两组完成数、发送滞后与资源配置后才读 TTFT/ITL。CPU 调度结果证明轮数和队列变化；真实负载结果才支持毫秒延迟与吞吐判断。

## 5.5 GPU 执行

在手册的 load 命令增加 `--profile-dir runs/profile-eager`，查看生成的 trace 与算子表。关闭 profiler 后再做性能对照。按照 B.5 验证 `02-graph-eager-fallback.patch` 并应用，再比较：

```bash
for execution in eager graph; do
  CUDA_VISIBLE_DEVICES=0 python practice/run.py load \
    --source "$NANO_DIR" --model "$MODEL_DIR" --trace workloads/mixed.jsonl \
    --mode wall --warmup-requests 2 --policy balanced \
    --batch-tokens 256 --batch-seqs 4 --max-active 8 --tp 1 --"$execution" \
    --out "runs/execution-$execution.jsonl"
done
python practice/run.py report \
  --inputs runs/execution-eager.jsonl,runs/execution-graph.jsonl \
  --out runs/execution-comparison.json
```

同时保留 B.5 的固定轨迹数值护栏。优化没提速也可以形成有效结论，但要用时间线和工作量解释。

## 5.6 两卡分工

应用 `04-replica-isolation.patch`，按手册分别启动两个独立进程；独立 GPU、端口和共享内存名。负载端用 `--endpoints` 轮询路由。随后结束自己的两个副本，改启动一个 TP=2 服务。

```bash
python practice/run.py load \
  --endpoints http://127.0.0.1:8801,http://127.0.0.1:8802 \
  --trace workloads/mixed.jsonl --mode wall --warmup-requests 2 \
  --out runs/replicas.jsonl
```

切换到 TP=2 且 ready 后：

```bash
python practice/run.py load --endpoints http://127.0.0.1:8801 \
  --trace workloads/mixed.jsonl --mode wall --warmup-requests 2 --out runs/tp2.jsonl
python practice/run.py report --inputs runs/replicas.jsonl,runs/tp2.jsonl \
  --out runs/parallel-comparison.json
```

HTTP 报告未探测服务端配置时将 policy/TP 标为 null；保留各服务的启动命令与日志来确认实际配置。每个方案使用独立的新启动实例或明确记录缓存历史。检查同一负载的所有 request_id，再比较同一窗口内的整体吞吐。小模型和轻负载未必从 TP 或两副本获益。

## 5.7 生命周期与证据

```bash
python practice/run.py client --endpoints http://127.0.0.1:8801 \
  --prompt Hello --max-tokens 64 --request-id cancel-demo \
  --cancel-after 3 --out runs/client-cancel.jsonl
python e2e/final_report.py --root "$LAB_ROOT" --init-notes
python e2e/final_report.py --root "$LAB_ROOT"
```

取消在安全边界执行，收到第三个 token 后提交取消可能最终收到第四个；核对终止原因和资源回收。慢消费者、入口满、排队取消、异常退出先跑 CPU 模拟，再在 GPU 上验证。报告只是证据索引，保持缺失项并填写原因。

## 遇到失败先看哪里

| 失败 | 第一检查点 |
| --- | --- |
| 补丁无法应用 | 当前源码 diff、固定提交与是否已经应用 |
| balanced 不被接受 | 03 是否应用、实际导入源码路径 |
| 多副本资源冲突 | 04、端口、共享内存名、自己遗留的进程 |
| 输出计数增加太早 | postprocess 接受边界、中间 Prefill chunk |
| 性能看似改善但完成量不同 | finished/error/rejected、同一输入轨迹与输出限制 |
| 取消后一直排队 | pending 队列回收与 owner 的安全边界 |
| Graph/TP 失败 | 从单卡 eager 基线开始，逐个恢复执行选项 |
