# E2E workload comparison

Each run retains its complete workload and tail. Throughput is aggregated across replicas in that run's one common wall-clock window.

Same trace: True. CPU simulation and profiling are not performance evidence.

| Run | Mode | Simulated / profile | Offered / admitted / completed | Accepted tokens | Full window (s) | Aggregate token/s | TTFT p50/p95 (ms) | ITL p50/p95 (ms) | Send lag p95 (ms) |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| replicas-cpu.jsonl | wall | True / False | 12 / 12 / 12 | 768 | 3.912 | 196.297 | 70.353 / 3181.527 | 8.010 / 9.182 | 10.057 |

## replicas-cpu.jsonl

Policy: None; TP: None; configuration source: external_worker_unknown.

Warmup: request_warmup; cache history: external_worker_history.

Finished: {"completed": 12}; errors: 0; duplicate terminals: 0.

Performance eligible: False. Eligibility excludes simulation/profiling/incomplete loads; it does not establish steady state or GPU validation.
