# E2E workload comparison

Each run retains its complete workload and tail. Throughput is aggregated across replicas in that run's one common wall-clock window.

Same trace: True. CPU simulation and profiling are not performance evidence.

| Run | Mode | Simulated / profile | Offered / admitted / completed | Accepted tokens | Full window (s) | Aggregate token/s | TTFT p50/p95 (ms) | ITL p50/p95 (ms) | Send lag p95 (ms) |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| prefill-first-cpu.jsonl | wall | True / False | 12 / 12 / 12 | 768 | 3.464 | 221.679 | 849.256 / 2723.029 | 4.654 / 4.762 | 10.008 |
| balanced-cpu.jsonl | wall | True / False | 12 / 12 / 12 | 768 | 4.280 | 179.453 | 1247.933 / 3558.088 | 9.116 / 9.203 | 9.350 |
| round-cpu.jsonl | round | True / False | 12 / 12 / 12 | 768 | 4.312 | 178.089 | 1446.772 / 3983.476 | 9.111 / 9.183 | unavailable |

## prefill-first-cpu.jsonl

Policy: prefill_first; TP: 1; configuration source: local_arguments.

Warmup: request_warmup; cache history: fresh_engine.

Finished: {"completed": 12}; errors: 0; duplicate terminals: 0.

Performance eligible: False. Eligibility excludes simulation/profiling/incomplete loads; it does not establish steady state or GPU validation.

## balanced-cpu.jsonl

Policy: balanced; TP: 1; configuration source: local_arguments.

Warmup: request_warmup; cache history: fresh_engine.

Finished: {"completed": 12}; errors: 0; duplicate terminals: 0.

Performance eligible: False. Eligibility excludes simulation/profiling/incomplete loads; it does not establish steady state or GPU validation.

## round-cpu.jsonl

Policy: balanced; TP: 1; configuration source: local_arguments.

Warmup: initialization_only; cache history: fresh_engine.

Finished: {"completed": 12}; errors: 0; duplicate terminals: 0.

Performance eligible: False. Eligibility excludes simulation/profiling/incomplete loads; it does not establish steady state or GPU validation.
