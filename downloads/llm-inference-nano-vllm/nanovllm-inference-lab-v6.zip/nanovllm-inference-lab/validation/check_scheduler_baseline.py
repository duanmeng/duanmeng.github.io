"""Validation artifact: local export fixture, never a fabricated Git commit.

Arguments: patched source directory, pristine source directory.
The fixture replaces only git object reads with known pristine file bytes.
Real Git patch checks and the full CPU scheduling scenarios still execute.
"""
import json
from pathlib import Path
import subprocess
import sys
from tempfile import TemporaryDirectory

sys.dont_write_bytecode = True
LAB = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(LAB / "e2e"))
import scheduler_practice as practice

repo, pristine = map(Path, sys.argv[1:3])
before = {str(p.relative_to(repo)): p.read_bytes() for p in repo.rglob("*") if p.is_file()}
checks = []
with TemporaryDirectory(prefix="scheduler-negative-check-") as temp:
    for name, args, expected in (
        ("missing_git_commit", ["--repo", str(repo)], "Cannot export the fixed baseline commit"),
        ("missing_patch", ["--repo", str(pristine), "--original-repo", str(pristine)], "patch is missing"),
        ("modified_explicit_baseline", ["--repo", str(repo), "--original-repo", str(repo)], "Pinned source hash mismatch"),
    ):
        output = Path(temp) / (name + ".json")
        result = subprocess.run([sys.executable, str(LAB / "e2e/scheduler_practice.py"),
                                 *args, "--out", str(output)], capture_output=True, text=True)
        assert result.returncode != 0 and expected in result.stderr, (name, result.stdout, result.stderr)
        assert not output.exists()
        checks.append(dict(name=name, check="PASS", exit_code=result.returncode,
                           diagnostic=result.stderr.strip()))

actual_git_read = practice.git_read
object_reads = []


def local_fixture_read(directory, *args):
    if args[0] == "rev-parse":
        assert args == ("rev-parse", "--verify", practice.PINNED_COMMIT + "^{commit}")
        object_reads.append("fixture commit-presence response; no Git object created")
        return (practice.PINNED_COMMIT + "\n").encode()
    if args[0] == "show":
        commit, rel = args[1].split(":", 1)
        assert commit == practice.PINNED_COMMIT and rel in practice.CPU_SOURCE_FILES
        object_reads.append("fixture pristine bytes: " + rel)
        return (pristine / rel).read_bytes()
    return actual_git_read(directory, *args)


practice.git_read = local_fixture_read
try:
    with practice.baseline_source(repo) as (exported, provenance):
        assert exported != repo and exported != pristine
        assert set(provenance["verified_sha256"]) == set(practice.CPU_SOURCE_FILES)
        for name, spec in practice.CASES.items():
            original = practice.run_case(exported, "prefill_first", spec)
            unchanged = practice.run_case(repo, "prefill_first", spec)
            assert original == unchanged, name
            assert practice.run_case(repo, "balanced", spec)["check"] == "PASS"
        exported_path = exported
    assert not exported_path.exists()
finally:
    practice.git_read = actual_git_read
after = {str(p.relative_to(repo)): p.read_bytes() for p in repo.rglob("*") if p.is_file()}
assert before == after
checks.append(dict(name="automatic_export_local_fixture", check="PASS",
    fixture_only=True, actual_git_commit_read=False, fabricated_git_objects=False,
    object_reads=object_reads, manifest_verified_files=list(practice.CPU_SOURCE_FILES),
    full_scheduler_scenarios=len(practice.CASES), temporary_export_removed=True,
    supplied_repository_unchanged=True))
result = dict(check="PASS", mode="EXPLICIT_PRISTINE_AND_LOCAL_EXPORT_FIXTURE_NOT_REAL_GIT_COMMIT_EXECUTION",
    user_command='python e2e/scheduler_practice.py --repo "$NANO_DIR" --out runs/scheduler-cpu.json',
    checks=checks, real_git_mode="NOT RUN: local source directories have no fixed Git object; network access was unavailable and no clone was attempted",
    explicit_mode_evidence="scheduler-practice.json: real pinned source hashes and five full CPU scenarios passed")
destination = LAB / "validation/scheduler-baseline-validation.json"
destination.write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps(result, indent=2))
