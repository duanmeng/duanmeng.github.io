# 实验包 v6：验证范围

本次发布的本地验证环境为 macOS CPU。目标运行环境仍为 Linux / Python 3.11.2 / CUDA 12.9 / A800。以下检查证明列明的有限路径，不代表已经运行过真实 GPU。

## 本次新增并验证

- `practice/run.py simulate`：单 owner、动态加入、逐 token 事件、输入校验、满活跃容量下的排队取消、生成中取消、有界队列、慢消费者、关闭和执行异常的 CPU 集成场景。模型由合成实现替代。
- 固定到达文件在 `wall` 和 `round` 模式下重放；12 条请求、768 个正式输出、终止集合与计数核对。按轮模式仅用于机制解释。
- 两个独立 CPU 进程通过真实本机 HTTP/JSONL 接口接收轮询路由；验证逐事件接收、取消和报告。GPU 后端未运行。
- `scheduler_practice.py` 调用真实 Scheduler、Sequence、BlockManager，对照原版、补丁默认策略和 balanced：原版与默认逐字段一致，长 Prefill/已有 Decode 的有限场景间隔从 6 轮降到 2 轮，三个 Decode 批次覆盖从两个请求增加到六个。轮数不是毫秒收益。
- 中间 Prefill chunk 的误发布为 0，结束时归还全部 KV 块；验证两种阶段受容量限制时的回退。
- 03/04 及 01/02/03/04 的应用、逆向检查通过，逆向后源码一致。04 的退出分支用模拟资源执行真实方法，覆盖幂等退出、owner unlink、超时和异常传播；真实 POSIX 共享内存、NCCL 未验证。
- Python 3.11 语法、教程 Bash 语法、HTML 导航、附件解压及完整性检查见发布记录。

## 保留的基线工具验证

`validation/` 保留既有 NumPy Attention、KV 等价、形状、页槽位、引用计数、抢占、预算和日志比较器的本地检查。旧验证记录中的环境、时间与版本表示该项检查发生的条件，不替代本次或实验机的 GPU 结果。

固定轨迹 logits 比较器的合成数据覆盖 PASS、REVIEW、FAIL，以及缺行、权重不一致、非有限数值等拒绝分支。Graph 分发的 CPU 替身检查仅证明 Python 路径选择，不运行 CUDA Graph。

## 必须在实验机完成

- 依赖导入、真实 CUDA 小计算、Qwen3 前向与 FlashAttention/Triton kernel。
- nano/HF BF16 logits、Graph eager/replay 数值与 KV 对照，校准初始误差门槛。
- CPU/CUDA profiler 输出、Graph 捕获、NCCL TP=2、多副本真实 IPC 和退出。
- 固定到达轨迹上的性能测量、不同批形状预热、冷/热前缀状态控制。
- 真实 GPU 在取消、过载、慢消费者与故障条件下的回收。

## 如何阅读报告

`COLLECTED` 只表示数值采集完整；比较器 PASS 表示该固定测试集满足给定阈值。REVIEW 要检查候选分数接近与误差分布。初始容差为教学起点，未在 A800 上校准。

`practice report` 把 engine/client 分开，使用一次负载跨所有副本的全局首提交至最后完成窗口；模拟和 profile 明确标注。`performance_eligible` 只排除若干明显不可用输入，不认证稳态、不自动证明 GPU 正确或两组资源条件相同。`--warmup-requests` 的少量请求预热也不保证覆盖所有模型形状。

本章服务仅监听 localhost，无生产鉴权、跨主机容错或完整资源隔离。它用于完成小而完整的工程学习闭环。
