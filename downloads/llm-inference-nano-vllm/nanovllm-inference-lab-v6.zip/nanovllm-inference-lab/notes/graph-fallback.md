# CUDA Graph 回退改造

状态：TODO（GPU 实测 / 未运行）

故障预测与复现：TODO（上限 20，捕获桶集合，batch 17 的原版行为）

改动：TODO（源码 diff；无覆盖桶时如何执行）

回归：TODO（batch 1/9/16/17/20 的实际路径、历史 KV、padding、logits 与新 KV 误差）

性能：TODO（不带探针的 benchmark；固定工作量、预热、重复、初始化和吞吐）

证据：runs/graph-before.json、runs/graph-fallback-check.json、runs/graph-fallback.diff

范围：TODO（运行时回退与捕获阶段配置支持的区别）
