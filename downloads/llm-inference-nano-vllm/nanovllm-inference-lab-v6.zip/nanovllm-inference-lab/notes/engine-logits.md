# nano 与 HF 逐步数值对照

状态：TODO（GPU 实测 / 未运行）

预测：TODO（相同前缀输入，哪些行来自完整 Prefill、分块 Prefill、Decode？）

命令与配置：TODO（权重指纹、源码 hash、dtype、后端、初始容差）

实际观察：TODO（最坏误差、相对 L2、top-1 一致行数、首个差异行）

证据：runs/engine-logits-check.json，runs/engine-nano.json/.npz，runs/engine-hf.json/.npz

结论与边界：TODO（固定轨迹前向覆盖；尚未覆盖采样、TP、取消等路径）
