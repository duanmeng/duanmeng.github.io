# Attention

状态：TODO（GPU 实测 / CPU 执行 / 静态推演 / 未运行）

预测：TODO

命令与配置：TODO

实际观察与日志路径：TODO

对应源码或公式：TODO

结论及适用条件：TODO

未解释的问题：TODO
