"""Collect topic-named evidence and notes; preserve unrun experiments as MISSING."""
import argparse
import hashlib
import json
from pathlib import Path

TOPICS = {
    "service-runtime": ("最小可观测服务", ["runtime-cpu.summary.json", "prefill-first.jsonl"]),
    "scheduling-change": ("跨轮调度改造", ["scheduler-cpu.json", "scheduler-comparison.json"]),
    "execution-change": ("GPU 执行定位与改进", ["execution-comparison.json"]),
    "parallel-service": ("两卡服务对照", ["parallel-comparison.json"]),
    "service-lifecycle": ("服务生命周期与回收", ["client-cancel.jsonl"]),
    "tokenizer": ("分词与采样", ["tokenizer.json"]),
    "attention": ("Attention", ["attention.json"]),
    "generation-timeline": ("生成时序", ["generation-timeline.json"]),
    "kv-cache-math": ("KV 缓存等价关系", ["kv-cache-math.json"]),
    "memory-budget": ("显存与延迟预算", ["memory-budget.json"]),
    "cached-forward": ("真实模型缓存对照", ["setup-doctor.json", "setup-smoke.log", "cached-forward-check.json"]),
    "engine-logits": ("nano 与 HF 逐步数值对照", ["engine-logits-check.json"]),
    "graph-fallback": ("CUDA Graph 回退改造", ["graph-before.json", "graph-fallback-check.json"]),
    "lifecycle": ("请求生命周期", ["lifecycle-check.json"]),
    "scheduler": ("调度与抢占", ["scheduler-check.json", "scheduler-preemption.json"]),
    "kv-pages": ("分页与槽位", ["kv-slots.json", "kv-slots-runtime.json"]),
    "prefix-cache": ("前缀复用", ["prefix-cache-check.json", "prefix-cache-refs.json"]),
    "model-execution": ("Runner 与模型执行", ["model-shapes.json", "runner-check.json", "model-shapes-check.json"]),
    "cuda-graph": ("CUDA Graph 对照", ["cuda-graph-comparison.json"]),
    "tensor-parallel": ("张量并行", ["tensor-parallel-shapes.json"]),
    "summary": ("整体调用链与结论", []),
}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", required=True)
    parser.add_argument("--init-notes", action="store_true")
    args = parser.parse_args()
    root = Path(args.root)
    notes = root / "notes"
    notes.mkdir(parents=True, exist_ok=True)
    if args.init_notes:
        for topic, (title, _) in TOPICS.items():
            file = notes / f"{topic}.md"
            if not file.exists():
                file.write_text(
                    f"# {title}\n\n状态：TODO（GPU 实测 / CPU 执行 / 静态推演 / 未运行）\n\n"
                    "预测：TODO\n\n命令与配置：TODO\n\n实际观察与日志路径：TODO\n\n"
                    "对应源码或公式：TODO\n\n结论及适用条件：TODO\n\n未解释的问题：TODO\n",
                    encoding="utf-8")
        print("Created missing topic notes; existing notes preserved.")
        return

    rows = []
    for topic, (title, files) in TOPICS.items():
        for name in files:
            file = root / "runs" / name
            state = "MISSING"
            if file.exists() and file.stat().st_size:
                state = "PRESENT"
                if file.suffix == ".json":
                    try:
                        data = json.loads(file.read_text(encoding="utf-8"))
                        if isinstance(data.get("runs"), list):
                            state = "RECORDED / REVIEW"
                            if any(run.get("simulated") or run.get("profiling") for run in data["runs"]):
                                state = "MECHANISM ONLY / REVIEW"
                        elif data.get("passed") is True and data.get("simulated") is True:
                            state = "CPU SIMULATION PASS"
                        else:
                            state = "PASS" if data.get("check") == "PASS" else "REVIEW"
                    except (json.JSONDecodeError, UnicodeDecodeError, AttributeError):
                        state = "INVALID JSON"
                elif name.endswith("smoke.log"):
                    from analyze import objects
                    state = "PASS" if any(
                        row.get("check") == "PASS"
                        and row.get("scope") == "nano eager actual generation"
                        for row in objects(file)) else "REVIEW"
            sha = hashlib.sha256(file.read_bytes()).hexdigest()[:12] if file.exists() else "-"
            rows.append((topic, title, name, state, sha))

    lines = [
        "# nano-vLLM 实验证据汇总", "",
        "按主题核对实际文件。PASS 表示对应脚本的检查通过；数值容差、性能解释与学习结论仍需人工复核。", "",
        "| 主题 | 文件 | 状态 | SHA256 前12位 |",
        "|---|---|---|---|",
    ]
    lines += [f"| {title} | runs/{name} | {state} | {sha} |"
              for _, title, name, state, sha in rows]
    lines += ["", "## 主题笔记", ""]
    complete = True
    for topic, (title, _) in TOPICS.items():
        file = notes / f"{topic}.md"
        status = "需补充" if not file.exists() or "TODO" in file.read_text(encoding="utf-8") else "已填写，待人工复核"
        if status == "需补充":
            complete = False
        lines.append(f"- {title}：{status}（notes/{topic}.md）")
    lines += [
        "", "## 入门主线证据", "",
        "- quick-A.json、modified-A.json、budget512.json、budget256.json 等对应单请求与调度预算练习，按所选实验分别保留。",
        "- engine-logits-check.json：nano 与 HF 沿固定 token 路径的逐步 logits 对照；数值通过后再改执行路径。",
        "- graph-before.json 的 PASS 仅表示复现预期错误；graph-fallback-check.json 的 PASS 才表示补丁后数值与路径检查通过。",
        "- 仅完成入门主线时，未选择的深入实验保持 MISSING，并在对应笔记说明。",
        "- 新主线：service-runtime → scheduling-change → execution-change → parallel-service → service-lifecycle；逐阶段命令见 CHECKPOINTS.md。",
        "- scheduler-cpu.json 执行真实调度状态流；runtime-cpu.summary.json 使用合成模型验证服务接口，二者均不是 GPU 前向或性能证明。",
        "- *-comparison.json 的 RECORDED 只代表已有报告，须逐项复核 same_trace、配置、warmup、simulated、profiling、完成数与原始日志。",
        "- 两卡报告采用同一次负载的全局首提交至最后完成窗口，不把各卡独立吞吐简单相加。",
        "", "## 验证范围", "",
        "- 张量并行静态形状与真实多卡运行分别记录。",
        "- cached-forward-check 的 PASS 检查位置计数与有限误差，数值等价性应结合 dtype 和误差容差判断。",
        "- engine-logits / graph-fallback 的容差为教学起点，必须保留原始误差；REVIEW 表示 top-1 存在差异，需要解释。",
        "- 保存原始 GPU 日志、实际依赖版本、源码 diff 与测量条件。",
    ]
    dest = root / "runs" / "final-report.md"
    dest.parent.mkdir(parents=True, exist_ok=True)
    dest.write_text("\n".join(lines) + "\n", encoding="utf-8")
    ready = all(row[3] == "PASS" for row in rows) and complete
    print(json.dumps({
        "report": str(dest),
        "evidence_and_notes_ready_for_review": ready,
        "missing_or_review": [name for _, _, name, state, _ in rows if state != "PASS"],
    }, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
