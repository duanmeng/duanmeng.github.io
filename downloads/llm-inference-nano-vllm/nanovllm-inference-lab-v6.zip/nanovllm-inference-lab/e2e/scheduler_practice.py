"""CPU end-to-end scheduling practice using the real Scheduler/BlockManager.

Run after applying 03-fair-scheduler.patch (04 is independent of this driver):
  python e2e/scheduler_practice.py --repo "$NANO_DIR" --out runs/scheduler-cpu.json

The original CPU source files are exported from the pinned Git commit to a
temporary directory and verified against source-manifest.json. For source
archives without Git objects, --original-repo accepts a pristine source directory
and verifies the same file hashes. Neither path changes the supplied repositories.

Synthetic sampled token IDs stand in for Runner output. No model, GPU, CUDA,
attention computation, wall-clock performance, or NCCL claim is made here.
Arrivals are fixed round numbers for mechanism inspection, not a load benchmark.
"""
import argparse
from collections import Counter
from contextlib import contextmanager
import hashlib
import json
from pathlib import Path
import subprocess
import sys
from tempfile import TemporaryDirectory
from types import SimpleNamespace

# Dynamic source imports must not create __pycache__ inside either repository.
sys.dont_write_bytecode = True
from cpu_scheduler import load_source


PINNED_COMMIT = "bb823b3e06983d71485a8e1f23715ebd87d98ef8"
CPU_SOURCE_FILES = ("nanovllm/sampling_params.py", "nanovllm/engine/sequence.py",
                    "nanovllm/engine/block_manager.py", "nanovllm/engine/scheduler.py")


def git_read(repo, *args):
    """Read Git objects or check a patch; never checkout, apply, or fetch."""
    try:
        result = subprocess.run(["git", "--no-replace-objects", "-C", str(repo), *args],
                                capture_output=True, timeout=30)
    except (OSError, subprocess.TimeoutExpired) as error:
        raise ValueError(f"Cannot run local Git check: {error}") from error
    if result.returncode:
        detail = result.stderr.decode("utf-8", errors="replace").strip()
        raise ValueError(detail or f"Git command failed: {' '.join(args)}")
    return result.stdout


def verify_source(root, manifest, files):
    verified = {}
    for rel in files:
        path = Path(root) / rel
        if not path.is_file():
            raise ValueError(f"Required source file is missing: {path}")
        actual = hashlib.sha256(path.read_bytes()).hexdigest()
        expected = manifest["sha256"].get(rel)
        if not expected or actual != expected:
            raise ValueError(f"Pinned source hash mismatch for {path}: expected {expected}, got {actual}")
        verified[rel] = actual
    return verified


@contextmanager
def baseline_source(repo, original_repo=None):
    manifest_path = Path(__file__).with_name("source-manifest.json")
    manifest = json.loads(manifest_path.read_text())
    if manifest.get("commit") != PINNED_COMMIT:
        raise ValueError(f"source-manifest.json must describe fixed commit {PINNED_COMMIT}")
    # Only the scheduler changes in this exercise. Preserve the real sequence,
    # sampling and KV-manager implementation used by the fixed baseline.
    verify_source(repo, manifest, CPU_SOURCE_FILES[:-1])
    patch = Path(__file__).resolve().parent.parent / "patches/03-fair-scheduler.patch"
    try:
        git_read(repo, "apply", "--reverse", "--check",
                 "--include=nanovllm/engine/scheduler.py", str(patch))
    except ValueError as error:
        raise ValueError("--repo must contain the applied 03-fair-scheduler.patch scheduler. "
                         "The patch is missing or its scheduler was changed; no files were modified. "
                         f"Git check: {error}") from error

    provenance = dict(commit=PINNED_COMMIT, manifest=str(manifest_path.resolve()),
                      scheduler_patch="03 reverse --check passed (scheduler only; 04 compatible)",
                      repository_modified=False)
    if original_repo:
        verified = verify_source(original_repo, manifest, CPU_SOURCE_FILES)
        yield Path(original_repo), dict(provenance, kind="manifest-verified explicit pristine source",
                                        source=str(Path(original_repo).resolve()), verified_sha256=verified)
        return

    hint = (f"Cannot export the fixed baseline commit {PINNED_COMMIT} from --repo. "
            "This command does not fetch or modify your checkout. Use a checkout containing that commit, "
            "or supply --original-repo /path/to/pristine-source; its required files must pass source-manifest.json hashes.")
    try:
        resolved = git_read(repo, "rev-parse", "--verify", f"{PINNED_COMMIT}^{{commit}}").decode().strip()
        if resolved != PINNED_COMMIT:
            raise ValueError(f"Commit resolved to unexpected value: {resolved}")
    except ValueError as error:
        raise ValueError(f"{hint}\nGit check: {error}") from error
    with TemporaryDirectory(prefix="nanovllm-scheduler-baseline-") as temp:
        root = Path(temp)
        for rel in CPU_SOURCE_FILES:
            try:
                content = git_read(repo, "show", f"{PINNED_COMMIT}:{rel}")
            except ValueError as error:
                raise ValueError(f"{hint}\nCould not export {rel}: {error}") from error
            path = root / rel
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_bytes(content)
        verified = verify_source(root, manifest, CPU_SOURCE_FILES)
        yield root, dict(provenance, kind="manifest-verified git show of fixed commit",
                         source=f"git:{PINNED_COMMIT}", verified_sha256=verified,
                         temporary_export_removed_after_run=True)


CASES = {
    "decode_with_long_prefill": dict(batch=2, budget=4, blocks=64,
        arrivals=[(0, "A", 2, 9), (2, "long", 20, 3)]),
    "running_over_batch_capacity": dict(batch=2, budget=8, blocks=64,
        arrivals=[(0, "A", 2, 8), (0, "B", 2, 8),
                  (2, "C", 2, 8), (2, "D", 2, 8),
                  (4, "E", 2, 8), (4, "F", 2, 8)]),
    "chunk_output_and_reclaim": dict(batch=2, budget=4, blocks=8,
        arrivals=[(0, "chunked", 10, 2)]),
    "prefill_capacity_fallback": dict(batch=2, budget=4, blocks=2,
        arrivals=[(0, "A", 3, 2), (1, "B", 8, 1)]),
    "decode_capacity_fallback": dict(batch=1, budget=4, blocks=3,
        arrivals=[(0, "A", 3, 5), (2, "B", 8, 2)]),
}


def run_case(repo, policy, spec):
    Seq, SP, Scheduler, _ = load_source(repo)
    Seq.block_size = 4  # Teaching size only; production Config uses multiples of 256.
    scheduler = Scheduler(SimpleNamespace(max_num_seqs=spec["batch"],
        max_num_batched_tokens=spec["budget"], eos=-1,
        kvcache_block_size=4, num_kvcache_blocks=spec["blocks"],
        scheduling_policy=policy))
    if policy == "balanced" and getattr(scheduler, "scheduling_policy", None) != policy:
        raise RuntimeError("--repo must have patches/03-fair-scheduler.patch applied")
    requests = {}
    labels = {}
    output_rounds = {}
    wait_streaks = {}
    max_wait = {}
    rounds = []
    bm = scheduler.block_manager

    def snapshot():
        return {
            "waiting": [labels[s.seq_id] for s in scheduler.waiting],
            "running": [labels[s.seq_id] for s in scheduler.running],
            "requests": {label: dict(status=s.status.name, total=len(s),
                cached=s.num_cached_tokens, scheduled=s.num_scheduled_tokens,
                completions=s.num_completion_tokens, is_prefill=s.is_prefill,
                blocks=list(s.block_table)) for label, s in requests.items()},
            "kv": dict(free=len(bm.free_block_ids), used=sorted(bm.used_block_ids),
                ref_counts=[block.ref_count for block in bm.blocks]),
        }

    def check_ownership():
        actual = Counter(block for seq in requests.values() for block in seq.block_table)
        assert set(actual) == bm.used_block_ids
        assert set(bm.free_block_ids).isdisjoint(bm.used_block_ids)
        assert len(bm.free_block_ids) + len(bm.used_block_ids) == spec["blocks"]
        assert len(set(bm.free_block_ids)) == len(bm.free_block_ids)
        assert all(block.ref_count == actual[block.block_id] for block in bm.blocks)
        assert all(s.num_scheduled_tokens == 0 for s in requests.values())
        assert all(not s.block_table for s in requests.values() if s.is_finished)

    for round_id in range(256):
        admitted = []
        for arrival_round, label, prompt_len, max_tokens in spec["arrivals"]:
            if arrival_round != round_id:
                continue
            # Disjoint prompt IDs avoid accidental cross-request prefix reuse.
            base = 1000 * (len(requests) + 1)
            seq = Seq(list(range(base, base + prompt_len)),
                      SP(max_tokens=max_tokens, ignore_eos=True))
            requests[label] = seq
            labels[seq.seq_id] = label
            output_rounds[label] = []
            wait_streaks[label] = max_wait[label] = 0
            scheduler.add(seq)
            admitted.append(label)
        if scheduler.is_finished():
            if round_id > max(row[0] for row in spec["arrivals"]):
                break
            continue
        before = snapshot()
        selected, is_prefill = scheduler.schedule()
        phase = "prefill" if is_prefill else "decode"
        assert selected and len(selected) <= spec["batch"]
        selected_labels = [labels[s.seq_id] for s in selected]
        counts_before = {labels[s.seq_id]: s.num_completion_tokens for s in selected}
        scheduled = snapshot()
        candidate_ids = [100000 + s.seq_id * 1000 + s.num_completion_tokens for s in selected]
        should_publish = {labels[s.seq_id]: not is_prefill or
            s.num_cached_tokens + s.num_scheduled_tokens == len(s) for s in selected}
        scheduler.postprocess(selected, candidate_ids, is_prefill)
        published = []
        discarded = []
        for seq, token_id in zip(selected, candidate_ids):
            label = labels[seq.seq_id]
            accepted = seq.num_completion_tokens - counts_before[label]
            assert accepted == int(should_publish[label])
            if accepted:
                assert seq.completion_token_ids[-1] == token_id
                output_rounds[label].append(round_id)
                published.append(dict(request=label, token_id=token_id,
                    output_index=seq.num_completion_tokens - 1, finished=seq.is_finished))
            else:
                discarded.append(dict(request=label, candidate_token_id=token_id,
                    reason="intermediate prefill chunk; postprocess did not append"))
        for label in before["running"]:
            wait_streaks[label] = 0 if label in selected_labels else wait_streaks[label] + 1
            max_wait[label] = max(max_wait[label], wait_streaks[label])
        check_ownership()
        rounds.append(dict(round=round_id, admitted=admitted, phase=phase,
            selected=selected_labels, before=before, scheduled=scheduled,
            synthetic_candidates=candidate_ids, published=published,
            discarded_candidates=discarded, after=snapshot()))
    else:
        raise RuntimeError("Practice did not drain in 256 rounds; inspect scheduling progress")
    assert scheduler.is_finished() and all(s.is_finished for s in requests.values())
    assert len(bm.free_block_ids) == spec["blocks"] and not bm.used_block_ids
    assert all(len(output_rounds[label]) == s.max_tokens for label, s in requests.items())
    gaps = {label: max((b - a for a, b in zip(values, values[1:])), default=0)
            for label, values in output_rounds.items()}
    return dict(check="PASS", config=dict(spec, block_size=4), rounds=rounds,
        summary=dict(total_rounds=len(rounds), peak_running=max(len(r["after"]["running"]) for r in rounds),
            output_rounds=output_rounds, max_output_round_gap=gaps,
            max_consecutive_running_wait_rounds=max_wait,
            discarded_chunk_candidates=sum(len(r["discarded_candidates"]) for r in rounds),
            final_free_blocks=len(bm.free_block_ids), final_used_blocks=len(bm.used_block_ids)))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo", required=True, help="source with 03 patch applied")
    parser.add_argument("--original-repo", help="optional pristine source archive; verified against source-manifest.json")
    parser.add_argument("--out", required=True)
    args = parser.parse_args()
    cases = {}
    with baseline_source(args.repo, args.original_repo) as (baseline_repo, provenance):
        for name, spec in CASES.items():
            original = run_case(baseline_repo, "prefill_first", spec)
            default = run_case(args.repo, "prefill_first", spec)
            balanced = run_case(args.repo, "balanced", spec)
            assert original == default, f"default policy changed in {name}"
            cases[name] = dict(original=original, balanced=balanced,
                              patched_default_matches_original=True)

    long = cases["decode_with_long_prefill"]
    before_gap = long["original"]["summary"]["max_output_round_gap"]["A"]
    after_gap = long["balanced"]["summary"]["max_output_round_gap"]["A"]
    assert before_gap > after_gap and after_gap <= 2
    rotation = cases["running_over_batch_capacity"]
    coverage = {}
    for policy in ("original", "balanced"):
        window = [r for r in rotation[policy]["rounds"] if r["round"] >= 5 and r["phase"] == "decode"][:3]
        coverage[policy] = sorted({label for r in window for label in r["selected"]})
    assert coverage["balanced"] == ["A", "B", "C", "D", "E", "F"]
    assert len(coverage["original"]) < 6
    assert rotation["balanced"]["summary"]["peak_running"] > CASES["running_over_batch_capacity"]["batch"]
    chunk = cases["chunk_output_and_reclaim"]["balanced"]
    assert chunk["summary"]["discarded_chunk_candidates"] == 2
    fallback = cases["decode_capacity_fallback"]["balanced"]["rounds"][3]
    assert fallback["phase"] == "prefill" and fallback["selected"] == ["B"]
    assert fallback["before"]["requests"]["A"]["blocks"] == fallback["after"]["requests"]["A"]["blocks"]
    result = dict(check="PASS", mode="CPU_REAL_SCHEDULER_SYNTHETIC_TOKENS_NOT_GPU",
        scope="Real schedule -> synthetic Runner candidate -> real postprocess -> KV ownership/reclaim",
        timing_scope="Round-based mechanism evidence only; no GPU throughput, TTFT, or ITL measurement",
        original_repo=provenance["source"], patched_repo=str(Path(args.repo).resolve()),
        baseline_kind=provenance["kind"], baseline_provenance=provenance,
        source_sha256={rel: hashlib.sha256((Path(args.repo) / rel).read_bytes()).hexdigest()
                       for rel in ("nanovllm/engine/scheduler.py", "nanovllm/engine/block_manager.py")},
        comparison=dict(existing_decode_max_output_round_gap=dict(before=before_gap, after=after_gap),
            requests_served_in_three_decode_rounds=coverage,
            chunk_candidates_published=0, all_cases_reclaim_all_kv=True,
            patched_default_matches_original=True), cases=cases,
        limits=["Phase alternation bounds consecutive feasible phases, not request latency in seconds.",
            "Decode rotation provides service to a finite runnable queue; continuous arrivals and KV pressure need separate load analysis.",
            "max_num_seqs is a per-batch limit; running may exceed it.",
            "Prompt KV is reserved as a whole even for chunked prefill; an individually impossible request still fails.",
            "Sequence.is_prefill retains its serialization meaning and is not redefined as the global batch phase."])
    target = Path(args.out)
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(json.dumps(result, indent=2, ensure_ascii=False) + "\n")
    print(json.dumps(dict(check=result["check"], mode=result["mode"],
        baseline_kind=result["baseline_kind"], comparison=result["comparison"],
        output=str(target.resolve())), indent=2, ensure_ascii=False))


if __name__ == "__main__":
    try:
        main()
    except (ValueError, OSError) as error:
        raise SystemExit(f"ERROR: {error}") from None
