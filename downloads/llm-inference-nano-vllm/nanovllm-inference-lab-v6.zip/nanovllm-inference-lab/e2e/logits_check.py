"""Teacher-forced nano/HF probes. GPU collection and CPU comparison are separate.

All forwards use the same prescribed token trajectory, never sampled output.
`collect` owns one TP=1 runner; run collectors sequentially (NCCL port 2333).
"""
import argparse
import hashlib
import importlib.metadata
import json
import math
from pathlib import Path
import sys


def cases(suite):
    if suite == "baseline":
        specs = [("short", [3]), ("page-boundary", [255]),
                 ("chunked-prefill", [700]), ("mixed-lengths", [3, 5])]
        steps = 3
    else:
        specs = [(f"batch-{n}", [3 + i % 3 for i in range(n)])
                 for n in [1, 9, 16, 17, 20]]
        steps = 2
    result = []
    for case_no, (name, lengths) in enumerate(specs):
        requests = []
        for i, length in enumerate(lengths):
            # Distinct first tokens prevent accidental prefix reuse in this test.
            start = 100 + case_no * 1000 + i * 10
            requests.append(dict(prompt=[start + j % 97 for j in range(length)],
                                 continuation=[8000 + i * 10 + j for j in range(steps)]))
        result.append(dict(name=name, requests=requests))
    return result


def row_key(name, request, step):
    return f"{name}/request-{request}/step-{step}"


def expected_rows(suite):
    return {row_key(c["name"], i, step): r["prompt"] + r["continuation"][:step]
            for c in cases(suite) for i, r in enumerate(c["requests"])
            for step in range(len(r["continuation"]))}


def digest(file):
    h = hashlib.sha256()
    with file.open("rb") as stream:
        for chunk in iter(lambda: stream.read(8 * 1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def model_fingerprint(model):
    model = Path(model).resolve()
    files = [model / "config.json", *sorted(model.glob("*.safetensors"))]
    if len(files) < 2 or not all(p.is_file() for p in files):
        raise ValueError("Expected config.json and local safetensors weights")
    return {p.name: digest(p) for p in files}


def save_json(file, data):
    file = Path(file)
    file.parent.mkdir(parents=True, exist_ok=True)
    file.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def collect(args):
    import numpy as np
    import torch

    if not torch.cuda.is_available():
        raise RuntimeError("GPU collection requires the prepared CUDA experiment environment")
    torch.manual_seed(0)
    torch.backends.cuda.matmul.allow_tf32 = False
    torch.backends.cudnn.allow_tf32 = False
    meta = dict(schema=1, backend=args.backend, execution=args.execution,
                suite=args.suite, completed=False, check="RUNNING", rows=[], trace=[],
                model=str(Path(args.model).resolve()), weights=model_fingerprint(args.model),
                trajectories=cases(args.suite), dtype="bfloat16", tp=1,
                gpu=torch.cuda.get_device_name(0), cuda=torch.version.cuda,
                versions={p: importlib.metadata.version(p)
                          for p in ["torch", "transformers", "numpy"]},
                scope="GPU teacher-forced logits; bypasses Sampler, not a generation benchmark")
    arrays = {}
    prefix = Path(args.out)
    prefix.parent.mkdir(parents=True, exist_ok=True)

    def record(key, inputs, logits, kv=None):
        assert key not in {r["key"] for r in meta["rows"]}, key
        index = len(meta["rows"])
        array_key = f"logits_{index}"
        arrays[array_key] = logits.detach().float().cpu().numpy().copy()
        row = dict(key=key, input_ids=inputs, logits=array_key)
        if kv is not None:
            row["kv"] = f"kv_{index}"
            arrays[row["kv"]] = kv.detach().float().cpu().numpy().copy()
        meta["rows"].append(row)

    try:
        with torch.inference_mode():
            if args.backend == "hf":
                from transformers import AutoModelForCausalLM
                model = AutoModelForCausalLM.from_pretrained(
                    args.model, torch_dtype=torch.bfloat16, attn_implementation="eager",
                    local_files_only=True).cuda().eval()
                meta["attention_backend"] = "HF eager attention, full-prefix use_cache=False"
                for key, ids in expected_rows(args.suite).items():
                    x = torch.tensor([ids], dtype=torch.long, device="cuda")
                    pos = torch.arange(len(ids), device="cuda").unsqueeze(0)
                    logits = model(x, position_ids=pos, use_cache=False).logits[0, -1]
                    record(key, ids, logits)
            else:
                collect_nano(args, meta, record)
        if args.expect_uncovered:
            raise AssertionError("Expected original Graph bucket failure, but the suite completed")
        assert {r["key"] for r in meta["rows"]} == set(expected_rows(args.suite))
        meta.update(completed=True, check="COLLECTED")
        np.savez_compressed(str(prefix) + ".npz", **arrays)
    except Exception as exc:
        meta.update(check="ERROR", error_type=type(exc).__name__, error=str(exc))
        save_json(str(prefix) + ".json", meta)
        raise
    save_json(str(prefix) + ".json", meta)
    print(json.dumps(dict(check=meta["check"], rows=len(meta["rows"]),
                          metadata=str(prefix) + ".json", scope=meta["scope"])))


def collect_nano(args, meta, record):
    import inspect
    import torch
    from nanovllm.config import Config
    from nanovllm.engine.model_runner import ModelRunner
    from nanovllm.engine.scheduler import Scheduler
    from nanovllm.engine.sequence import Sequence
    from nanovllm.sampling_params import SamplingParams
    from nanovllm.utils.context import reset_context

    config = Config(args.model, enforce_eager=args.execution == "eager", tensor_parallel_size=1,
                    max_num_seqs=20, max_num_batched_tokens=256, max_model_len=1024,
                    kvcache_block_size=256, gpu_memory_utilization=0.5)
    if config.hf_config.dtype != torch.bfloat16:
        raise ValueError("This experiment fixes the model dtype to BF16")
    Sequence.block_size = config.kvcache_block_size
    runner = ModelRunner(config, 0, [])
    meta.update(attention_backend="FlashAttention", source_file=inspect.getfile(ModelRunner),
                source_sha256=digest(Path(inspect.getfile(ModelRunner))),
                graph_buckets=list(getattr(runner, "graph_bs", [])),
                config=dict(max_num_seqs=20, token_budget=256, block_size=256,
                            max_model_len=1024, kv_blocks=config.num_kvcache_blocks))
    events = []
    hook = runner.model.register_forward_pre_hook(lambda *_: events.append("eager"))

    class ReplayProbe:
        def __init__(self, graph, bucket):
            self.graph, self.bucket = graph, bucket

        def replay(self):
            events.append(f"graph:{self.bucket}")
            return self.graph.replay()

    if args.execution == "graph":
        runner.graphs = {n: ReplayProbe(g, n) for n, g in runner.graphs.items()}

    def cache_at(slots):
        # Flatten only the physical page/slot axes. Keep K/V, layer, head, feature.
        index = torch.tensor(slots, device="cuda", dtype=torch.long)
        cache = runner.kv_cache.flatten(2, 3)
        return cache.index_select(2, index)

    try:
        for case in cases(args.suite):
            scheduler = Scheduler(config)  # fresh page allocation and prefix metadata per case
            requests = []
            by_id = {}
            for i, spec in enumerate(case["requests"]):
                seq = Sequence(spec["prompt"], SamplingParams(
                    max_tokens=len(spec["continuation"]), ignore_eos=True))
                requests.append(seq)
                by_id[seq.seq_id] = (i, spec)
                scheduler.add(seq)
            while not scheduler.is_finished():
                seqs, prefill = scheduler.schedule()
                row = dict(case=case["name"], phase="prefill" if prefill else "decode",
                           batch=len(seqs), scheduled=[s.num_scheduled_tokens for s in seqs],
                           cached=[s.num_cached_tokens for s in seqs],
                           blocks=[list(s.block_table) for s in seqs])
                meta["trace"].append(row)
                ids, pos = runner.prepare_prefill(seqs) if prefill else runner.prepare_decode(seqs)
                historical = []
                if args.suite == "graph" and not prefill:
                    historical = [s.block_table[p // 256] * 256 + p % 256
                                  for s in seqs for p in range(s.num_cached_tokens)]
                old_kv = cache_at(historical).clone() if historical else None
                events.clear()
                try:
                    logits = runner.run_model(ids, pos, prefill)
                except StopIteration:
                    # Recognize only the exact unpatched, uncovered Decode bucket case.
                    if (args.expect_uncovered and not prefill and len(seqs) in (17, 20)
                            and not any(n >= len(seqs) for n in runner.graph_bs)):
                        row["path"] = "uncovered-StopIteration"
                        meta.update(check="PASS", completed=False,
                                    scope="Expected original uncovered Graph bucket failure; no numerical PASS")
                        save_json(str(args.out) + ".json", meta)
                        print(json.dumps(dict(check="PASS", expected_failure=True, batch=len(seqs))))
                        # No npz is published for a partial run.
                        raise SystemExit(0)
                    raise
                finally:
                    reset_context()
                assert len(events) == 1, events
                row["path"] = events[0]
                if old_kv is not None:
                    row["historical_kv_unchanged"] = bool(torch.equal(old_kv, cache_at(historical)))
                    assert row["historical_kv_unchanged"], "Decode changed historical KV"
                if events[0].startswith("graph:"):
                    bucket = int(events[0].split(":")[1])
                    variables = runner.graph_vars
                    row["padding_safe"] = bool(
                        torch.all(variables["slot_mapping"][len(seqs):bucket] == -1)
                        and torch.all(variables["context_lens"][len(seqs):bucket] == 0))
                    assert row["padding_safe"], "Graph padding must skip KV writes"
                forced = []
                for n, seq in enumerate(seqs):
                    i, spec = by_id[seq.seq_id]
                    step = seq.num_completion_tokens
                    forced.append(spec["continuation"][step])
                    if prefill and seq.num_cached_tokens + seq.num_scheduled_tokens < len(seq):
                        continue  # intermediate chunk's candidate is discarded by postprocess
                    slot = seq.block_table[(len(seq) - 1) // 256] * 256 + (len(seq) - 1) % 256
                    kv = cache_at([slot]).squeeze(2) if args.suite == "graph" else None
                    record(row_key(case["name"], i, step), list(seq.token_ids), logits[n], kv)
                scheduler.postprocess(seqs, forced, prefill)
            assert all(s.is_finished and not s.block_table and s.num_cached_tokens == 0 for s in requests)
    finally:
        hook.remove()
        runner.exit()


def metrics(actual, reference, max_abs, rel_l2):
    import numpy as np
    a, b = np.asarray(actual, dtype=np.float64), np.asarray(reference, dtype=np.float64)
    if a.shape != b.shape or a.size == 0 or not np.isfinite(a).all() or not np.isfinite(b).all():
        return dict(pass_tolerance=False, invalid="shape/empty/nonfinite")
    diff = a - b
    absolute = float(np.max(np.abs(diff)))
    relative = float(np.linalg.norm(diff.ravel()) / max(float(np.linalg.norm(b.ravel())), 1e-12))
    return dict(max_abs=absolute, relative_l2=relative,
                pass_tolerance=absolute <= max_abs and relative <= rel_l2)


def compare(args):
    import numpy as np
    left = json.loads(Path(str(args.lhs) + ".json").read_text())
    right = json.loads(Path(str(args.rhs) + ".json").read_text())
    for name in ["schema", "suite", "trajectories", "weights", "dtype", "tp", "gpu", "versions"]:
        if left.get(name) != right.get(name):
            raise ValueError(f"Incomparable metadata: {name}")
    if not left["completed"] or not right["completed"]:
        raise ValueError("Both captures must be complete; a reproduced failure is not a numerical result")
    expected = expected_rows(left["suite"])
    def index(meta):
        rows = {r["key"]: r for r in meta["rows"]}
        if len(rows) != len(meta["rows"]) or set(rows) != set(expected):
            raise ValueError("Missing, duplicate or unexpected score rows")
        if any(r["input_ids"] != expected[k] for k, r in rows.items()):
            raise ValueError("Token trajectories differ")
        return rows
    lhs, rhs = index(left), index(right)
    results = []
    with np.load(str(args.lhs) + ".npz", allow_pickle=False) as la, np.load(str(args.rhs) + ".npz", allow_pickle=False) as ra:
        for key in expected:
            a, b = la[lhs[key]["logits"]], ra[rhs[key]["logits"]]
            result = dict(key=key, **metrics(a, b, args.max_abs, args.rel_l2))
            result["top1_same"] = bool(np.argmax(a) == np.argmax(b))
            top = np.sort(b.ravel())[-2:]
            result["reference_top1_margin"] = float(top[-1] - top[-2])
            if "kv" in lhs[key] and "kv" in rhs[key]:
                result["kv"] = metrics(la[lhs[key]["kv"]], ra[rhs[key]["kv"]], args.kv_max_abs, args.rel_l2)
            elif left["suite"] == "graph":
                raise ValueError("Graph comparison requires both current-position KV captures")
            results.append(result)
    routes = {}
    if left["suite"] == "graph":
        if left["execution"] != "graph" or right["execution"] != "eager":
            raise ValueError("Use patched graph as lhs and eager as rhs")
        wanted = {1: "graph:1", 9: "graph:16", 16: "graph:16", 17: "eager", 20: "eager"}
        for n, path in wanted.items():
            rows = [r for r in left["trace"] if r["phase"] == "decode" and r["batch"] == n]
            routes[str(n)] = bool(rows) and all(r["path"] == path and r.get("historical_kv_unchanged")
                                              and r.get("padding_safe", True) for r in rows)
    numeric = all(r["pass_tolerance"] and r.get("kv", {"pass_tolerance": True})["pass_tolerance"] for r in results)
    all_top1 = all(r["top1_same"] for r in results)
    status = "FAIL" if not numeric or not all(routes.values()) else ("PASS" if all_top1 else "REVIEW")
    report = dict(check=status, scope="GPU fixed-trajectory numerical comparison; finite test coverage",
                  lhs=str(args.lhs), rhs=str(args.rhs), suite=left["suite"], rows=len(results),
                  tolerances=dict(max_abs=args.max_abs, relative_l2=args.rel_l2, kv_max_abs=args.kv_max_abs),
                  tolerance_note="Initial educational guardrails, not empirically calibrated on A800; retain raw errors and review the baseline",
                  same_top1_rows=sum(r["top1_same"] for r in results), routes=routes, results=results)
    save_json(args.out, report)
    print(json.dumps({k: v for k, v in report.items() if k != "results"}, ensure_ascii=False, indent=2))
    return {"PASS": 0, "FAIL": 1, "REVIEW": 2}[status]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    c = sub.add_parser("collect")
    c.add_argument("--model", required=True)
    c.add_argument("--backend", choices=["nano", "hf"], required=True)
    c.add_argument("--execution", choices=["eager", "graph"], default="eager")
    c.add_argument("--suite", choices=["baseline", "graph"], default="baseline")
    c.add_argument("--expect-uncovered", action="store_true")
    c.add_argument("--out", required=True, help="artifact prefix, without extension")
    p = sub.add_parser("compare")
    p.add_argument("--lhs", required=True)
    p.add_argument("--rhs", required=True)
    p.add_argument("--out", required=True)
    p.add_argument("--max-abs", type=float, default=0.5)
    p.add_argument("--rel-l2", type=float, default=0.02)
    p.add_argument("--kv-max-abs", type=float, default=0.1)
    args = parser.parse_args()
    if args.command == "collect":
        if args.backend == "hf" and (args.execution != "eager" or args.suite != "baseline"):
            parser.error("HF reference is the eager full-prefix baseline suite")
        if args.expect_uncovered and (args.backend, args.execution, args.suite) != ("nano", "graph", "graph"):
            parser.error("--expect-uncovered requires nano + graph + graph suite")
        collect(args)
        return 0
    if not all(math.isfinite(x) and x > 0 for x in [args.max_abs, args.rel_l2, args.kv_max_abs]):
        parser.error("Tolerances must be positive")
    try:
        return compare(args)
    except Exception as exc:
        save_json(args.out, dict(check="ERROR", error_type=type(exc).__name__, error=str(exc)))
        raise


if __name__ == "__main__":
    sys.exit(main())
