# nano-vLLM 推理实验包 v5

本实验包配套《大模型推理入门与 nano-vLLM 源码详解》，沿单请求、单卡合批、独立副本、张量并行逐步学习。详细安装、命令与验收步骤见同目录的 **实验手册.html**，用浏览器打开即可阅读；命令在 GPU 实验机终端执行。

在线教程：https://bytedance.larkoffice.com/docx/KoiNd9URGohmWGxB2WlcOUA4ndh

## 固定基线

- 系统参考：Linux x86_64、Python 3.11.2、CUDA Toolkit 12.9、A800-SXM4-80GB；系统 CUDA 已可正常运行。
- 引擎：GeeeekExplorer/nano-vllm，提交 bb823b3e06983d71485a8e1f23715ebd87d98ef8。
- 模型：Qwen/Qwen3-0.6B，revision c1899de289a04d12100db370d81485cdf75e47ca。
- 参考 Python 依赖：requirements-nano.txt；CPU 练习依赖：requirements-cpu.txt。
- 包版本 v5，打包完整性由 SHA256SUMS 记录。GPU 安装与性能结果在实际实验机上验证，范围见 VALIDATION.md。

## 从哪里开始

ZIP 解压后得到 nanovllm-inference-lab/。先进入该目录，运行 sha256sum -c SHA256SUMS 核对完整性，再按实验手册完成：

1. 下载固定引擎源码、创建学习分支。
2. 创建 .venv-nano 并安装依赖，下载模型配置、Tokenizer 和权重。
3. 运行 doctor、smoke 和单请求 quick A。
4. 观察多请求、跨页、预算与前缀复用，用日志解释请求和缓存的变化。
5. 完成 5.3.7 的 nano/HF 固定轨迹 logits 对照，建立数值基线。
6. 按 5.4–5.6 逐步实现多副本路由，对照 TP，再增加异步流式与取消。附录 B 是按问题选择的深入练习，B.5 提供一个 Graph 回退边界修复。

入门完成标志：能解释三轮 Prefill/Decode 状态、读懂页与 slot、给出数值对照结果，并留下一个“复现—修改—回归”的完整记录。5.3.4 的动态入口和 5.3.6 的多轮驱动帮助把机制迁移到新的请求场景。

每次重新登录后：

```bash
source "$HOME/nanovllm-inference-lab/env.sh"
cd "$LAB_ROOT"
source .venv-nano/bin/activate
```

env.sh 根据自身位置设置 LAB_ROOT、NANO_DIR 与 MODEL_DIR，因此也可以放在其他工作目录。

## 目录职责

| 目录或文件 | 用途 |
|---|---|
| 实验手册.html | 完整安装、运行、观察和改造步骤 |
| e2e/ | Setup 检查、主题练习、源码阅读、日志分析和报告生成 |
| labs/ | Attention、缓存对照、引擎追踪和性能实验 |
| pedagogy/ | CPU 教学小模型 |
| patches/ | 源码日志补丁、02-graph-eager-fallback.patch |
| notes/ | 按主题填写的学习记录 |
| validation/ | 本次发布实际执行的 CPU 检查结果 |
| nano-vllm/ | Setup 时获取的固定上游源码 |
| models/Qwen3-0.6B/ | Setup 时下载的模型资产 |
| runs/ | 实验机产生的原始日志与验收结果 |

## 修改代码和记录结论

新增 `e2e/logits_check.py` 使用两个独立进程分别采集 nano-vLLM 和 Transformers 的 logits，输入固定 token 轨迹，跳过随机采样。原始数组保存为 `.npz`，配置与调度轨迹保存为 `.json`，比较结果单独输出。数值采集带探针，不能用于性能结论；性能使用 `labs/04_benchmark_nanovllm.py`。

具体命令、初始容差与退出码见 5.3.7；Graph 故障复现和补丁应用见 B.5。Graph 测试固定并发上限 20，覆盖 batch 1、9、16、17、20；补丁只处理运行时缺少覆盖桶的回退，未扩展为任意捕获配置支持。

引擎以 editable 方式安装，修改 nano-vllm/nanovllm/ 下的 Python 文件后重启实验进程即可生效。保留源码 diff，逐次改变一个机制，区分静态推演、CPU 检查与真实 GPU 结果。

日志按主题命名，例如 runs/lifecycle.log、runs/prefix-cache.log；笔记对应 notes/lifecycle.md、notes/prefix-cache.md。初始化笔记和汇总已有证据：

```bash
python e2e/final_report.py --root "$LAB_ROOT" --init-notes
python e2e/final_report.py --root "$LAB_ROOT"
```

笔记初始化保留已有文件。未运行项目在报告中保持 MISSING，先完成选择的学习路线，再根据问题补充深入实验。
