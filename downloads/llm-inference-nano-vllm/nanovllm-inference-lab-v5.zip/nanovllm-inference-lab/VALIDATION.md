# 实验包 v5：验证范围
本次发布在 macOS、Python 3.12.14、NumPy 2.3.5 和 xxhash 3.5.0 上执行 CPU 检查。实验手册面向 Linux / Python 3.11.2 / CUDA 12.9 / A800；以下结果只证明列明的检查通过。

## 已完成
- 固定源码 bb823b3e06983d71485a8e1f23715ebd87d98ef8 的清单核对：SOURCE PASS。
- 包内 Python 文件通过 Python 3.11 语法解析；手册 Bash 命令通过语法检查（数量见 validation-summary.json）。
- NumPy Attention、生成时序、KV 等价关系、显存预算、slot 寻址和 TP=1/2 形状推导通过。
- 执行固定源码中的 Scheduler / BlockManager，验证抢占、引用计数、A/B/C 三个案例的位置计数和 256/512/1024 预算。采样使用合成 token ID。
- 日志补丁和 Graph 回退补丁在临时源码副本上应用、解析、反向应用；还原文件逐字节一致。
- 从真实 ModelRunner 源码抽取 run_model，在 CPU 替身上验证原版找不到桶时抛出异常，补丁后桶内回放／越界回退分支。此检查验证 Python 分支，不执行 CUDA Graph。
- 固定源码 Scheduler 执行两组预设轨迹：基线 15 行、Graph 场景 126 行，验证分块候选丢弃、跨页和异长合批的对齐方式。
- logits 比较器的合成数据检查覆盖 PASS、REVIEW、FAIL，拒绝缺行、不完整采集、权重不一致与非有限数值。
- 16 个主题笔记可重复初始化，已有笔记保留。报告中的期望文件名与手册命令一致；缺少 GPU 结果时保留 MISSING。
- 详细结果见 validation/validation-summary.json 与同目录各主题 JSON。

## 需在实验机完成
- Linux / A800 上的依赖安装与实际 CUDA 运算。
- 完整引擎生成、FlashAttention / Triton kernel、GPU quick_walk。
- nano/HF BF16 逐步 logits 对照、Graph 回退的实际路径与 KV 检查、初始容差的实验机校准。
- CUDA Graph 捕获与回放、NCCL TP=2，以及吞吐和延迟测量。
- 多副本、异步入口、流式返回和取消等自行实现的改造任务。

## 如何解释 PASS
doctor 检查依赖导入和小 CUDA 运算；smoke 检查一次完整生成的数量与结构；quick_walk 检查指定案例的轮数、形状与输出长度。缓存对照中的误差需要结合 dtype 与容差判断。离线 benchmark 记录固定工作量下的吞吐；在线 TTFT / ITL 需在客户端额外观测。

logits_check 的 COLLECTED 只表示采集完整；compare 的 PASS 表示固定测试集满足给定误差与 top-1 门槛。REVIEW 表示数值门槛内出现 top-1 差异，退出码为 2；FAIL 为 1。`--expect-uncovered` 的 PASS 仅表示复现原版指定故障。默认误差阈值是教学起点，尚未在 A800 实测，不能当作生产认证。

CPU 逻辑验证、静态公式推导和真实 GPU 结果分开记录。validation/ 的结果可用于复查实验工具，不能作为 A800 性能结论。
