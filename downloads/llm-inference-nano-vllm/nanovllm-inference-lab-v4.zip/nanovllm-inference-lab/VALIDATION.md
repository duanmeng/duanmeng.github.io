# 实验包 v4：验证范围
本次发布在 macOS、Python 3.12.14、NumPy 2.3.5 和 xxhash 3.5.0 上执行 CPU 检查。实验手册面向 Linux / Python 3.11.2 / CUDA 12.9 / A800；以下结果只证明列明的检查通过。

## 已完成
- 固定源码 bb823b3e06983d71485a8e1f23715ebd87d98ef8 的清单核对：SOURCE PASS。
- 包内 Python 文件通过 Python 3.11 语法解析；手册 33 段 Bash 命令通过语法检查。
- NumPy Attention、生成时序、KV 等价关系、显存预算、slot 寻址和 TP=1/2 形状推导通过。
- 执行固定源码中的 Scheduler / BlockManager，验证抢占、引用计数、A/B/C 三个案例的位置计数和 256/512/1024 预算。采样使用合成 token ID。
- 日志补丁在临时源码副本上应用、解析、反向应用；还原文件逐字节一致。
- 14 个主题笔记可重复初始化，已有笔记保留。报告中的期望文件名与手册命令一致；缺少 GPU 结果时保留 MISSING。
- 详细结果见 validation/validation-summary.json 与同目录各主题 JSON。

## 需在实验机完成
- Linux / A800 上的依赖安装与实际 CUDA 运算。
- 完整引擎生成、FlashAttention / Triton kernel、GPU quick_walk。
- CUDA Graph 捕获与回放、NCCL TP=2，以及吞吐和延迟测量。
- 多副本、异步入口、流式返回和取消等自行实现的改造任务。

## 如何解释 PASS
doctor 检查依赖导入和小 CUDA 运算；smoke 检查一次完整生成的数量与结构；quick_walk 检查指定案例的轮数、形状与输出长度。缓存对照中的误差需要结合 dtype 与容差判断。离线 benchmark 记录固定工作量下的吞吐；在线 TTFT / ITL 需在客户端额外观测。

CPU 逻辑验证、静态公式推导和真实 GPU 结果分开记录。validation/ 的结果可用于复查实验工具，不能作为 A800 性能结论。
