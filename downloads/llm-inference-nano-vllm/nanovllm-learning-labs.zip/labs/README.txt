大模型推理入门与 nano-vLLM 源码详解：配套实验

正文：https://bytedance.larkoffice.com/docx/KoiNd9URGohmWGxB2WlcOUA4ndh
源码：GeeeekExplorer/nano-vllm
固定提交：bb823b3e06983d71485a8e1f23715ebd87d98ef8（0.2.0）
模型：Qwen/Qwen3-0.6B
模型 revision：c1899de289a04d12100db370d81485cdf75e47ca
核对日期：2026-09-06

将压缩包解压到 nano-vllm 仓库目录。包内的 labs/ 不会替换原仓库文件。
激活与正文第 6 章一致的环境，在仓库目录运行：

python -m pip install numpy
python labs/01_attention_numpy.py

MODEL_DIR="$HOME/huggingface/Qwen3-0.6B"
python labs/02_cached_forward.py --model "$MODEL_DIR" --device cuda
python labs/03_trace_nanovllm.py --model "$MODEL_DIR" --case lifecycle
python labs/03_trace_nanovllm.py --model "$MODEL_DIR" --case chunk
python labs/03_trace_nanovllm.py --model "$MODEL_DIR" --case prefix
python labs/04_benchmark_nanovllm.py --model "$MODEL_DIR" --eager
python labs/04_benchmark_nanovllm.py --model "$MODEL_DIR"

01 只需要 Python 和 NumPy。它使用人为设置的单头 Attention，不是自然语言模型。
02 需要 torch、transformers 和本地模型。它使用固定 token 路径比较 cache，不随机生成后续输入。
03 和 04 需要固定提交的 nano-vLLM，以及可用的 CUDA、NCCL、FlashAttention 与 GPU。
03 日志会同步 GPU，只用于学习，不能作为性能测量。
04 为每组配置独立启动进程；不要同时运行多个 nano 实例（固定 NCCL 端口和共享内存名）。
04 默认每轮 16×32=512 个输出 token，单独记录初始化时间，预热后测三轮。
04 显存字段只采集 rank 0；TP 实验需要逐卡采集才能得到总显存。

验证范围：
- 01 已在写作机器执行，因果 mask 和 cache 等价断言通过；输出见 verified_cpu_output.txt。
- 四个脚本均通过 Python 语法检查，03/04 的参数与固定源码已核对。
- 写作机器无 PyTorch/NVIDIA GPU 运行环境，02–04 尚未做 GPU 实跑。
- 不包含假造的 GPU 吞吐、延迟或正确性结果；请在你的环境运行并记录实际结果。

更多参数：python labs/02_cached_forward.py --help 等。
正文第 15 章说明每个实验的预期现象、测量边界和结果解释。
