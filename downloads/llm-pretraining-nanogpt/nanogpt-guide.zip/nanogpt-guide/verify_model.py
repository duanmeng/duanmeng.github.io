"""CPU checks for pinned nanoGPT; run from its repository root.

These verify tensor algebra and autograd, not multi-GPU communication.
python /path/to/verify_model.py --repo .
"""
import argparse
import copy
import importlib.util
import json
from pathlib import Path

import torch
import torch.nn.functional as F


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--repo', default='.')
    args = ap.parse_args()
    spec = importlib.util.spec_from_file_location('nanogpt_model', Path(args.repo) / 'model.py')
    module = importlib.util.module_from_spec(spec)
    # dataclasses consults sys.modules when resolving types.
    import sys
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    torch.set_num_threads(1)
    torch.manual_seed(7)
    config = module.GPTConfig(n_layer=2, n_head=2, n_embd=16,
                             vocab_size=19, block_size=8, dropout=0.0, bias=True)
    model = module.GPT(config).double().eval()
    x = torch.randint(0, config.vocab_size, (2, 8))
    target = torch.randint(0, config.vocab_size, (2, 8))
    logits, loss = model(x, target)
    changed = x.clone()
    changed[:, 4:] = (changed[:, 4:] + 1) % config.vocab_size
    changed_logits, _ = model(changed, target)
    torch.testing.assert_close(logits[:, :4], changed_logits[:, :4], rtol=0, atol=0)
    assert model.transformer.wte.weight is model.lm_head.weight
    only_last, _ = model(x)
    torch.testing.assert_close(only_last, logits[:, -1:])
    generated = model.generate(x[:, :2], 3, top_k=5)
    assert generated.shape == (2, 5)

    # Two MLP output-column shards; the output projection's bias is added once.
    mlp = model.transformer.h[0].mlp
    inp = torch.randn(2, 8, config.n_embd, dtype=torch.float64, requires_grad=True)
    ref = mlp(inp)
    w1s = mlp.c_fc.weight.chunk(2, dim=0)
    b1s = mlp.c_fc.bias.chunk(2, dim=0)
    w2s = mlp.c_proj.weight.chunk(2, dim=1)
    partials = [F.linear(F.gelu(F.linear(inp, w1, b1)), w2)
                for w1, b1, w2 in zip(w1s, b1s, w2s)]
    split = partials[0] + partials[1] + mlp.c_proj.bias
    torch.testing.assert_close(split, ref, rtol=1e-10, atol=1e-12)
    params = (inp, *mlp.parameters())
    grad_ref = torch.autograd.grad(ref.square().mean(), params)
    grad_split = torch.autograd.grad(split.square().mean(), params)
    for a, b in zip(grad_ref, grad_split):
        torch.testing.assert_close(a, b, rtol=1e-9, atol=1e-12)

    # Logical pipeline boundary, in one process; the tied parameter stays shared.
    partitioned = copy.deepcopy(model)
    pos = torch.arange(x.size(1))
    hidden = partitioned.transformer.drop(partitioned.transformer.wte(x) +
                                          partitioned.transformer.wpe(pos))
    hidden = partitioned.transformer.h[0](hidden)  # stage 0 output
    hidden = partitioned.transformer.h[1](hidden)  # stage 1 input
    pp_logits = partitioned.lm_head(partitioned.transformer.ln_f(hidden))
    pp_loss = F.cross_entropy(pp_logits.reshape(-1, config.vocab_size), target.reshape(-1))
    torch.testing.assert_close(pp_logits, logits, rtol=0, atol=0)
    loss.backward()
    pp_loss.backward()
    for (name, p), (other_name, q) in zip(model.named_parameters(), partitioned.named_parameters()):
        assert name == other_name
        torch.testing.assert_close(p.grad, q.grad, rtol=0, atol=0)
    print(json.dumps({'causality': 'passed', 'weight_tying': 'passed',
                      'last_position_logits_and_generation': 'passed',
                      'mlp_two_shards_output_and_gradients': 'passed',
                      'logical_pipeline_output_and_gradients': 'passed',
                      'device': 'cpu', 'distributed_communication_tested': False}, indent=2))


if __name__ == '__main__':
    main()
