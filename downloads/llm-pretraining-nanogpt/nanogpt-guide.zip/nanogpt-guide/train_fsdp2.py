"""Teaching extension for nanoGPT 3adf61e, PyTorch 2.9.x, CUDA/NCCL.

Copy next to nanoGPT/model.py. This is a separate small training entry point.
It uses FP32, dropout=0, one microbatch/update and no clipping/compile/AMP.
All ranks participate in evaluation, DCP, and optional full-model export.
GPU execution must be validated on the target hardware before scaling up.
"""
import argparse
import json
import os
import pickle
from pathlib import Path

import numpy as np
import torch
import torch.distributed as dist
import torch.distributed.checkpoint as dcp
from torch.distributed.checkpoint.state_dict import (
    StateDictOptions, get_model_state_dict, get_state_dict, set_state_dict,
)
from torch.distributed.device_mesh import init_device_mesh
from torch.distributed.fsdp import fully_shard
from model import GPT, GPTConfig


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--dataset', default='shakespeare_char')
    parser.add_argument('--out-dir', default='out-fsdp2')
    parser.add_argument('--resume', default=None, help='Completed step-N directory')
    parser.add_argument('--steps', type=int, default=20)
    parser.add_argument('--batch-size', type=int, default=4, help='Per rank')
    parser.add_argument('--block-size', type=int, default=32)
    parser.add_argument('--n-layer', type=int, default=2)
    parser.add_argument('--n-head', type=int, default=2)
    parser.add_argument('--n-embd', type=int, default=64)
    parser.add_argument('--lr', type=float, default=1e-3)
    parser.add_argument('--eval-interval', type=int, default=10)
    parser.add_argument('--eval-iters', type=int, default=2)
    parser.add_argument('--export', action='store_true', help='Also export sample.py compatible ckpt.pt')
    args = parser.parse_args()
    if not torch.cuda.is_available():
        raise SystemExit('This FSDP2 example requires CUDA; use config_smoke.py for the CPU baseline.')
    if min(args.steps, args.batch_size, args.block_size, args.eval_interval, args.eval_iters) < 1:
        raise ValueError('Steps, batch/context sizes and evaluation settings must be positive.')
    local_rank = int(os.environ['LOCAL_RANK'])
    torch.cuda.set_device(local_rank)
    dist.init_process_group('nccl')
    try:
        rank, world = dist.get_rank(), dist.get_world_size()
        device = torch.device('cuda', local_rank)
        data_dir = Path('data') / args.dataset
        # These are the metadata files produced by our own prepare.py run.
        with (data_dir / 'meta.pkl').open('rb') as f:
            meta = pickle.load(f)
        arrays = {s: np.memmap(data_dir / f'{s}.bin', dtype=np.uint16, mode='r')
                  for s in ('train', 'val')}
        if any(len(a) <= args.block_size for a in arrays.values()):
            raise ValueError('Each split must contain more tokens than block_size.')
        model_args = dict(n_layer=args.n_layer, n_head=args.n_head,
                          n_embd=args.n_embd, block_size=args.block_size,
                          vocab_size=meta['vocab_size'], dropout=0.0, bias=False)
        # FSDP2 does not supply DDP's initial broadcast. All ranks initialize alike.
        torch.manual_seed(1337)
        model = GPT(GPTConfig(**model_args)).to(device)
        mesh = init_device_mesh('cuda', (world,))
        for block in model.transformer.h:
            fully_shard(block, mesh=mesh, reshard_after_forward=True)
        # wte and lm_head share a parameter: keep both in this root group.
        fully_shard(model, mesh=mesh, reshard_after_forward=True)
        params = list(model.parameters())
        optimizer = torch.optim.AdamW([
            {'params': [p for p in params if p.dim() >= 2], 'weight_decay': 0.1},
            {'params': [p for p in params if p.dim() < 2], 'weight_decay': 0.0},
        ], lr=args.lr, betas=(0.9, 0.95), foreach=False, fused=False)
        generators = {s: torch.Generator().manual_seed(2027 + rank + 10000 * i)
                      for i, s in enumerate(('train', 'val'))}
        settings = dict(model_args=model_args, world_size=world, dataset=args.dataset,
                        batch_size=args.batch_size, lr=args.lr,
                        eval_interval=args.eval_interval, eval_iters=args.eval_iters)
        step = 0
        if args.resume:
            folder = Path(args.resume)
            saved = json.loads((folder / 'completed.json').read_text())
            if saved['settings'] != settings:
                raise ValueError('This teaching resume path requires identical model, world size and run settings.')
            model_sd, optim_sd = get_state_dict(model, optimizer)
            state = {'model': model_sd, 'optimizer': optim_sd}
            dcp.load(state, checkpoint_id=str(folder / 'dcp'))
            set_state_dict(model, optimizer, model_state_dict=state['model'],
                           optim_state_dict=state['optimizer'])
            rng = torch.load(folder / f'rng-{rank}.pt', map_location='cpu', weights_only=True)
            torch.set_rng_state(rng['cpu'])
            torch.cuda.set_rng_state(rng['cuda'], device)
            for split in generators:
                generators[split].set_state(rng[split])
            step = saved['step']

        def batch(split):
            a = arrays[split]
            starts = torch.randint(len(a) - args.block_size, (args.batch_size,),
                                   generator=generators[split]).tolist()
            x = np.stack([a[i:i + args.block_size] for i in starts]).astype(np.int64)
            y = np.stack([a[i + 1:i + 1 + args.block_size] for i in starts]).astype(np.int64)
            return torch.from_numpy(x).to(device), torch.from_numpy(y).to(device)

        @torch.no_grad()
        def evaluate():
            model.eval()
            total = torch.zeros((), device=device)
            for _ in range(args.eval_iters):
                _, loss = model(*batch('val'))
                total += loss.detach()
            # Equal B/T and no ignored targets: equal weighting is appropriate here.
            dist.all_reduce(total, op=dist.ReduceOp.SUM)
            model.train()
            return (total / (world * args.eval_iters)).item()

        while step < args.steps:
            optimizer.zero_grad(set_to_none=True)
            _, loss = model(*batch('train'))
            loss.backward()
            optimizer.step()
            step += 1
            if step % args.eval_interval == 0:
                val_loss = evaluate()  # Must run on every rank.
                if rank == 0:
                    print(f'step={step} val_loss={val_loss:.6f}', flush=True)

        # Create a new directory for this completed update count; do not overwrite.
        root = Path(args.out_dir)
        folder = root / f'step-{step}'
        exists = [folder.exists() if rank == 0 else None]
        dist.broadcast_object_list(exists, src=0)
        if exists[0]:
            raise FileExistsError(f'Checkpoint directory already exists: {folder}')
        if rank == 0:
            folder.mkdir(parents=True)
        dist.barrier()
        model_sd, optim_sd = get_state_dict(model, optimizer)
        dcp.save({'model': model_sd, 'optimizer': optim_sd}, checkpoint_id=str(folder / 'dcp'))
        torch.save(dict(cpu=torch.get_rng_state(), cuda=torch.cuda.get_rng_state(device),
                        **{s: g.get_state() for s, g in generators.items()}),
                   folder / f'rng-{rank}.pt')
        dist.barrier()
        if rank == 0:
            (folder / 'completed.json').write_text(json.dumps(
                {'step': step, 'settings': settings}, indent=2))
        dist.barrier()
        if args.export:
            # This collective gathers a full CPU state dict on rank 0.
            full = get_model_state_dict(model, options=StateDictOptions(
                full_state_dict=True, cpu_offload=True))
            if rank == 0:
                sample_dir = folder / 'sample'
                sample_dir.mkdir()
                torch.save({'model': full, 'model_args': model_args,
                            'config': {'dataset': args.dataset}}, sample_dir / 'ckpt.pt')
        if rank == 0:
            print(f'Saved completed update {step}: {folder}', flush=True)
    finally:
        dist.destroy_process_group()


if __name__ == '__main__':
    main()
