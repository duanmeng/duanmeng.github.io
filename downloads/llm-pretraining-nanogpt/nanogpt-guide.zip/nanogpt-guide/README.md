# nanoGPT 项目实战配套文件

按第六章端到端流程、第七章分布式改造组织。固定源码：
https://github.com/karpathy/nanoGPT/tree/3adf61e154c3fe3fca428ad6bc3818b27a3b8291

上游已将 nanoGPT 标为历史项目；本包用于理解紧凑的 GPT-2 风格模型和训练流程。不是 nanochat / build-nanogpt 的使用说明。

## 重排状态

2026-09-14：飞书在线正文已完成第 6—7 章重排，并通过页面核对章节、代码显示与配图。三张图内容保留，对应位置为项目关系 6.2、训练流程 6.4、并行改造 7.4。本包的配套阅读稿与线上章节顺序一致，保留更完整的固定版本源码片段，适合离线阅读。

## 文件

- `第六章-nanoGPT端到端与源码解读.md`：先跑通训练，再沿数据、模型、更新、验证、保存与生成下钻源码。
- `第七章-nanoGPT分布式改造.md`：以单设备为基线，依次讲 DDP、FSDP2、TP、PP 与验证。
- `config_smoke.py`：原版 train.py 的 CPU 起步配置。
- `verify_model.py`：CPU 因果性、绑权、MLP 两分片和逻辑流水线输出/梯度对照。
- `train_fsdp2.py`：独立 FSDP2 教学入口，目标 PyTorch 2.9.x、CUDA/NCCL。
- `diagrams/`：三张图的 SVG、PNG、原生画板 JSON。
- `验证记录.json`：已完成验证与硬件限制。

## CPU 跑通流程

安装与设备匹配的 PyTorch 2.9.x，并安装 numpy、requests、tiktoken。将本包三个 `.py` 文件复制到固定版 nanoGPT 根目录，然后在该目录运行：

```bash
python data/shakespeare_char/prepare.py
python train.py config_smoke.py
python sample.py --out_dir=out-guide --device=cpu --dtype=float32 --num_samples=1 --max_new_tokens=40 --start=ROMEO:
python train.py config_smoke.py --init_from=resume --max_iters=30
python verify_model.py --repo .
```

起步训练约 0.1M 参数，几十步仅验证运行流程，生成结果仍会是杂乱字符。词表 meta.pkl 必须与模型一起保留。

原版 max_iters=20 会执行编号 0—20 的更新；检查点在更新前按间隔保存。本例最终保存的 step 20 比退出前内存模型少一次更新。原版恢复不包含完整 RNG、采样进度和 FP16 scaler 状态，因此不能承诺与连续训练逐步一致。

## CUDA 多卡扩展

原版 DDP 示例：

```bash
torchrun --standalone --nproc_per_node=2 train.py config_smoke.py --device=cuda --dtype=float32 --out_dir=out-guide-ddp --gradient_accumulation_steps=2
```

原版会把命令行梯度累加值除以 world size，要求整除。G=2、W=2 时，每卡只累加一次；全局每次更新 4×32×2=256 个 token。

FSDP2 教学入口：

```bash
torchrun --standalone --nproc_per_node=2 train_fsdp2.py --steps 20 --out-dir out-fsdp2 --export
torchrun --standalone --nproc_per_node=2 train_fsdp2.py --steps 30 --out-dir out-fsdp2 --resume out-fsdp2/step-20 --export
python sample.py --out_dir=out-fsdp2/step-30/sample --device=cpu --dtype=float32 --num_samples=1 --max_new_tokens=40 --start=ROMEO:
```

该入口使用 FP32、dropout=0、每卡每次更新一个 batch，无 AMP、梯度累加、裁剪或编译；所有 rank 参与验证、DCP 与导出。steps 代表完成的更新次数。每个 step-N 保存目录不能已存在；恢复要求同一模型、数据内容、world size 和关键运行设置。多机输出目录必须由所有 rank 访问。

每卡先创建完整小模型，再分片，因此它用于验证改造流程。真正大到无法在单卡初始化的模型还需要 meta 初始化和分布式加载。完整导出需要足够的 rank 0 CPU 内存；不导出时，DCP 目录不能直接交给原版 sample.py。

## 验证范围

CPU：Python 3.12.14、PyTorch 2.9.1、numpy 2.3.5；实际数据准备、短训练、保存、恢复、生成及数学对照已通过。运行使用隔离依赖，未替换用户环境。

FSDP2 文件完成语法、导入和 2.9 API 核对。没有 CUDA 多卡硬件实测，因此 FSDP2 训练、DCP 恢复、完整导出以及真实 DDP/TP/PP 的通信与性能均待验证。CPU 的两分片/两逻辑 stage 检查只检验张量代数与梯度，不代表分布式运行通过。

到目标机器后先验证：小模型前向与 loss、一次更新、保存/恢复、导出后采样；再控制有效 batch、精度与计时范围比较显存和吞吐。随机数据窗口与 dropout 会影响精确对照。
