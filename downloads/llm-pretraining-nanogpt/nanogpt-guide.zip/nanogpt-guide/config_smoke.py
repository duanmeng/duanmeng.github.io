# Run from the pinned nanoGPT repository root:
# python train.py /path/to/config_smoke.py
out_dir = 'out-guide'
dataset = 'shakespeare_char'
device = 'cpu'
dtype = 'float32'
compile = False
wandb_log = False
n_layer = 2
n_head = 2
n_embd = 64
block_size = 32
batch_size = 4
gradient_accumulation_steps = 2
dropout = 0.0
learning_rate = 1e-3
decay_lr = False
max_iters = 20
eval_interval = 10
eval_iters = 2
log_interval = 5
always_save_checkpoint = True
