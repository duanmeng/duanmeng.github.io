# 7. 从 nanoGPT 到分布式训练：沿单卡流程逐步改造

配套阅读稿：章节顺序与线上文章一致，代码片段保留较完整的固定版本实现；正文与图表采用适合离线阅读的排版。

第 6 章回答了单设备如何完成训练；本章逐项改变它的分工。先阅读第 3 章的进程、通信和并行机制，再回到 nanoGPT 找实际接入点。顺序是原生 DDP → FSDP2 教学扩展 → MLP 张量并行 → 按 Block 做流水线，最后统一验证。DDP 是仓库现有功能；FSDP2 是本文新增入口；TP/PP 是局部改造示例与数学对照，尚不是完整分布式训练器。

## 7.1 先固定基线：哪一段流程需要改变

保留第 6 章的数据、模型与训练目标，先关闭 dropout、编译与混合精度。比较时固定初始权重、输入/目标、有效 token 数和 loss 归一化。每次只引入一种并行方式；“启动了多个进程”与“保持训练语义且获得收益”需要分别验证。

| 从第 6 章的哪个位置出发 | 第 7 章怎样改变它 |
| --- | --- |
| get_batch 与 backward | DDP：各 rank 取不同数据，复制完整模型，归约梯度。 |
| 模型初始化、optimizer、验证与 checkpoint | FSDP2：分片训练状态，按模块收集参数；所有 rank 参与所需的集体操作。 |
| Block 内的 MLP / Attention | TP：切分一层的矩阵计算，明确输入、局部结果与通信布局。 |
| GPT.forward 的 Block 循环 | PP：将层分配到不同 stage，传递 hidden 及梯度，并调度 micro-batch。 |

## 7.2 读懂原生 DDP：进程、取数与有效 batch

这一节使用仓库已有 train.py。torchrun 给每个进程设置 RANK、LOCAL_RANK 和 WORLD_SIZE；代码据此初始化通信组、绑定本地 GPU，再把模型放进 DDP。每卡持有完整参数、梯度和优化器状态，各自完成前向/反向，通过梯度同步保持更新一致。原版 DDP 路径会强制选择 CUDA 设备，不能仅把 backend 改为 gloo 就视为 CPU 多进程示例。

```bash
# 在有两张可用 CUDA GPU 的机器运行；本章未做硬件实测。
torchrun --standalone --nproc_per_node=2 train.py config_smoke.py --device=cuda --dtype=float32 --out_dir=out-guide-ddp --gradient_accumulation_steps=2
```

设 world_size=W，命令行中的梯度累加值为 G。原版要求 G 能被 W 整除，并把每卡累加次数改为 A=G/W。全局每次更新的窗口数是 B×A×W=B×G，token 数再乘 T。这里 B=4、T=32、G=2：单卡 A=2，两卡各 A=1，两者每次更新都是 256 个 token。保持 G 不变增加卡数时，累加次数会减小；若想保持每卡 A 不变，则要随 W 一起调大 G。

原配置 train_shakespeare_char.py 的 G=1，直接 torchrun 两卡会触发整除断言，这就是示例显式覆盖 G 的原因。数据方面，各 rank 用 1337+rank 的随机种子，从同一 token 流独立采窗口；它不是 DistributedSampler，也不保证不同卡的窗口互不重叠。固定有效 batch 只说明梯度平均的规模可比较，不保证两种运行抽到了同样数据。

原版只在最后一个 micro-step 开启 require_backward_grad_sync，前面的反向先在本卡累积。自行改写时优先使用公开的 DDP.no_sync()，并把对应前向和反向都放在上下文中。rank 0 负责日志、验证和保存；原版验证结果是 rank 0 抽样批次的估计。迁移到分片模型后，必须重新设计这些职责，不能照搬“验证只让 rank 0 前向”。

回到源码核对三个接入点：[进程初始化及累加次数换算](https://github.com/karpathy/nanoGPT/blob/3adf61e154c3fe3fca428ad6bc3818b27a3b8291/train.py#L82)、[DDP 包装](https://github.com/karpathy/nanoGPT/blob/3adf61e154c3fe3fca428ad6bc3818b27a3b8291/train.py#L210)、[最后一个 micro-step 同步梯度](https://github.com/karpathy/nanoGPT/blob/3adf61e154c3fe3fca428ad6bc3818b27a3b8291/train.py#L292)。GPT.forward 和 loss 定义保持一致；新增的是多进程的数据分工与梯度归约。

## 7.3 动手扩展 FSDP2：分片边界、训练与 checkpoint

FSDP2 适合完整训练状态放不下单卡的情形。先把 nanoGPT 中哪些参数由哪个分片组管理讲清楚：对 transformer.h 的每个 Block 调用 fully_shard，再对整个 GPT 调用 fully_shard。前者提供逐 Block 的聚合/重分片边界，后者管理尚未分组的 Embedding、末尾归一化和输出层。wte 与 lm_head 共用参数，应留在同一个根组里。

```python
from torch.distributed.device_mesh import init_device_mesh
from torch.distributed.fsdp import fully_shard

# 所有 rank 已初始化 NCCL，绑定自己的 CUDA 设备。
# 使用相同模型初始化种子；另设按 rank 区分的数据采样 Generator。
model = GPT(gpt_config).to(device)
mesh = init_device_mesh("cuda", (world_size,))
for block in model.transformer.h:
    fully_shard(block, mesh=mesh, reshard_after_forward=True)
fully_shard(model, mesh=mesh, reshard_after_forward=True)
# 优化器必须在 fully_shard 之后创建；此路径不再套 DDP。
optimizer = torch.optim.AdamW(model.parameters(), lr=1e-3)
```

附带的 train_fsdp2.py 是独立教学入口，继续导入固定版 model.py。它提供 FP32、dropout=0、每卡每次更新一个 batch、全 rank 验证、DCP 保存/恢复以及可选的采样格式导出。为便于先验证分片正确性，它未加入编译、混合精度、梯度裁剪和梯度累加，因此不能直接用吞吐与开启这些功能的原版配置比较。初始化时每卡先持有完整小模型，这份入口适合小规模验证；真正超出单卡的模型还需设计 meta device 初始化与分布式加载。

| 改造点 | 在 nanoGPT 中如何落实 |
| --- | --- |
| 模型初始化与优化器 | 先绑定设备，以相同种子构建相同参数；逐 Block 分片再分片 root，最后创建 AdamW。FSDP2 不能靠 DDP 的初始广播替它同步随机初始化。 |
| 训练与数据 | 各 rank 各自采 batch，所有 rank 执行前向/反向；区分模型初始化随机数与数据采样随机数。新增累加时要用 FSDP2 的同步控制，不复用 DDP 标志。 |
| 验证 | 所有 rank 都进入模型前向，以相同调用次数参与参数通信；汇总 loss 后只让 rank 0 打印。变长或带 ignore 标签的数据按有效 token 数加权。 |
| 恢复训练 | 全部 rank 参与 DCP 保存/加载模型和优化器；额外保留完成更新数、配置以及各 rank 的 RNG/采样器状态。 |
| 生成导出 | DCP 分片目录不能直接交给原版 sample.py；全 rank 参与聚合，rank 0 导出普通 ckpt.pt，保留 model_args、dataset 和对应 meta.pkl。 |

```bash
# 将附件 train_fsdp2.py 放到 nanoGPT 根目录；需要 CUDA/NCCL。
torchrun --standalone --nproc_per_node=2 train_fsdp2.py --steps 20 --out-dir out-fsdp2 --export
torchrun --standalone --nproc_per_node=2 train_fsdp2.py --steps 30 --out-dir out-fsdp2 --resume out-fsdp2/step-20 --export
python sample.py --out_dir=out-fsdp2/step-30/sample --device=cpu --dtype=float32 --num_samples=1 --max_new_tokens=40 --start=ROMEO:
```

这个入口使用 argparse，参数写法为 --steps 20；原版 configurator.py 使用 --max_iters=20，两者不要混淆。steps 在新增入口里表示已完成的参数更新次数，和原版 max_iters 的边界语义不同。每次保存在新的 step-N 目录，completed.json 标识该次保存已完成。恢复示例要求相同 world size、模型和关键运行配置；虽然 DCP 可以支持更广的重分片加载，本例没有把弹性恢复与可复现性混在一起。多机时这些路径应在所有 rank 可访问的共享存储上。

导出完整模型仍需要足够的 rank 0 CPU 内存。此教学入口在 FSDP2 上尚未做多卡运行，交付前仅完成语法、导入及 PyTorch 2.9 API 核对；先按 7.6 验证前向、一次更新、恢复和导出，再扩大模型。官方接口参考：[fully_shard](https://docs.pytorch.org/docs/2.9/distributed.fsdp.fully_shard.html) 与 [Distributed Checkpoint](https://docs.pytorch.org/docs/2.9/distributed.checkpoint.html)。

## 7.4 扩展 TP：先切 MLP，再处理 Attention 布局

下图把四种方式对应到 nanoGPT 的模块名。先明确要解决的是数据吞吐、训练状态容量，还是层内与跨层的计算分工，再选择改造路径；DDP/FSDP2 的基本机制可与 3.1、3.3、3.4 对照。

并行改造落点图：模型副本、Block 分片、MLP 张量切分与跨层流水线。

![可编辑配图：nanogpt-parallel](diagrams/nanogpt-parallel/diagram.svg)

[SVG](diagrams/nanogpt-parallel/diagram.svg) · [PNG](diagrams/nanogpt-parallel/diagram.png) · [原生画板 JSON](diagrams/nanogpt-parallel/diagram.json)

**先切 MLP。** nanoGPT 的 MLP 是 C→4C→C：c_fc 后接 GELU，再接 c_proj。两卡可以把 c_fc 的输出特征各取一半，各自计算 GELU，再用 c_proj 对应的输入列得到一份部分输出，最后求和。PyTorch Linear.weight 的布局为 (out_features,in_features)，所以 c_fc.weight 沿第 0 维切，c_proj.weight 沿第 1 维切。若有 c_proj.bias，只能在合并后加一次。

```python
from torch.distributed.tensor.parallel import (
    ColwiseParallel, RowwiseParallel, parallelize_module,
)

# tp_mesh 是一维 TP 子网格；各 rank 持有一致的模型和输入。
# 先用 dropout=0 验证下列 MLP 模式；这不是完整训练入口。
for block in model.transformer.h:
    parallelize_module(block.mlp, tp_mesh, {
        "c_fc": ColwiseParallel(),
        "c_proj": RowwiseParallel(),
    })
# 布局改造完成后再创建优化器，并验证输出与梯度。
```

注意原版 Attention 的 c_attn 一次输出 [Q 全部通道, K 全部通道, V 全部通道]。直接把这个 3C 维连续对半切，可能得到不完整的 Q/K/V 配对；同时 forward 中 split(self.n_embd) 和 view(...,self.n_head,...) 仍假设全局维度。扩展 Attention TP 时，应显式重排或拆开 Q/K/V 投影，让每卡拿到对应局部头，调整 local n_head 和局部 reshape，再设计输出投影归约。必须让 n_head 能按 TP 度数合理分配。

TP 组内的各卡共同处理同一个 batch；从 DDP 路径迁移时，数据随机种子应按数据并行组区分，并在 TP 组内保持输入一致。LayerNorm 等算子所见的布局、dropout 随机性、共享 Embedding/lm_head 的分片和 checkpoint 布局也要一起考虑。官方接口参考：[Tensor Parallelism](https://docs.pytorch.org/docs/2.9/distributed.tensor.parallel.html)。

## 7.5 扩展 PP：把 Block 链路拆成多个阶段

**再按 Block 拆 PP。** 第一阶段接收 token，执行 wte+wpe、dropout 和前半段 Blocks，输出 hidden states (B,T,C)；第二阶段执行后半段 Blocks、ln_f、lm_head，并用目标计算 loss。前向传 hidden，反向传对应梯度；最后阶段还需要拿到同一 micro-batch 的 Y。完整训练循环交给 PipelineStage 与 schedule 组织，不能仅把两段模块 .to 到不同设备就认为完成了流水线。

先在单进程中按边界顺序执行两段，验证与整模型输出及梯度一致，再换成两进程通信，并从简单的填充—排空调度进入 1F1B。明确 micro-batch 数、每段输入输出 shape、loss 的 sum/mean 与缩放规则，避免 schedule 与外层循环重复除以 micro-batch 数。负载也不能只按层数平均：首尾的 Embedding、词表投影和 loss 可能造成额外开销。

nanoGPT 的 wte 与 lm_head 若位于不同 stage，跨进程不会自动保持 Parameter 别名。保持绑权时，需要一致初始化，并把两处梯度贡献正确合并，协调更新，使两份权重继续一致；使用支持共享权重的框架可以减少手写同步。若为了学习先解绑，必须明确这是修改模型结构，再建立对应的 untied 基线。官方接口参考：[Pipeline Parallelism](https://docs.pytorch.org/docs/2.9/distributed.pipelining.html)。

附件 verify_model.py 在 CPU 上验证 MLP 两分片求和的输出/梯度，以及保留共享参数时按两个逻辑 stage 执行的输出/梯度。这能检验切分的数学关系；真实 TP/PP 的通信、调度、随机数和性能还要在多卡上单独验证。

## 7.6 验证改造：先对结果，再比较显存与吞吐

建立一份固定的测试输入、目标和初始权重，先关闭 dropout、编译和混合精度。在相同全局 token 数与 loss 归一化下，比较单卡和改造后的前向、loss、梯度及一次 optimizer 更新。跨设备归约顺序可能导致浮点差异，应使用与 dtype 相符的容差，并记录最大误差；检查恢复时还要核对迭代数、优化器状态和随机数状态。

```bash
python verify_model.py --repo .
```

| 检查项 | 本次结果 / 下一步要求 |
| --- | --- |
| 原版数据准备 | 实际 tiny Shakespeare：65 字符，训练 1,003,854 token，验证 111,540 token。 |
| CPU 短训练与生成 | PyTorch 2.9.1、Python 3.12.14；验证 loss 约 4.1699→3.2548；完成 checkpoint 读取及字符采样。 |
| 原版恢复训练 | 从保存的 step 20 继续到 step 30 并再次保存；未宣称与连续训练逐步一致。 |
| 模型语义 | 因果性、绑权、最后位置 logits 与生成形状检查通过。 |
| TP / PP 数学边界 | CPU 上 MLP 两分片输出/梯度对照通过；两逻辑 stage 输出/梯度对照通过。 |
| FSDP2 扩展代码 | 完成语法、导入与 2.9 API 核对；CUDA/NCCL 训练、DCP 恢复和导出需目标机器验证。 |
| 真实 DDP / TP / PP 与性能 | 本次未做多 GPU / 多机实测，不填写加速比和显存节省结论。 |

测吞吐前先预热，排除编译和验证/保存耗时，在明确的计时范围前后同步设备；用全局有效 token 数除以各 rank 中最大的耗时。记录每卡 max_memory_allocated 的峰值并取最大值，同时注明是否包含验证、checkpoint 和导出。只改一个因素，保持模型、序列长度、有效 batch、数据与精度一致；参数存储减少不等于训练峰值按卡数等比例下降。

建议保存实验记录：提交版本、PyTorch/CUDA/驱动、GPU 数与互联、B/T/G 或每卡累加次数、精度、编译开关、loss/梯度误差、恢复结果、峰值显存和 tokens/s。学到这里，应能从模块与张量布局解释一次改造的结果，并知道何时继续用 nanoGPT 做实验、何时转向 torchtitan 等更完整的训练工程。

第 6—7 章附件：端到端训练与源码解读、分布式改造说明、起步配置、CPU 验证脚本、FSDP2 教学入口，以及三张可编辑 SVG、PNG 预览和原生画板 JSON。运行步骤与已验证范围同时保留在包内 README 中。
