# 6. nanoGPT 端到端实战：从训练过程深入源码

配套阅读稿：章节顺序与线上文章一致，代码片段保留较完整的固定版本实现；正文与图表采用适合离线阅读的排版。

第 6 章沿着一次完整训练展开：文本如何变成样本，样本怎样经过模型得到 loss，梯度如何形成参数更新，训练产物又怎样用于验证、恢复和生成。先串起流程，再跑通实验，并沿同一条路径下钻源码。进入条件是能理解第 2 章的 GPT 前向和训练循环；分布式所需的进程、通信与切分留到第 7 章。

第 6—7 章固定阅读 Karpathy nanoGPT 的提交 `3adf61e154c3fe3fca428ad6bc3818b27a3b8291`（2025-11-12），源码于 2026-09-13 核对。上游 README 已将 nanoGPT 标为历史项目并推荐 nanochat；这里选择它，是因为模型和训练入口紧凑，适合学习 GPT-2 风格实现。nanoGPT、build-nanogpt 和 nanochat 是不同项目，代码与启动命令不能混用。

第 6—7 章共用附件 `nanogpt-guide.zip`，放在第 7 章末尾。第 6 章使用起步配置 `config_smoke.py` 和验证脚本 `verify_model.py`；第 7 章再使用 `train_fsdp2.py`。包内还包含两章正文及三张可编辑配图。先将需要的脚本放到固定版本的 nanoGPT 仓库根目录。

## 6.1 先走完整条链路：训练结束后，我们得到了什么

以 tiny Shakespeare 字符级模型为例：输入是一份剧本文本，训练目标是在每个位置预测下一个字符，最终产物是模型 checkpoint。训练不是把答案存进文件；它反复取样、预测、计算误差，再用误差的梯度调整参数。生成阶段加载这些参数，从提示词开始逐个采样新字符。

| 阶段 | 沿着同一个实验看输入、动作与产物 |
| --- | --- |
| 准备数据 | input.txt → 字符编号 → train.bin / val.bin；meta.pkl 保存编号与字符的映射。 |
| 建立训练状态 | 读取配置 → 构造 GPT → 创建 AdamW；恢复训练时从 checkpoint 载入模型和优化器。 |
| 完成一次更新 | 取 X/Y → 前向得到 logits 和 loss → backward 累积梯度 → 裁剪 → optimizer.step → 清空梯度；重复这一循环。 |
| 验证与保存 | 用验证段估计模型对未训练文本的预测误差，按条件保存 ckpt.pt。原版在下一次更新之前触发这条支路。 |
| 生成与恢复 | sample.py：checkpoint + 词表 + 提示词 → 新文本；train.py resume：checkpoint → 继续更新参数。 |

先记住三个时间尺度：一个 token 是一个字符编号；一个 micro-batch 是 B 段长度为 T 的窗口；一次参数更新由 A 个 micro-batch 累积而成。下面的小配置 B=4、T=32、A=2，因此一次更新使用 8 段窗口、256 个 token 预测目标。验证和生成只做前向，不更新参数。

## 6.2 从运行过程定位源码：三条入口与共享模型

把 nanoGPT 看成三条入口：prepare.py 把文本变成训练数据，train.py 更新参数，sample.py 用已有参数生成文本。model.py 提供共同使用的模型定义；配置决定模型大小、数据位置和训练方式。阅读时先走完这三条路径，再深入 Attention 内部。

| 文件 / 对象 | 职责与阅读重点 |
| --- | --- |
| data/shakespeare_char/prepare.py | 下载或读取 input.txt，建立字符词表；按前 90% / 后 10% 切成训练与验证段，输出 train.bin、val.bin、meta.pkl。 |
| config/train_shakespeare_char.py + configurator.py | 配置文件是 Python 代码；默认值先定义在入口脚本中，然后按命令行顺序覆盖。把配置文件放前面，--key=value 放后面。 |
| train.py | 初始化进程和模型；get_batch 取数据；训练、验证、记录指标和保存。它是理解工程组织的主线。 |
| model.py | GPTConfig、GPT、Block、CausalSelfAttention、MLP；还包括 optimizer 配置、GPT-2 权重导入与 generate。 |
| sample.py | 从 checkpoint 重建 GPT，按 dataset 找到 meta.pkl，编码提示词、循环采样并解码。 |
| out_dir/ckpt.pt | 原版保存模型、优化器、模型配置、迭代号、验证记录和运行配置；词表映射仍在数据目录。 |

项目关系图：配置、数据文件、训练入口与生成入口各自承担什么职责。

![可编辑配图：nanogpt-project](diagrams/nanogpt-project/diagram.svg)

[SVG](diagrams/nanogpt-project/diagram.svg) · [PNG](diagrams/nanogpt-project/diagram.png) · [原生画板 JSON](diagrams/nanogpt-project/diagram.json)

建议按“配置 → prepare.py → train.py 的 get_batch → GPT.forward → 训练循环 → sample.py”阅读。先回答数据从哪里来、shape 是什么、参数什么时候变化，再读融合 QKV、权重共享和性能优化。源码入口：[train.py](https://github.com/karpathy/nanoGPT/blob/3adf61e154c3fe3fca428ad6bc3818b27a3b8291/train.py)、[model.py](https://github.com/karpathy/nanoGPT/blob/3adf61e154c3fe3fca428ad6bc3818b27a3b8291/model.py)、[sample.py](https://github.com/karpathy/nanoGPT/blob/3adf61e154c3fe3fca428ad6bc3818b27a3b8291/sample.py)、[data/shakespeare_char/prepare.py](https://github.com/karpathy/nanoGPT/blob/3adf61e154c3fe3fca428ad6bc3818b27a3b8291/data/shakespeare_char/prepare.py)。

第一次下钻按运行顺序走：`configurator.py → get_batch → GPT.forward → backward / step → estimate_loss / checkpoint → generate`。第二次再从 `GPT.forward` 进入 Block、Attention 和 MLP。这样每段代码都有一个已见过的输入和输出，而不是脱离训练过程逐文件浏览。

这里的模型采用可学习绝对位置 Embedding、LayerNorm、GELU MLP 和多头因果自注意力。它没有直接采用 LLaMA 的 RoPE、RMSNorm、SwiGLU/GQA。transformer.wte.weight 与 lm_head.weight 是同一个参数，这个共享关系在保存、FSDP 分组和 PP 拆阶段时都需要保留或明确处理。

## 6.3 跑通一次：数据准备、短训练、恢复与生成

先使用独立目录和与本机匹配的 PyTorch 2.9.x 环境。CUDA 机器应按 PyTorch 官方安装说明选择构建；本节 CPU 小配置不依赖 CUDA。除 PyTorch 外，字符级路径使用 numpy、requests；sample.py 在文件开头导入 tiktoken，因此即使使用字符词表也要安装它。加载 GPT-2 预训练权重才进一步需要 transformers，本次起步实验不下载预训练模型。

```bash
git clone https://github.com/karpathy/nanoGPT.git
cd nanoGPT
git checkout 3adf61e154c3fe3fca428ad6bc3818b27a3b8291
# 已安装与设备匹配的 PyTorch 2.9.x 后：
python -m pip install numpy requests tiktoken
python data/shakespeare_char/prepare.py
```

官方 tiny Shakespeare 数据准备后，词表有 65 个字符，训练段 1,003,854 个 token，验证段 111,540 个 token。train.bin/val.bin 中保存 uint16 编号，meta.pkl 保存 vocab_size、stoi 和 itos。分割是文本的连续前后段，随机训练窗口不会跨越这条分界；窗口之间可能重叠。若替换成自己的文本，重新建立词表并重新准备数据；词表超过 uint16 容量时要同时修改写入和读取的数据类型。

将下列内容保存为仓库根目录的 config_smoke.py。它把实验缩到 2 层、2 头、64 维、32 个字符上下文，关闭编译与混合精度，方便先检查流程。梯度累加次数设为 2，后面可以直接用于 2 卡 DDP。

```python
# Run from the pinned nanoGPT repository root:
# python train.py /path/to/config_smoke.py
out_dir = 'out-guide'
dataset = 'shakespeare_char'
device = 'cpu'
dtype = 'float32'
compile = False
wandb_log = False
n_layer = 2
n_head = 2
n_embd = 64
block_size = 32
batch_size = 4
gradient_accumulation_steps = 2
dropout = 0.0
learning_rate = 1e-3
decay_lr = False
max_iters = 20
eval_interval = 10
eval_iters = 2
log_interval = 5
always_save_checkpoint = True
```

```bash
python train.py config_smoke.py
python sample.py --out_dir=out-guide --device=cpu --dtype=float32 --num_samples=1 --max_new_tokens=40 --start=ROMEO:
python train.py config_smoke.py --init_from=resume --max_iters=30
```

先观察日志是否识别 vocab_size=65、是否打印 train/val loss，以及 out-guide/ckpt.pt 是否生成。几十步训练通常只会生成杂乱字符；本节用它验证完整流程，语言质量需要更充分的训练。提示词字符必须存在于 stoi 中，空提示词也不适合直接喂给原版 generate。生成时保留原来的 data/shakespeare_char/meta.pkl；若丢失，sample.py 会尝试回退到 GPT-2 编码，不能用这个回退解释字符级模型的输出。

理解两个时间点：原版在循环开头做验证与条件保存，且 iter_num>0 才真正落盘；停止条件在更新后检查 iter_num>max_iters。因此 max_iters=20 会执行编号 0—20 的 21 次更新，最后保存的 step 20 文件对应第 20 次已完成更新，内存随后还会再更新一次。恢复训练从保存的 iter_num 继续，不代表从退出前最后一次更新继续。要做严格实验，可以改成 while completed_updates<target，并在完成更新后递增计数和保存。

原版 resume 恢复模型和优化器，但没有保存 CPU/CUDA RNG、数据采样进度和 FP16 GradScaler 状态；所以“能继续训练”不等于“与不中断训练逐步一致”。配置文件仍会重新执行，未强制恢复的配置可能改变运行行为。保留同一数据和词表，确认学习率、batch、精度、dropout 等设置，再解释恢复后的曲线。

| 现象 | 对应检查 |
| --- | --- |
| 没有 ckpt.pt | 检查是否走到非零 eval_interval、保存条件是否满足；短跑使用本章 always_save_checkpoint=True。 |
| 配置覆盖失败 | 原版采用 --key=value；bool 写 True/False；数值类型要匹配默认值，例如浮点参数写 0.0。 |
| 采样 KeyError 或文本异常 | 核对提示词字符、meta.pkl、模型 vocab_size 和 checkpoint.config.dataset；不要混用字符级与 BPE 数据。 |
| 显存不足 / CPU 太慢 | 先减小 batch_size、block_size、n_layer、n_embd；保证 n_embd 能整除 n_head。 |
| 旧 AMP 接口出现 FutureWarning | 固定版本仍使用 torch.cuda.amp.GradScaler；本章 CPU FP32 路径已运行通过，扩展代码采用独立入口。 |

## 6.4 沿一批数据：串起输入、前向与参数更新

源码入口：[prepare.py：字符词表与数据切分](https://github.com/karpathy/nanoGPT/blob/3adf61e154c3fe3fca428ad6bc3818b27a3b8291/data/shakespeare_char/prepare.py#L21)，以及 [train.py：get_batch](https://github.com/karpathy/nanoGPT/blob/3adf61e154c3fe3fca428ad6bc3818b27a3b8291/train.py#L116)。prepare 先用排序后的字符集合建立 stoi / itos，再编码文本；get_batch 每次随机取窗口，不是按 epoch 顺序遍历整个训练集。X 和 Y 共用同一段文本，只错开一个位置，因此不需要人工标注答案。

```python
ix = torch.randint(len(data) - block_size, (batch_size,))
x = torch.stack([torch.from_numpy((data[i:i+block_size]).astype(np.int64)) for i in ix])
y = torch.stack([torch.from_numpy((data[i+1:i+1+block_size]).astype(np.int64)) for i in ix])
```

磁盘上使用 uint16 节省空间，取样时转成 int64，对应 PyTorch 的 torch.long。起步配置得到 X.shape=Y.shape=(4,32)。训练、验证使用各自的 bin 文件；验证也随机抽窗口。代码没有 DataLoader / DistributedSampler，也没有保证窗口互不重叠——这些行为将在第 7 章决定如何分配多卡数据。

train.py 的 get_batch 不使用第 2 章示例中的 DataLoader。它读取 memmap，在 token 流上随机选 B 个起点，每个位置取长度 T 的输入及向后错一位的目标。若 token 为 [10,11,12,13,14]、T=4，则 X=[10,11,12,13]，Y=[11,12,13,14]。这是同一前向同时学习多个“下一个 token”预测的原因。

| 阶段 | 形状与含义 |
| --- | --- |
| X / Y | (B,T)，torch.long；每个位置是词表中的整数编号。 |
| wte(X) + wpe(position) | (B,T,C)；词向量与位置向量相加。 |
| c_attn → split → reshape | 先得到 (B,T,3C)，按 Q/K/V 各 C 分开，再变为 (B,H,T,C/H)。 |
| 因果 Attention → c_proj | 每个位置只使用允许访问的上下文；多头合回 (B,T,C)，再做输出投影。 |
| Block 与 ln_f | 每个 Block 两条 Pre-Norm 残差，维持 (B,T,C)；最后再做 LayerNorm。 |
| lm_head 与 loss | 训练输出 (B,T,V)，展平成 (B×T,V) 与目标 (B×T) 计算交叉熵。未传 targets 时原版只计算最后位置的 logits。 |

训练流程图：梯度累加形成一次更新；验证、保存与生成具有各自的入口和时机。

![可编辑配图：nanogpt-training](diagrams/nanogpt-training/diagram.svg)

[SVG](diagrams/nanogpt-training/diagram.svg) · [PNG](diagrams/nanogpt-training/diagram.png) · [原生画板 JSON](diagrams/nanogpt-training/diagram.json)

一次 optimizer 更新包含 A 个 micro-step：各次前向的 loss 除以 A 后 backward，梯度累积到参数上；最后才做 unscale、梯度裁剪、optimizer 更新和清零。原版通过 scaler.step/update 兼容 FP16；FP32/BF16 时 scaler 不启用。前向之后立即取下一批，再对当前 loss 反向，这是一种预取安排，并不会让当前 loss 改用下一批标签。

有两个指标容易读错。训练日志里的 loss 是最后一个 micro-step 的 loss 乘回 A，并非所有 micro-step 的精确平均；estimate_loss 则在 eval 模式和 no_grad 下对若干随机批次求平均。另一个是 MFU：estimate_mfu 硬编码 A100 BF16 峰值 312 TFLOPS，不能把 CPU、H800 或其他设备打印的百分比直接当作硬件利用率。

model.py 中名为 flash 的开关只检查 `scaled_dot_product_attention` 这个 API 是否存在；实际采用哪种 SDPA 后端由设备、dtype、shape 等决定，不能仅凭这个变量断言启用了 FlashAttention。没有该 API 时，源码使用显式 QKᵀ、因果 mask、softmax 和与 V 相乘的路径。

## 6.5 前向下钻：GPT → Block → Attention / MLP → loss

先看外层 [GPT.forward](https://github.com/karpathy/nanoGPT/blob/3adf61e154c3fe3fca428ad6bc3818b27a3b8291/model.py#L170)。以 B=4、T=32、C=64、H=2、V=65 为例，wte 把编号变成 (4,32,64)，wpe 生成 (32,64) 并沿 batch 广播相加。两个 Block 和末尾 LayerNorm 保持 hidden 的形状，lm_head 最终将每个位置投影到 65 个字符的分数。这里的 logits 尚未经过 softmax。

```python
# forward the GPT model itself
tok_emb = self.transformer.wte(idx) # token embeddings of shape (b, t, n_embd)
pos_emb = self.transformer.wpe(pos) # position embeddings of shape (t, n_embd)
x = self.transformer.drop(tok_emb + pos_emb)
for block in self.transformer.h:
    x = block(x)
x = self.transformer.ln_f(x)

if targets is not None:
    # if we are given some desired targets also calculate the loss
    logits = self.lm_head(x)
    loss = F.cross_entropy(logits.view(-1, logits.size(-1)), targets.view(-1), ignore_index=-1)
```

loss 将 (4,32,65) 展平成 (128,65)，与 128 个目标编号计算交叉熵，默认对有效目标求平均。F.cross_entropy 内部处理 log-softmax，不要先把 logits 做 softmax 再传进去。因果 Attention 阻止位置 t 读取未来输入，而 Y[t] 正是下一字符；训练一次并行算出 32 个位置的预测，这与生成时逐个追加 token 是两个阶段。

继续进入 [Block.forward](https://github.com/karpathy/nanoGPT/blob/3adf61e154c3fe3fca428ad6bc3818b27a3b8291/model.py#L103)：先对 x 做 LayerNorm，再做 Attention，与原来的 x 相加；随后对新的 x 做 LayerNorm、MLP，再残差相加。归一化放在子层之前，所以称 Pre-Norm。残差要求两个子层都输出相同的 C 维。

```python
def forward(self, x):
    x = x + self.attn(self.ln_1(x))
    x = x + self.mlp(self.ln_2(x))
    return x
```

再进入 [CausalSelfAttention.forward](https://github.com/karpathy/nanoGPT/blob/3adf61e154c3fe3fca428ad6bc3818b27a3b8291/model.py#L52)。c_attn 是一次 C→3C 的融合线性变换；它输出的排列是完整 Q、完整 K、完整 V。split 之后各自变成 (B,H,T,C/H)，小配置中就是 (4,2,32,32)。每个头计算带因果限制的注意力，多头再合并成 (4,32,64)，经过 c_proj 回到残差路径。

```python
# calculate query, key, values for all heads in batch and move head forward to be the batch dim
q, k, v  = self.c_attn(x).split(self.n_embd, dim=2)
k = k.view(B, T, self.n_head, C // self.n_head).transpose(1, 2) # (B, nh, T, hs)
q = q.view(B, T, self.n_head, C // self.n_head).transpose(1, 2) # (B, nh, T, hs)
v = v.view(B, T, self.n_head, C // self.n_head).transpose(1, 2) # (B, nh, T, hs)

# causal self-attention; Self-attend: (B, nh, T, hs) x (B, nh, hs, T) -> (B, nh, T, T)
if self.flash:
    # efficient attention using Flash Attention CUDA kernels
    y = torch.nn.functional.scaled_dot_product_attention(q, k, v, attn_mask=None, dropout_p=self.dropout if self.training else 0, is_causal=True)
else:
    # manual implementation of attention
    att = (q @ k.transpose(-2, -1)) * (1.0 / math.sqrt(k.size(-1)))
    att = att.masked_fill(self.bias[:,:,:T,:T] == 0, float('-inf'))
    att = F.softmax(att, dim=-1)
    att = self.attn_dropout(att)
    y = att @ v # (B, nh, T, T) x (B, nh, T, hs) -> (B, nh, T, hs)
y = y.transpose(1, 2).contiguous().view(B, T, C) # re-assemble all head outputs side by side

# output projection
y = self.resid_dropout(self.c_proj(y))
return y
```

最后进入 [MLP](https://github.com/karpathy/nanoGPT/blob/3adf61e154c3fe3fca428ad6bc3818b27a3b8291/model.py#L78)：c_fc 将每个 token 的 64 维扩展为 256 维，GELU 提供非线性，再由 c_proj 投回 64 维。MLP 对各位置分别计算；跨位置的信息交流发生在 Attention。这正是第 7 章先从 MLP 做张量并行练习的原因。

```python
def forward(self, x):
    x = self.c_fc(x)
    x = self.gelu(x)
    x = self.c_proj(x)
    x = self.dropout(x)
    return x
```

## 6.6 训练下钻：梯度如何变成更新，更新如何被记录

回到 [train.py：scaler 与 optimizer 初始化](https://github.com/karpathy/nanoGPT/blob/3adf61e154c3fe3fca428ad6bc3818b27a3b8291/train.py#L195)。模型构造后，[configure_optimizers](https://github.com/karpathy/nanoGPT/blob/3adf61e154c3fe3fca428ad6bc3818b27a3b8291/model.py#L263) 按参数维数分成两组：矩阵和 Embedding 参与 weight decay，bias 与 LayerNorm 参数不衰减，然后创建 AdamW。优化器保存自己的状态；前向计算出 loss 时，参数尚未改变，backward 只向参数的 .grad 累积梯度。

以下是 [原训练循环](https://github.com/karpathy/nanoGPT/blob/3adf61e154c3fe3fca428ad6bc3818b27a3b8291/train.py#L290) 的单设备阅读版，省略 DDP 分支与日志，保留原有操作顺序。FP32 起步配置中 scaler 是空操作；通常在 scaler.step 内部调用 optimizer.step 时参数才改变，FP16 检测到非有限梯度时可能跳过这次更新。

```python
for micro_step in range(gradient_accumulation_steps):
    with ctx:
        logits, loss = model(X, Y)
        loss = loss / gradient_accumulation_steps
    X, Y = get_batch('train')  # 为下一次前向取数
    scaler.scale(loss).backward()
if grad_clip != 0.0:
    scaler.unscale_(optimizer)
    torch.nn.utils.clip_grad_norm_(model.parameters(), grad_clip)
scaler.step(optimizer)
scaler.update()
optimizer.zero_grad(set_to_none=True)
```

固定大小、没有 padding 的 A 个 micro-batch，各自 loss 除以 A 后累加，等价于对这 A 批 token 的平均 loss 求梯度；dropout 与浮点归约顺序会影响逐值对照。zero_grad 不会清空模型参数，它释放或清空梯度，为下一次更新准备。

训练还要管理时间：[get_lr](https://github.com/karpathy/nanoGPT/blob/3adf61e154c3fe3fca428ad6bc3818b27a3b8291/train.py#L231) 实现 warmup、cosine decay 与最小学习率，循环开头将结果写入 optimizer.param_groups；本章 decay_lr=False，始终使用配置的学习率。[estimate_loss](https://github.com/karpathy/nanoGPT/blob/3adf61e154c3fe3fca428ad6bc3818b27a3b8291/train.py#L215) 在 eval 与 no_grad 下抽取 train/val 批次，结束后切回 train。eval 改变 Dropout 等层的行为，no_grad 关闭梯度记录，两者作用不同。

保存发生在 [验证与 checkpoint 分支](https://github.com/karpathy/nanoGPT/blob/3adf61e154c3fe3fca428ad6bc3818b27a3b8291/train.py#L262)；恢复路径见 [模型恢复](https://github.com/karpathy/nanoGPT/blob/3adf61e154c3fe3fca428ad6bc3818b27a3b8291/train.py#L158) 和 [优化器恢复](https://github.com/karpathy/nanoGPT/blob/3adf61e154c3fe3fca428ad6bc3818b27a3b8291/train.py#L198)。ckpt.pt 包含模型权重、AdamW 状态、模型结构参数、迭代号和配置；meta.pkl 仍在数据目录。理解这些字段后，才能判断 checkpoint 是“能生成”“能续训”还是“能精确复现中断前的轨迹”。

## 6.7 生成下钻：checkpoint 怎样续写 ROMEO:

源码从 [sample.py：恢复模型](https://github.com/karpathy/nanoGPT/blob/3adf61e154c3fe3fca428ad6bc3818b27a3b8291/sample.py#L35) 开始：用 checkpoint.model_args 构造相同 GPT，加载权重，切到 eval 并放到指定设备；然后根据 checkpoint.config.dataset 找到 meta.pkl。提示词 ROMEO: 被编码为形状 (1,6) 的 long tensor，再传给 [GPT.generate](https://github.com/karpathy/nanoGPT/blob/3adf61e154c3fe3fca428ad6bc3818b27a3b8291/model.py#L305)。这条路径没有目标 Y，不计算训练 loss，也不调用 backward 或 optimizer。

```python
for _ in range(max_new_tokens):
    # if the sequence context is growing too long we must crop it at block_size
    idx_cond = idx if idx.size(1) <= self.config.block_size else idx[:, -self.config.block_size:]
    # forward the model to get the logits for the index in the sequence
    logits, _ = self(idx_cond)
    # pluck the logits at the final step and scale by desired temperature
    logits = logits[:, -1, :] / temperature
    # optionally crop the logits to only the top k options
    if top_k is not None:
        v, _ = torch.topk(logits, min(top_k, logits.size(-1)))
        logits[logits < v[:, [-1]]] = -float('Inf')
    # apply softmax to convert logits to (normalized) probabilities
    probs = F.softmax(logits, dim=-1)
    # sample from the distribution
    idx_next = torch.multinomial(probs, num_samples=1)
    # append sampled index to the running sequence and continue
    idx = torch.cat((idx, idx_next), dim=1)

return idx
```

每轮只取最后位置的分数，除以正的 temperature；top_k 可将候选限制在高分字符中，然后 softmax 得到概率，multinomial 随机抽一个编号，cat 追加到输入末尾。要求生成 40 个新字符时，最终序列长度为 6+40=46；原版没有自动按结束标记停下的逻辑。相同提示词在不同随机状态下可能生成不同续写。

当输入超过 block_size=32，generate 只保留最近 32 个 token 作为下一次模型输入，返回值仍保留原提示词与完整生成结果。原版每次重新计算整个上下文，没有 KV cache。训练时一次并行预测窗口内所有位置，生成时必须先选出下一 token 才能继续，这解释了两条路径的速度与计算方式为何不同。

## 6.8 本章通关：能运行，也能解释一次训练

用第 6.3 节命令得到 checkpoint、生成文本并恢复训练后，尝试不看文件清单，按顺序解释：X/Y 为什么错开一位；logits 为什么是 (B,T,V)；A 次 backward 为什么只更新一次；验证为什么不改变参数；恢复训练为什么还需要优化器与随机状态；生成为什么只使用最后位置。能把这六个问题定位到源码，就具备了第 7 章改造的单设备基线。

本次 CPU 实跑中，验证 loss 从 step 0 的约 4.1699 降到 step 20 的约 3.2548，保存后能生成 40 个字符，也能恢复训练。这是“链路跑通”的证据；短训练与少量验证批次不能据此评价语言能力。带着日志与产物，下面回到源码解释刚才发生的每一步。

本章 CPU 路径已完成数据准备、短训练、保存、恢复和生成，模型因果性、权重共享及最后位置 logits 检查通过。第 7 章会在相同输入、权重和 loss 口径下，分别改变数据分配、状态存放、层内计算和跨层执行，并验证改造是否保持预期结果。
