# nanoGPT 训练状态观察与测量辅助文件

把 `make_observed_train.py` 和 `training_observer.py` 保持在同一目录，在固定版 nanoGPT 仓库根目录运行：

```bash
python /path/to/make_observed_train.py --repo .
python train_observe.py config_smoke.py --out_dir=out-observe
```

生成器只接受提交 `3adf61e154c3fe3fca428ad6bc3818b27a3b8291` 的 `train.py`，输出 `train_observe.py`、辅助模块和可读的 `train_observe.patch`。原始 `train.py` 不变；生成的文件已有不同内容时拒绝覆盖。再次生成已修改的生成文件前需自行保存，或明确使用 `--force`。

默认 `observe_first_update=True`，要求 FP32、`compile=False` 和正学习率。观察的是首层 MLP 的 `c_fc.weight` 一个指定参数：其形状为 `(4C,C)`，前向/反向保持参数不变，反向产生梯度，step 改参数，clear 令 `.grad` 回到 `None`。这是被观察参数的状态检查，不能据此断言其他所有代码都正确。

`GUIDE after_backward` 的 `global_mean_loss` 汇总了本次更新的全部微批，并在 DDP 下平均所有 rank；适用于本例等大、无 padding 的字符窗口。它不同于原日志只显示最后一个微批的 loss。

## 一次同步改造

生成器把固定版的私有同步开关改为公开 `no_sync` 上下文。阅读 `train_observe.patch` 对照这一段；上下文必须包住前向和反向：

```python
sync_now = ddp_sync_each_micro or micro_step == gradient_accumulation_steps - 1
sync_context = model.no_sync() if ddp and not sync_now else nullcontext()
with sync_context:
    with ctx:
        logits, loss = model(X, Y)
        loss = loss / gradient_accumulation_steps
    X, Y = get_batch('train')
    scaler.scale(loss).backward()
```

用两卡且 `G=4`，使每个 rank 的实际微批数 `A=2`，两个模式才有区别：

```bash
torchrun --standalone --nproc_per_node=2 train_observe.py config_smoke.py --device=cuda --gradient_accumulation_steps=4 --out_dir=out-sync-last --ddp_sync_each_micro=False
torchrun --standalone --nproc_per_node=2 train_observe.py config_smoke.py --device=cuda --gradient_accumulation_steps=4 --out_dir=out-sync-every --ddp_sync_each_micro=True
```

False 在最后一个微批同步梯度，True 每个微批都同步。保持同一输入、初始参数和优化器状态后再做数值对照；这里的随机窗口摘要只能检查各 rank 在取什么数据，不能证明样本不重叠或替代数值对照。

## 独立测量窗口

```bash
CUDA_VISIBLE_DEVICES=0 python train_observe.py config_smoke.py --device=cuda --gradient_accumulation_steps=4 --out_dir=out-bench-1gpu --observe_first_update=False --benchmark=True --benchmark_warmup=5 --benchmark_updates=10 --max_iters=20
torchrun --standalone --nproc_per_node=2 train_observe.py config_smoke.py --device=cuda --gradient_accumulation_steps=4 --out_dir=out-bench-2gpu --observe_first_update=False --benchmark=True --benchmark_warmup=5 --benchmark_updates=10 --max_iters=20
```

示例固定全局批量：单卡 `A=4`，两卡每 rank `A=2`。所有命令都保持 `b=4`、`T=32`，每次更新 512 个目标 token。两卡加速不是必然；小模型可能主要消耗在通信和启动开销上。

测量按本次进程已完成的更新计数：先完成 5 次预热，再测 10 次完整更新。计时前后同步 CUDA；DDP 取各 rank 用时的最大值，全局 tokens/s 的分子只计一次全局 token 总数。每个 rank 分别打印测量期间的绝对峰值 `torch.cuda.max_memory_allocated`，不是增量显存，也不是设备总显存。

窗口内跳过验证、保存和原有逐步 loss 日志，包含取样/预取、前向、反向、优化器更新和清梯度。窗口前后保留原版验证与保存；原 `max_iters` 停止边界不变，更新数不足会报错。关闭验证也会改变后续数据采样的 RNG 轨迹，因此测量运行用于比较吞吐，不能将其 checkpoint 用作普通训练的逐值等价证据。FP16 可能跳过更新，当前测量拒绝 FP16。

CPU 将 `device` 改为 `cpu`、用 `python` 单进程启动即可检查测量功能；CPU 的显存字段是 `null`，CPU 结果不代表 GPU 性能。已有验证只覆盖 CPU：默认模式的模型与 optimizer checkpoint 和原版逐值相同、首更新状态检查通过、计时窗口与错误输入检查通过。CUDA 和 NCCL/DDP 仍需要读者在对应设备上实测。
