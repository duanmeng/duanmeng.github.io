"""One-update check for pinned nanoGPT, PyTorch 2.9.x.

Copy beside nanoGPT/model.py. CPU/Gloo is a logic check; CUDA/NCCL must
still be checked on the target GPUs. This is not a throughput benchmark.
"""
import argparse
import copy
import json
import os
from contextlib import nullcontext

import torch
import torch.distributed as dist
from torch.nn.parallel import DistributedDataParallel as DDP
from model import GPT, GPTConfig


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--device', choices=['cpu', 'cuda'], default='cuda')
    parser.add_argument('--accum', type=int, default=1)
    args = parser.parse_args()
    if args.accum < 1:
        raise ValueError('accum must be positive')
    torch.set_num_threads(1)
    local_rank = int(os.environ['LOCAL_RANK'])
    if args.device == 'cuda':
        torch.cuda.set_device(local_rank)
        torch.backends.cuda.matmul.allow_tf32 = False
        torch.backends.cudnn.allow_tf32 = False
    device = torch.device(args.device, local_rank) if args.device == 'cuda' else torch.device('cpu')
    dist.init_process_group('nccl' if args.device == 'cuda' else 'gloo')
    try:
        rank, world = dist.get_rank(), dist.get_world_size()
        B, T, A = 4, 32, args.accum
        torch.manual_seed(1337)
        model = GPT(GPTConfig(vocab_size=65, block_size=T, n_layer=2,
                              n_head=2, n_embd=64, dropout=0.0, bias=False)).to(device)
        reference = copy.deepcopy(model)
        wrapped = DDP(model, device_ids=[local_rank] if args.device == 'cuda' else None)
        generator = torch.Generator().manual_seed(2027)
        windows = torch.randint(65, (world * A * B, T + 1), generator=generator).to(device)
        x, y = windows[:, :-1].contiguous(), windows[:, 1:].contiguous()

        def optimizer(m):
            params = list(m.parameters())
            return torch.optim.AdamW([
                {'params': [p for p in params if p.dim() >= 2], 'weight_decay': 0.1},
                {'params': [p for p in params if p.dim() < 2], 'weight_decay': 0.0},
            ], lr=1e-3, betas=(0.9, 0.95), fused=False, foreach=False)

        opt, ref_opt = optimizer(model), optimizer(reference)
        ref_logits, ref_loss = reference(x, y)
        ref_loss.backward()
        local_loss = torch.zeros((), device=device)
        local_logits = []
        for micro in range(A):
            start = (rank * A + micro) * B
            context = wrapped.no_sync() if micro < A - 1 else nullcontext()
            with context:  # no_sync covers both forward and backward
                logits, loss = wrapped(x[start:start+B], y[start:start+B])
                (loss / A).backward()
            local_logits.append(logits.detach())
            local_loss += loss.detach() / A
        dist.all_reduce(local_loss)
        local_loss /= world
        errors = {'logits': 0.0, 'loss': 0.0, 'gradient': 0.0, 'parameter': 0.0}
        failures = []

        def compare(kind, name, actual, expected):
            errors[kind] = max(errors[kind], (actual - expected).abs().max().item())
            if not torch.allclose(actual, expected, atol=5e-6, rtol=1e-4):
                failures.append(f'{kind}:{name}')

        start = rank * A * B
        compare('logits', 'local', torch.cat(local_logits), ref_logits[start:start+A*B].detach())
        compare('loss', 'global_mean', local_loss, ref_loss.detach())
        ref_params = dict(reference.named_parameters())
        for name, parameter in model.named_parameters():
            compare('gradient', name, parameter.grad, ref_params[name].grad)
        opt.step()
        ref_opt.step()
        for name, parameter in model.named_parameters():
            compare('parameter', name, parameter.detach(), ref_params[name].detach())
        metrics = torch.tensor(list(errors.values()) + [float(bool(failures))], device=device)
        dist.all_reduce(metrics, op=dist.ReduceOp.MAX)
        if rank == 0:
            print(json.dumps({'device': args.device, 'world': world, 'A': A,
                              'tokens': world*A*B*T, 'max_abs_error': dict(zip(errors, metrics[:-1].tolist())),
                              'passed': metrics[-1].item() == 0}, indent=2), flush=True)
        if metrics[-1].item():
            raise AssertionError(f'rank {rank}: failed comparisons {failures[:8]}; inspect before changing tolerance')
    finally:
        dist.destroy_process_group()


if __name__ == '__main__':
    main()
