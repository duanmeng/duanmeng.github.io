"""One FP32 FSDP2 update versus a complete nanoGPT reference (PyTorch 2.9.x).

Copy beside the pinned model.py. Run with torchrun on CUDA GPUs.
All ranks use identical initial weights and a deterministic global input.
This small correctness check retains a full reference model on every GPU;
it is not a capacity or performance benchmark.
"""
import argparse
import copy
import json
import os
from datetime import timedelta
from pathlib import Path

import torch
import torch.distributed as dist
from torch.distributed.device_mesh import init_device_mesh
from torch.distributed.fsdp import fully_shard
from torch.distributed.tensor import DTensor


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--batch-size', type=int, default=4, help='One local micro-batch per update')
    parser.add_argument('--atol', type=float, default=5e-6)
    parser.add_argument('--rtol', type=float, default=1e-4)
    parser.add_argument('--output', type=Path, help='Optional JSON result, written only by rank 0')
    args = parser.parse_args()
    if args.batch_size < 1 or min(args.atol, args.rtol) < 0:
        parser.error('Batch size must be positive and tolerances nonnegative.')
    if not torch.cuda.is_available():
        parser.error('This check requires CUDA/NCCL; CPU model checks do not validate FSDP2.')
    from model import GPT, GPTConfig

    torch.set_num_threads(1)
    local_rank = int(os.environ['LOCAL_RANK'])
    torch.cuda.set_device(local_rank)
    device = torch.device('cuda', local_rank)
    torch.backends.cuda.matmul.allow_tf32 = False
    torch.backends.cudnn.allow_tf32 = False
    dist.init_process_group('nccl', timeout=timedelta(seconds=180))
    try:
        rank, world = dist.get_rank(), dist.get_world_size()
        if world < 2:
            raise ValueError('Use at least two ranks to check actual parameter sharding.')
        B, T, V = args.batch_size, 32, 65
        torch.manual_seed(1337)
        model = GPT(GPTConfig(vocab_size=V, block_size=T, n_layer=2,
                              n_head=2, n_embd=64, dropout=0.0, bias=False)).to(device)
        reference = copy.deepcopy(model)
        mesh = init_device_mesh('cuda', (world,))
        for block in model.transformer.h:
            fully_shard(block, mesh=mesh, reshard_after_forward=True)
        fully_shard(model, mesh=mesh, reshard_after_forward=True)

        def make_optimizer(m):
            params = list(m.parameters())
            return torch.optim.AdamW([
                {'params': [p for p in params if p.dim() >= 2], 'weight_decay': 0.1},
                {'params': [p for p in params if p.dim() < 2], 'weight_decay': 0.0},
            ], lr=1e-3, betas=(0.9, 0.95), foreach=False, fused=False)

        optimizer, ref_optimizer = make_optimizer(model), make_optimizer(reference)
        generator = torch.Generator().manual_seed(2027)
        windows = torch.randint(V, (world * B, T + 1), generator=generator).to(device)
        x, y = windows[:, :-1].contiguous(), windows[:, 1:].contiguous()
        ref_logits, ref_loss = reference(x, y)
        ref_loss.backward()
        start = rank * B
        logits, loss = model(x[start:start+B], y[start:start+B])
        loss.backward()  # FSDP2 averages across data-parallel ranks; A=1 here.
        global_loss = loss.detach().clone()
        dist.all_reduce(global_loss)
        global_loss /= world
        errors = {'logits': 0.0, 'loss': 0.0, 'gradient': 0.0, 'parameter': 0.0}
        failures = []

        def compare(kind, name, actual, expected):
            if actual.shape != expected.shape:
                failures.append(f'{kind}:{name}:shape')
                return
            difference = (actual - expected).abs().max().item()
            errors[kind] = max(errors[kind], difference)
            if not torch.allclose(actual, expected, atol=args.atol, rtol=args.rtol):
                failures.append(f'{kind}:{name}')

        def complete(tensor):
            # All ranks must call each full_tensor() in the same parameter order.
            tensor = tensor.detach()
            return tensor.full_tensor() if isinstance(tensor, DTensor) else tensor

        compare('logits', 'local', logits.detach(), ref_logits[start:start+B].detach())
        compare('loss', 'global_mean', global_loss, ref_loss.detach())
        ref_params = dict(reference.named_parameters())
        local_shapes = {}
        for name, parameter in model.named_parameters():
            if parameter.grad is None:
                raise RuntimeError(f'Missing gradient: {name}')
            compare('gradient', name, complete(parameter.grad), ref_params[name].grad)
            local_shapes[name] = {
                'global': list(parameter.shape),
                'local': list(parameter.to_local().shape) if isinstance(parameter, DTensor) else list(parameter.shape),
            }
        optimizer.step()
        ref_optimizer.step()
        for name, parameter in model.named_parameters():
            compare('parameter', name, complete(parameter), ref_params[name].detach())
        metrics = torch.tensor(list(errors.values()) + [float(bool(failures))], device=device)
        dist.all_reduce(metrics, op=dist.ReduceOp.MAX)
        result = {
            'check': 'fsdp2_one_update', 'device': 'cuda', 'world_size': world,
            'micro_batch_size': B, 'accumulation_steps': 1, 'sequence_length': T,
            'global_samples': world * B, 'global_tokens': world * B * T,
            'atol': args.atol, 'rtol': args.rtol,
            'max_abs_error': dict(zip(errors, metrics[:-1].tolist())),
            'passed': metrics[-1].item() == 0,
            'rank0_parameter_shapes': local_shapes if rank == 0 else None,
        }
        if rank == 0:
            text = json.dumps(result, indent=2)
            print(text, flush=True)
            if args.output:
                args.output.parent.mkdir(parents=True, exist_ok=True)
                args.output.write_text(text + '\n')
        if not result['passed']:
            raise AssertionError(f'rank {rank}: {failures[:8]}; inspect inputs and normalization before changing tolerance')
    finally:
        dist.destroy_process_group()


if __name__ == '__main__':
    main()
