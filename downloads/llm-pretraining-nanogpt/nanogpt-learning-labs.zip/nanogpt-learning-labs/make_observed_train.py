"""Generate an inspectable teaching patch for nanoGPT commit 3adf61e; never edit train.py."""
import argparse
import difflib
import hashlib
from pathlib import Path

PINNED_SHA256 = '413bd97b40bb400a2a0d01230e2946f056c263ebac1b7281c2367d964a123085'


def replace_once(text, old, new):
    if text.count(old) != 1:
        raise ValueError('Unexpected upstream anchor: ' + old[:80])
    return text.replace(old, new, 1)


def generate(source):
    if hashlib.sha256(source.encode()).hexdigest() != PINNED_SHA256:
        raise ValueError('train.py differs from pinned nanoGPT 3adf61e154c3fe3fca428ad6bc3818b27a3b8291; refusing to patch')
    text = replace_once(source, 'from model import GPTConfig, GPT\n',
                        'from model import GPTConfig, GPT\nfrom training_observer import TrainingObserver\n')
    flags = '''# Tutorial-only controls; original train.py remains untouched.
observe_first_update = True
benchmark = False
benchmark_warmup = 5
benchmark_updates = 10
ddp_sync_each_micro = False
'''
    text = replace_once(text, 'config_keys = [', flags + 'config_keys = [')
    text = replace_once(text, 'def get_batch(split):', '_guide_sample_reported = False\ndef get_batch(split):\n    global _guide_sample_reported')
    sample = '''    if observe_first_update and split == 'train' and not _guide_sample_reported:
        print(f"GUIDE sampling rank={seed_offset} first_window_starts={ix[:8].tolist()} (random windows may overlap)", flush=True)
        _guide_sample_reported = True
'''
    anchor = '    ix = torch.randint(len(data) - block_size, (batch_size,))\n'
    text = replace_once(text, anchor, anchor + sample)
    text = replace_once(text, 'running_mfu = -1.0\nwhile True:\n',
                        'running_mfu = -1.0\nobserver = TrainingObserver(globals())\nwhile True:\n    observer.begin(local_iter_num)\n')
    text = replace_once(text, 'if iter_num % eval_interval == 0 and master_process:',
                        'if iter_num % eval_interval == 0 and master_process and not observer.active:')
    start = text.index('    for micro_step in range(gradient_accumulation_steps):\n')
    end = text.index('    # clip the gradient\n', start)
    # Public no_sync must enclose BOTH forward and backward. True is the ablation.
    loop = '''    for micro_step in range(gradient_accumulation_steps):
        sync_now = ddp_sync_each_micro or micro_step == gradient_accumulation_steps - 1
        sync_context = model.no_sync() if ddp and not sync_now else nullcontext()
        with sync_context:
            with ctx:
                logits, loss = model(X, Y)
                observer.after_forward(X, Y, logits, loss, micro_step)
                loss = loss / gradient_accumulation_steps
            X, Y = get_batch('train')  # preserve upstream prefetch order
            scaler.scale(loss).backward()
            observer.after_backward(micro_step)
'''
    text = text[:start] + loop + text[end:]
    text = replace_once(text, '    scaler.step(optimizer)\n', '    scaler.step(optimizer)\n    observer.after_step()\n')
    text = replace_once(text, '    optimizer.zero_grad(set_to_none=True)\n',
                        '    optimizer.zero_grad(set_to_none=True)\n    observer.after_clear()\n    observer.end(local_iter_num + 1)\n')
    text = replace_once(text, 'if iter_num % log_interval == 0 and master_process:',
                        'if iter_num % log_interval == 0 and master_process and not observer.active:')
    text = replace_once(text, '\nif ddp:\n    destroy_process_group()\n',
                        '\nobserver.finish()\nif ddp:\n    destroy_process_group()\n')
    return text


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--repo', default='.', type=Path)
    parser.add_argument('--force', action='store_true', help='replace previous generated files')
    args = parser.parse_args()
    source = (args.repo / 'train.py').read_text()
    observed = generate(source)
    compile(observed, 'train_observe.py', 'exec')
    patch = ''.join(difflib.unified_diff(source.splitlines(True), observed.splitlines(True),
                                       fromfile='train.py', tofile='train_observe.py'))
    payloads = {'train_observe.py': observed, 'train_observe.patch': patch,
                'training_observer.py': Path(__file__).with_name('training_observer.py').read_text()}
    for name, content in payloads.items():
        path = args.repo / name
        if path.exists() and path.read_text() != content and not args.force:
            raise FileExistsError(f'{path} differs; preserve it or use --force for generated files')
    for name, content in payloads.items():
        (args.repo / name).write_text(content)
        print(args.repo / name)


if __name__ == '__main__':
    main()
