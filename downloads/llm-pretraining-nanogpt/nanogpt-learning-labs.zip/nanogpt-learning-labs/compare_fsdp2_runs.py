"""Compare continuous and resumed train_fsdp2.py checkpoints on one CPU process.

Both runs must use --export, the same fixed world size, data, and settings.
The official DCP converter reconstructs tensor values; file bytes are not compared.
This small-model check holds complete model and optimizer states in CPU memory.
"""
import argparse
import importlib
import json
import math
import sys
import tempfile
from pathlib import Path

import torch
from torch.distributed.checkpoint.format_utils import dcp_to_torch_save


class Comparison:
    def __init__(self, atol, rtol):
        self.atol, self.rtol = atol, rtol
        self.counts = {}
        self.errors = {}
        self.failures = []

    def fail(self, group, path, reason):
        self.failures.append(f'{group}:{path}:{reason}')

    def compare(self, group, a, b, path='', exact=False):
        if isinstance(a, torch.Tensor) and isinstance(b, torch.Tensor):
            self.counts[group] = self.counts.get(group, 0) + 1
            if a.shape != b.shape or a.dtype != b.dtype:
                self.fail(group, path, 'shape/dtype')
                return
            if a.numel() and (a.is_floating_point() or a.is_complex()):
                error = (a - b).abs().max().item()
                self.errors[group] = max(self.errors.get(group, 0.0), error if math.isfinite(error) else float('inf'))
                okay = torch.equal(a, b) if exact else torch.allclose(a, b, atol=self.atol, rtol=self.rtol)
            else:
                okay = torch.equal(a, b)
            if not okay:
                self.fail(group, path, 'value')
        elif isinstance(a, dict) and isinstance(b, dict):
            if a.keys() != b.keys():
                self.fail(group, path, 'keys')
            for key in a.keys() & b.keys():
                self.compare(group, a[key], b[key], f'{path}.{key}', exact)
        elif isinstance(a, (list, tuple)) and isinstance(b, type(a)):
            if len(a) != len(b):
                self.fail(group, path, 'length')
            for i, (left, right) in enumerate(zip(a, b)):
                self.compare(group, left, right, f'{path}[{i}]', exact)
        elif type(a) is not type(b) or a != b:
            self.fail(group, path, 'value/type')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--continuous', type=Path, required=True, help='Continuous run step-N directory')
    parser.add_argument('--resumed', type=Path, required=True, help='Resumed run step-N directory')
    parser.add_argument('--repo', type=Path, default=Path('.'), help='Pinned nanoGPT repository')
    parser.add_argument('--expected-steps', type=int, default=30)
    parser.add_argument('--atol', type=float, default=5e-6)
    parser.add_argument('--rtol', type=float, default=1e-4)
    parser.add_argument('--output', type=Path)
    args = parser.parse_args()
    if min(args.atol, args.rtol) < 0 or args.expected_steps < 1:
        parser.error('Tolerances must be nonnegative and expected steps positive.')
    torch.set_num_threads(1)
    sys.path.insert(0, str(args.repo.resolve()))
    module = importlib.import_module('model')
    check = Comparison(args.atol, args.rtol)
    folders = {'continuous': args.continuous, 'resumed': args.resumed}
    snapshots = {}
    with tempfile.TemporaryDirectory(prefix='fsdp2-compare-') as scratch:
        for label, folder in folders.items():
            metadata = json.loads((folder / 'completed.json').read_text())
            if metadata['step'] != args.expected_steps:
                raise ValueError(f'{label}: expected step {args.expected_steps}, found {metadata["step"]}')
            converted = Path(scratch) / f'{label}.pt'
            dcp_to_torch_save(folder / 'dcp', converted)
            state = torch.load(converted, map_location='cpu', weights_only=True)
            if not {'model', 'optimizer'} <= state.keys():
                raise ValueError(f'{label}: expected train_fsdp2.py model/optimizer DCP keys')
            world = metadata['settings']['world_size']
            rng = {rank: torch.load(folder / f'rng-{rank}.pt', map_location='cpu', weights_only=True)
                   for rank in range(world)}
            export = torch.load(folder / 'sample' / 'ckpt.pt', map_location='cpu', weights_only=True)
            snapshots[label] = {'metadata': metadata, 'state': state, 'rng': rng, 'export': export}

    continuous, resumed = snapshots['continuous'], snapshots['resumed']
    check.compare('metadata', continuous['metadata'], resumed['metadata'], exact=True)
    check.compare('model', continuous['state']['model'], resumed['state']['model'])
    check.compare('optimizer', continuous['state']['optimizer'], resumed['state']['optimizer'])
    check.compare('rng', continuous['rng'], resumed['rng'], exact=True)
    outputs = {}
    for label, snapshot in snapshots.items():
        model_args = snapshot['metadata']['settings']['model_args']
        check.compare('export_metadata', snapshot['export']['model_args'], model_args, path=label, exact=True)
        check.compare('export_metadata', snapshot['export']['config']['dataset'],
                      snapshot['metadata']['settings']['dataset'], path=label, exact=True)
        check.compare('export_state', snapshot['export']['model'], snapshot['state']['model'], path=label)
        # Use the same fixed input for both checkpoints and both serialization paths.
        generator = torch.Generator().manual_seed(8080)
        B, T = 4, min(32, model_args['block_size'])
        x = torch.randint(model_args['vocab_size'], (B, T), generator=generator)
        y = torch.randint(model_args['vocab_size'], (B, T), generator=generator)
        model = module.GPT(module.GPTConfig(**model_args)).eval()
        model.load_state_dict(snapshot['state']['model'], strict=True)
        with torch.no_grad():
            dcp_logits, _ = model(x, y)
        model.load_state_dict(snapshot['export']['model'], strict=True)
        with torch.no_grad():
            export_logits, _ = model(x, y)
        check.compare('export_logits', dcp_logits, export_logits, path=label)
        outputs[label] = dcp_logits
    check.compare('resumed_logits', outputs['continuous'], outputs['resumed'])
    result = {
        'check': 'fsdp2_checkpoint_values', 'device': 'cpu',
        'step': args.expected_steps, 'world_size': continuous['metadata']['settings']['world_size'],
        'atol': args.atol, 'rtol': args.rtol, 'rng_comparison': 'exact',
        'tensor_comparisons': check.counts, 'max_abs_error': check.errors,
        'failure_count': len(check.failures), 'failures': check.failures[:20],
        'passed': not check.failures,
    }
    text = json.dumps(result, indent=2)
    print(text, flush=True)
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(text + '\n')
    if check.failures:
        raise SystemExit(1)


if __name__ == '__main__':
    main()
