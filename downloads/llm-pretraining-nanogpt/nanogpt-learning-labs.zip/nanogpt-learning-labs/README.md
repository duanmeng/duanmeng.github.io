# nanoGPT 学习实验补充包（2026-10-12）

配合在线文档第 3—6 章，使用 Karpathy nanoGPT 提交 `3adf61e154c3fe3fca428ad6bc3818b27a3b8291` 和 PyTorch 2.9.x。
先 clone/checkout 上游仓库、安装依赖、运行 `python data/shakespeare_char/prepare.py`。
把本目录的 `.py` 文件复制到上游仓库根目录，所有后续命令都从该目录运行。
本包不包含上游模型源码和数据；原版 `train.py` 保留。

## 第 3 章：跑通并观察训练

```bash
python check_inputs.py
python train.py config_smoke.py
python inspect_checkpoint.py out-guide/ckpt.pt
python sample.py --out_dir=out-guide --device=cpu --dtype=float32 --num_samples=1 --max_new_tokens=40 --start=ROMEO:
python train.py config_smoke.py --init_from=resume --max_iters=30
python make_observed_train.py --repo .
python train_observe.py config_smoke.py --out_dir=out-observe-cpu
```

观察器输出 `GUIDE` 记录：configuration → before_forward → after_forward → after_backward → after_step → after_clear。
`after_clear` 应包含 `state_check: PASS`；它只检查指定的 MLP 权重，不替代整个模型的正确性验收。
`check_inputs.py` 分别报告数据有效性与 Git 版本是否确认。源码压缩包没有本地 `.git` 时版本为未确认；请与固定源码及文件校验值核对。

官方示例配置的单 GPU 短跑命令见在线 3.3；观察器和测量完整说明见 `OBSERVE_USAGE.md`。

## 第 4 章：DDP

原版路径先运行 `torchrun --standalone --nproc_per_node=2 train.py config_smoke.py --device=cuda --out_dir=out-guide-ddp`。
随后执行固定输入对照：

```bash
torchrun --standalone --nproc_per_node=2 verify_ddp_step.py --device cuda --accum 1
torchrun --standalone --nproc_per_node=2 verify_ddp_step.py --device cuda --accum 2
```

`train_observe.patch` 展示将原版私有同步标志替换为公开 `DDP.no_sync()` 的具体修改。
两卡同步范围对照必须设 `gradient_accumulation_steps=4`，使每副本实际累积两次；命令见 `OBSERVE_USAGE.md` 和在线 4.3。
`inspect_checkpoint.py A/ckpt.pt --compare B/ckpt.pt` 只比较保存步数、模型结构与参数，不等于完整训练状态恢复验收。

## 第 5 章：FSDP2

`train_fsdp2.py` 与原附件版本字节一致，继续导入上游 `model.py`，使用 FP32、dropout=0、每副本每次更新一个微批。

```bash
torchrun --standalone --nproc_per_node=2 verify_fsdp2_step.py
torchrun --standalone --nproc_per_node=2 train_fsdp2.py --steps 30 --out-dir out-fsdp2-continuous --export
torchrun --standalone --nproc_per_node=2 train_fsdp2.py --steps 20 --out-dir out-fsdp2-split --export
torchrun --standalone --nproc_per_node=2 train_fsdp2.py --steps 30 --out-dir out-fsdp2-split --resume out-fsdp2-split/step-20 --export
python compare_fsdp2_runs.py --continuous out-fsdp2-continuous/step-30 --resumed out-fsdp2-split/step-30 --repo .
python sample.py --out_dir=out-fsdp2-split/step-30/sample --device=cpu --dtype=float32 --num_samples=1 --max_new_tokens=40 --start=ROMEO:
```

目录必须是新的；原训练器拒绝覆盖已有 `step-N`。比较器在单进程 CPU 上读取真实运行产出的 DCP、各 rank RNG 和导出权重。
`verify_model.py --repo .` 是未分片模型的 CPU 机制检查，不能替代 FSDP2 验收。

容量观测：

```bash
python make_observed_fsdp2.py
torchrun --standalone --nproc_per_node=2 train_fsdp2_observe.py --steps 20 --batch-size 4 --out-dir out-fsdp2-observe-b4 --observe --warmup-steps 5
torchrun --standalone --nproc_per_node=2 train_fsdp2_observe.py --steps 20 --batch-size 2 --out-dir out-fsdp2-observe-b2 --observe --warmup-steps 5
```

每个训练更新单独同步计时，前 5 次原有更新预热、其余 15 次测量；排除验证/保存/导出操作本身。
修改 batch 改变全局工作量，此实验用于容量观察。此计时方法与原版连续窗口计时不同，不能直接横比二者的 tokens/s。

## 第 6 章：多机

每台机器先运行 `check_inputs.py` 并比较源文件、配置、数据与词表的 SHA256。再按在线 6.2 的双节点命令运行 `check_dist.py`。
`check_dist.py` 的标量正确性只验证基本连接，不证明 RDMA 已启用或网络带宽足够。
沿在线 6.3—6.6，先两节点各两卡；固定 `G=4` 比较单机四卡与两机各两卡，再研究更多 GPU。

## 验证范围

已执行：CPU 原版训练状态对照、观察与测量窗口检查、模型机制检查、数据及普通 checkpoint 检查、CPU DCP 比较器正负例、Python 编译和 PyTorch 2.9.1 API 核对。
未执行：CUDA 单卡、多卡 NCCL/DDP/FSDP2、真实分布式 DCP 保存恢复、跨机通信和硬件性能。
这些检查器提供可执行验收方法，硬件结果须由目标机器实测。原版 `max_iters` 的更新/保存边界仍按在线 3.3 解释。
