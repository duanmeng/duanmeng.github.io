"""Run from the pinned nanoGPT root; prints comparable environment/data facts."""
import hashlib
import json
import pickle
import platform
import subprocess
from pathlib import Path

import numpy as np
import torch

EXPECTED = '3adf61e154c3fe3fca428ad6bc3818b27a3b8291'

def sha256(path):
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()

def main():
    files = [Path(name) for name in ['train.py', 'model.py', 'sample.py', 'config_smoke.py',
             'data/shakespeare_char/train.bin', 'data/shakespeare_char/val.bin',
             'data/shakespeare_char/meta.pkl']]
    missing = [str(p) for p in files if not p.is_file()]
    if missing:
        raise SystemExit('Missing files: ' + ', '.join(missing))
    # This metadata was produced by the reader's own prepare.py execution.
    with files[-1].open('rb') as stream:
        meta = pickle.load(stream)
    assert meta['vocab_size'] == len(meta['stoi']) == len(meta['itos'])
    for ch, index in meta['stoi'].items():
        assert meta['itos'][index] == ch
    token_counts = {}
    for split in ['train', 'val']:
        path = Path('data/shakespeare_char') / (split + '.bin')
        assert path.stat().st_size % 2 == 0
        data = np.memmap(path, dtype=np.uint16, mode='r')
        assert len(data) > 32 and int(data.max()) < meta['vocab_size']
        token_counts[split] = len(data)
    try:
        git_root = subprocess.check_output(['git', 'rev-parse', '--show-toplevel'], stderr=subprocess.DEVNULL, text=True).strip()
        commit = (subprocess.check_output(['git', 'rev-parse', 'HEAD'], stderr=subprocess.DEVNULL, text=True).strip()
                  if Path(git_root).resolve() == Path.cwd().resolve() else None)
    except (subprocess.CalledProcessError, FileNotFoundError):
        commit = None
    print(json.dumps({'python': platform.python_version(), 'torch': torch.__version__,
        'torch_cuda_build': torch.version.cuda, 'cuda_available': torch.cuda.is_available(),
        'visible_gpu_count': torch.cuda.device_count(), 'expected_commit': EXPECTED,
        'commit': commit, 'version_verified': commit == EXPECTED,
        'vocab_size': meta['vocab_size'], 'tokens': token_counts,
        'files': {str(p): {'bytes': p.stat().st_size, 'sha256': sha256(p)} for p in files},
        'data_files_valid': True}, ensure_ascii=False, indent=2))
    if commit is not None:
        assert commit == EXPECTED, 'Checkout the documented nanoGPT commit before continuing.'

if __name__ == '__main__':
    main()
