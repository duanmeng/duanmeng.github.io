"""Generate an instrumented copy of the pinned nanoGPT FSDP2 teaching entry.

No CUDA run has been performed. The original train_fsdp2.py is never modified.
Warmup means the first N existing updates of this invocation, not extra updates.
"""
import argparse
import hashlib
from pathlib import Path


SOURCE_SHA256 = '654a8c0b4d7f7a4738de47a88d2ad02b68c29d441cccc3b8b20308a4139cc435'

OPTIONS = '''    parser.add_argument('--observe', action='store_true',
                        help='Report synchronized training-update time and allocated peak memory')
    parser.add_argument('--warmup-steps', type=int, default=5,
                        help='Exclude the first N existing updates of this invocation; adds no updates')
    parser.add_argument('--observe-parameter', default='transformer.h.0.mlp.c_fc.weight',
                        help='Print this named parameter global/local shape on every rank')
'''

INITIALIZE = '''        observed_updates = 0
        observed_seconds = 0.0
        observed_peak = 0
        observation_initial_step = step
        if args.observe:
            named = dict(model.named_parameters())
            if args.observe_parameter not in named:
                raise ValueError(f'Unknown parameter: {args.observe_parameter}')
            parameter = named[args.observe_parameter]
            print(json.dumps({
                'event': 'fsdp2_parameter_shape', 'rank': rank, 'world_size': world,
                'name': args.observe_parameter, 'dtype': str(parameter.dtype),
                'global_shape': list(parameter.shape),
                'local_shape': list(parameter.to_local().shape),
            }), flush=True)

'''

BEFORE_UPDATE = '''            observe_this_update = (args.observe and
                                   step - observation_initial_step >= args.warmup_steps)
            if observe_this_update:
                # Drain earlier work (including evaluation) before resetting this update's peak.
                torch.cuda.synchronize(device)
                torch.cuda.reset_peak_memory_stats(device)
                update_started = time.perf_counter()
'''

AFTER_UPDATE = '''            if observe_this_update:
                # The measured interval includes batch loading and the end synchronization.
                torch.cuda.synchronize(device)
                observed_seconds += time.perf_counter() - update_started
                observed_peak = max(observed_peak, torch.cuda.max_memory_allocated(device))
                observed_updates += 1
'''

REPORT = '''        if args.observe:
            # This reporting collective is outside all measured update intervals.
            torch.cuda.synchronize(device)
            observation = torch.tensor([observed_seconds, float(observed_peak)],
                                       dtype=torch.float64, device=device)
            dist.all_reduce(observation, op=dist.ReduceOp.MAX)
            seconds_max, peak_max = observation.cpu().tolist()
            global_tokens = observed_updates * world * args.batch_size * args.block_size
            if rank == 0:
                print(json.dumps({
                    'event': 'fsdp2_training_observation',
                    'status': 'measured' if observed_updates else 'no_measured_updates',
                    'world_size': world, 'batch_size_per_rank': args.batch_size,
                    'block_size': args.block_size, 'dtype': 'float32',
                    'invocation_initial_step': observation_initial_step,
                    'completed_step': step,
                    'warmup_updates_requested': args.warmup_steps,
                    'warmup_updates_executed': min(args.warmup_steps, step - observation_initial_step),
                    'measured_updates_per_rank': observed_updates,
                    'global_tokens': global_tokens,
                    'seconds_max_rank_sum': seconds_max if observed_updates else None,
                    'tokens_per_second': global_tokens / seconds_max if seconds_max > 0 else None,
                    'peak_allocated_bytes_max_rank': int(peak_max) if observed_updates else None,
                    'timed_operations': ['batch_loading', 'forward', 'backward',
                                         'optimizer_step', 'end_cuda_synchronize'],
                    'excluded_operations': ['warmup_updates', 'evaluation', 'checkpoint',
                                            'export', 'observation_reporting'],
                    'timing_method': 'sum of per-update synchronized intervals; then max across ranks',
                    'peak_scope': 'live allocated bytes during measured updates, including state '
                                  'and buffers still live at update entry; not reserved memory',
                    'extra_warmup_updates': 0,
                }), flush=True)

'''


def replace_once(source, old, new):
    count = source.count(old)
    if count != 1:
        raise ValueError(f'Expected one source anchor, found {count}: {old[:80]!r}')
    return source.replace(old, new, 1)


def generate(source):
    source = replace_once(source, 'import pickle\n', 'import pickle\nimport time\n')
    source = replace_once(source, '    args = parser.parse_args()\n',
                          OPTIONS + '    args = parser.parse_args()\n'
                          '    if args.warmup_steps < 0:\n'
                          "        raise ValueError('warmup-steps must be nonnegative')\n")
    source = replace_once(source, '        while step < args.steps:\n',
                          INITIALIZE + '        while step < args.steps:\n' + BEFORE_UPDATE)
    source = replace_once(source, '            step += 1\n',
                          '            step += 1\n' + AFTER_UPDATE)
    source = replace_once(source, '        # Create a new directory for this completed update count; do not overwrite.\n',
                          REPORT + '        # Create a new directory for this completed update count; do not overwrite.\n')
    return source


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source', default='train_fsdp2.py')
    parser.add_argument('--output', default='train_fsdp2_observe.py')
    args = parser.parse_args()
    source_path, output_path = Path(args.source), Path(args.output)
    if source_path.resolve() == output_path.resolve():
        raise ValueError('Source and output must be different files')
    raw = source_path.read_bytes()
    actual = hashlib.sha256(raw).hexdigest()
    if actual != SOURCE_SHA256:
        raise ValueError(f'Unexpected source SHA256 {actual}; expected {SOURCE_SHA256}. '
                         'Use the unmodified tutorial attachment as the source.')
    result = generate(raw.decode('utf-8'))
    compile(result, str(output_path), 'exec')
    if output_path.exists() and output_path.read_text() != result:
        raise FileExistsError(f'Refusing to overwrite a different file: {output_path}')
    output_path.write_text(result)
    print(f'Generated {output_path}; source SHA256 verified; CUDA/NCCL execution untested.')


if __name__ == '__main__':
    main()
