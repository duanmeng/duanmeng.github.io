import os, torch, torch.distributed as dist

def setup():
    dist.init_process_group("nccl")            # GPU 间通信用 NCCL 后端
    local_rank = int(os.environ["LOCAL_RANK"]) # 本节点内的第几张卡
    torch.cuda.set_device(local_rank)          # 绑定当前进程到这张卡
    return local_rank

local_rank = setup()
rank = dist.get_rank()          # 全局第几个进程（跨所有节点）
world_size = dist.get_world_size()  # 总进程数 = 总卡数
is_main = rank == 0             # 只在主进程打印日志/存 checkpoint
print(f"rank={rank}, local_rank={local_rank}, world_size={world_size}", flush=True)
dist.destroy_process_group()
