import os, socket
from datetime import timedelta
import torch
import torch.distributed as dist

local_rank = int(os.environ["LOCAL_RANK"])
torch.cuda.set_device(local_rank)
dist.init_process_group("nccl", timeout=timedelta(seconds=120))
try:
    rank, world = dist.get_rank(), dist.get_world_size()
    value = torch.tensor(float(rank), device=f"cuda:{local_rank}")
    dist.all_reduce(value)
    expected = world * (world - 1) / 2
    print(socket.gethostname(), "rank=", rank, "local_rank=", local_rank,
          "world=", world, "sum=", value.item(), flush=True)
    assert value.item() == expected
finally:
    dist.destroy_process_group()
