"""Inspect a checkpoint produced by the reader's own nanoGPT training run."""
import argparse
import json
from pathlib import Path
import torch

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('checkpoint', type=Path)
    parser.add_argument('--compare', type=Path, help='Compare model weights at the same saved update')
    args = parser.parse_args()
    ckpt = torch.load(args.checkpoint, map_location='cpu', weights_only=True)
    state = ckpt['model']
    result = {'path': str(args.checkpoint), 'iter_num': ckpt.get('iter_num'),
              'model_args': ckpt['model_args'], 'dataset': ckpt['config']['dataset'],
              'state_dict_entries': len(state),
              'optimizer_state_entries': len(ckpt.get('optimizer', {}).get('state', {})),
              'has_rng_state': any('rng' in key.lower() for key in ckpt),
              'all_model_values_finite': all(torch.isfinite(t).all().item() for t in state.values())}
    if args.compare:
        other = torch.load(args.compare, map_location='cpu', weights_only=True)
        failures = []
        if ckpt.get('iter_num') != other.get('iter_num'):
            failures.append('iter_num')
        if ckpt['model_args'] != other['model_args']:
            failures.append('model_args')
        if state.keys() != other['model'].keys():
            failures.append('model_keys')
        max_error = 0.0
        for name in state.keys() & other['model'].keys():
            lhs, rhs = state[name], other['model'][name]
            if lhs.shape != rhs.shape or lhs.dtype != rhs.dtype:
                failures.append(name + ':shape_or_dtype')
                continue
            max_error = max(max_error, float((lhs - rhs).abs().max()))
            if not torch.allclose(lhs, rhs, atol=5e-6, rtol=1e-4):
                failures.append(name)
        result['model_comparison'] = {'other': str(args.compare), 'atol': 5e-6, 'rtol': 1e-4,
                                     'max_abs_error': max_error, 'failures': failures,
                                     'passed': not failures}
    print(json.dumps(result, ensure_ascii=False, indent=2))
    assert result['all_model_values_finite']
    if args.compare:
        assert result['model_comparison']['passed'], 'Inspect differences before changing tolerance.'

if __name__ == '__main__':
    main()
