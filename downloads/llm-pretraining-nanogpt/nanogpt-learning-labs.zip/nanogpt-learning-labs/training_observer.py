"""Teaching instrumentation for the pinned nanoGPT train.py; not production profiling."""
import json
import time

import torch
import torch.distributed as dist


class TrainingObserver:
    def __init__(self, scope):
        self.s = scope
        self.rank = dist.get_rank() if scope['ddp'] else 0
        self.world = scope['ddp_world_size']
        self.device = scope['device']
        self.cuda = scope['device_type'] == 'cuda'
        self.observe = scope['observe_first_update']
        self.benchmark = scope['benchmark']
        self.warmup = scope['benchmark_warmup']
        self.updates = scope['benchmark_updates']
        self.active = False
        self.reported = False
        if self.observe:
            assert scope['dtype'] == 'float32' and not scope['compile'], 'Observation requires FP32 and compile=False'
            assert scope['learning_rate'] > 0, 'Observation requires a positive learning rate'
        if self.benchmark:
            assert scope['dtype'] != 'float16', 'FP16 skipped updates are outside this benchmark'
            assert self.warmup >= int(self.observe) and self.updates > 0
            assert not scope['eval_only'], 'Benchmark requires training'
            available = scope['max_iters'] - scope['iter_num'] + 1
            assert available >= self.warmup + self.updates, 'Increase max_iters to finish the benchmark window'
        self.parameter = scope['raw_model'].transformer.h[0].mlp.c_fc.weight if self.observe else None
        self.emit('configuration', G=scope['config']['gradient_accumulation_steps'],
                  A=scope['gradient_accumulation_steps'], W=self.world, b=scope['batch_size'],
                  local_samples_per_update=scope['batch_size'] * scope['gradient_accumulation_steps'],
                  global_tokens_per_update=scope['tokens_per_iter'],
                  sync_each_micro=scope['ddp_sync_each_micro'])

    def emit(self, event, **values):
        print('GUIDE ' + json.dumps(dict(event=event, rank=self.rank, **values)), flush=True)

    def synchronize(self):
        if self.cuda:
            torch.cuda.synchronize(self.device)

    def begin(self, completed):
        self.first = self.observe and completed == 0
        self.active = self.benchmark and self.warmup <= completed < self.warmup + self.updates
        if self.first:
            self.before = self.parameter.detach().clone()
            self.loss_sum = torch.zeros((), device=self.device)
            assert self.parameter.grad is None
            self.emit('before_forward', parameter='transformer.h.0.mlp.c_fc.weight',
                      parameter_shape=list(self.parameter.shape), gradient_is_none=True)
        if self.benchmark and completed == self.warmup:
            self.synchronize()
            if self.world > 1:
                dist.barrier()
            self.synchronize()
            if self.cuda:
                torch.cuda.reset_peak_memory_stats(self.device)
            self.emit('benchmark_start', completed_updates=completed, measured_updates=self.updates,
                      excludes='warmup, validation, checkpoint, ordinary loss logging; includes sampling/prefetch, forward, backward, step, clear')
            self.started = time.perf_counter()

    def after_forward(self, x, y, logits, loss, micro):
        if not self.first:
            return
        assert torch.equal(self.parameter.detach(), self.before), 'Forward changed the observed parameter'
        self.loss_sum += loss.detach() / self.s['gradient_accumulation_steps']
        if micro == 0:
            self.emit('after_forward', x_shape=list(x.shape), y_shape=list(y.shape),
                      logits_shape=list(logits.shape), loss_shape=list(loss.shape),
                      parameter_unchanged=True, gradient_is_none=self.parameter.grad is None)

    def after_backward(self, micro):
        if not self.first:
            return
        assert torch.equal(self.parameter.detach(), self.before), 'Backward changed the observed parameter'
        gradient = self.parameter.grad
        assert gradient is not None and torch.isfinite(gradient).all()
        if micro + 1 == self.s['gradient_accumulation_steps']:
            assert gradient.float().norm() > 0, 'Observed gradient is zero'
            mean_loss = self.loss_sum.clone()
            if self.world > 1:
                dist.all_reduce(mean_loss)
                mean_loss /= self.world
            self.emit('after_backward', backward_calls=micro + 1, parameter_unchanged=True,
                      observed_gradient_norm_before_clip=gradient.float().norm().item(),
                      global_mean_loss=mean_loss.item(),
                      loss_scope='all equal-size, unpadded micro-batches of this first update')

    def after_step(self):
        if self.first:
            delta = (self.parameter.detach() - self.before).abs().max().item()
            assert delta > 0, 'The observed parameter did not change'
            self.emit('after_step', optimizer_calls=1, observed_parameter_max_abs_change=delta)

    def after_clear(self):
        if self.first:
            assert self.parameter.grad is None
            self.emit('after_clear', gradient_is_none=True, state_check='PASS')
            del self.before, self.loss_sum

    def end(self, completed):
        if self.benchmark and completed == self.warmup + self.updates:
            self.synchronize()
            elapsed = time.perf_counter() - self.started
            peak = torch.cuda.max_memory_allocated(self.device) if self.cuda else None
            slowest = torch.tensor(elapsed, dtype=torch.float64, device=self.device)
            if self.world > 1:
                dist.all_reduce(slowest, op=dist.ReduceOp.MAX)
            self.emit('benchmark_rank', completed_updates=completed, local_seconds=elapsed,
                      peak_allocated_bytes=peak, peak_scope='absolute PyTorch allocated bytes; CPU memory is not measured')
            if self.rank == 0:
                tokens = self.updates * self.s['tokens_per_iter']
                self.emit('benchmark_result', measured_updates=self.updates, global_tokens=tokens,
                          slowest_rank_seconds=slowest.item(), global_tokens_per_second=tokens / slowest.item(),
                          hardware='CUDA' if self.cuda else 'CPU')
            self.reported = True

    def finish(self):
        if self.benchmark:
            assert self.reported, 'Training ended before the benchmark window completed'
